# 用 GPT Image 2 给这套骨骼做「AI 皮肤」

> 本文截图与 AI 生成图未入库（遵循仓库约定）；本地 `shots/`/`out/` 或运行 demo 查看。

先回答一个容易混淆的问题：**这套角色里的"蒙皮"是什么？**

| 东西 | 哪来的 |
|---|---|
| 2D 网格（顶点 / 三角面 / UV） | `tools/convert.mjs` 把 3D 模型按视角投影、烘焙出来的 |
| 蒙皮权重 | 普通模型来自 GLB 自带的 skin weights；`naked` 这种裸模型由 `tools/autoskin.mjs` 用「最近骨段反距离加权 + 邻接平滑」现算 |
| 贴图 | 从 GLB 的材质/贴图烘焙成 `out/<view>/tex/*.png` |
| 骨骼动画 | 来自 Mesh2Motion 的 CC0 动画，按骨长归一化后共享 |

所以"蒙皮"不是 AI 画的：**网格、权重、骨架、动画都是代码/3D 资产算出来的，AI 换的是最外面那层贴图**。
`tools/ai-skin.mjs` 做的事就是：让 gpt-image-2 按角色姿势生成一张人物图，再把这层"皮"贴回同一套网格。
骨架、权重、动画、逐帧深度排序全部不动。精细版 `tools/ai-skin-parts.mjs` 会按身体分成 6 块，
每块单独出图/贴图，见第 6 节。

## 1. 准备

API Key 只放在环境变量里，**不要写进仓库、截图或聊天记录**：

```bash
export ARUHUB_API_KEY='你的 key'
# 可选：默认就是 https://api.aruhub.com/v1
export ARUHUB_BASE_URL='https://api.aruhub.com/v1'
```

仓库的 `.gitignore` 已经忽略 `.env` / `.env.*`；工具本身不会把 key 写进任何输出文件。

## 2. 生成一张 AI 皮肤

```bash
# 默认底模 male，生成正/侧两个视角，角色名 ai_ronin
node tools/ai-skin.mjs --char male --name ai_ronin --views side,front
```

它会做这些事：

1. 用 `tools/render-ref.mjs` 渲染**绑定姿态**参考图（不是某一帧动画，避免贴图被某一帧的姿势带偏）：
   `out/<view>/ai/ref-male-<view>.png`
2. 调 `POST /v1/images/edits`，把参考图 + 提示词发给 `gpt-image-2`（`size=1024x1024`、`quality=medium`）：
   `out/<view>/ai/raw-ai_ronin-<view>.png`
3. 去背景（品红/透明）、裁到人物包围盒、边缘补 2px 色边：
   `out/<view>/ai/ai_ronin-<view>.png`
4. 按绑定姿态计算**平面投影 UV**，写入：
   `out/<view>/characters-ai.json`（角色名 `ai_ronin`，带 `ai` 标记和 `ai/...` 贴图路径）

刷新演示页，角色下拉框会出现 `ai_ronin · AI`。两个视角要分别生成，因为侧/正投影的网格不一样。

常用参数：

```bash
--model gpt-image-2          # 也支持 gpt-image-2.5-flare / gpt-image-2.5-sunburst
--quality medium             # 教程里确认稳定的值
--size 1024x1024
--prompt "..."               # 覆盖默认提示词；{VIEW_HINT} 会被替换成视角描述
--reuse                      # 复用已有 ref/raw，只重新抠图/写 UV（调试用）
--no-api                     # 完全不调 API（配合 --reuse 重做后处理）
```

实测一次 `edits` 大约 30s–2min，正/侧两张图按一次一张算；生成失败时工具会打印接口返回的前 600 字符，不会打印 key。

## 3. 贴图是怎么贴上去的

M2D 的每个顶点都有绑定姿态下的 2D 坐标 `(x, y)`。工具取整个人物的包围盒，
把 AI 人物图（裁到它自己的包围盒）线性映射上去：

```
u = u0 + (x - minX) / (maxX - minX) * (u1 - u0)
v = v0 + (1 - (y - minY) / (maxY - minY)) * (v1 - v0)
```

也就是说这是一张**平面投影的"贴花皮"**，不是按身体部位重新拆的 UV。
好处是零手工、任何现有角色都能直接套；代价见第 6 节。

正视图的绑定姿态是 T-pose，AI 图也要求保持 T-pose；侧视图是侧身站姿，就要求保持侧身。
这样贴图在绑定姿态下和网格轮廓对齐，动画时纹理跟着蒙皮形变走。

## 4. 也可以导出成龙骨

AI 皮肤角色同样能进 DragonBones：

```bash
node tools/export-dragonbones.mjs \
  --data out/front --out out/front/dragonbones \
  --extra out/front/characters-ai.json --chars ai_ronin

node tools/verify-dragonbones.mjs \
  --db out/front/dragonbones/ai_ronin.json \
  --data out/front --char ai_ronin --clip Walk
```

`verify-dragonbones.mjs` 和演示页会自动合并 `characters-ai.json`，不需要再改代码。
实测 `ai_ronin` 在官方 DragonBones 5.7 + Pixi 8 里能正常播放，逐帧骨骼矩阵和蒙皮顶点校验通过
（逐帧误差 < 1.5px；300px=1m）。

## 5. 默认提示词

工具里的默认主题是"赛博朋克浪人"（可按 `--prompt` 换）：

```
Repaint the character in the reference image as a detailed stylized cyberpunk street samurai:
lean adult male, short black hair, glowing cyan visor over the eyes, dark teal techwear jacket with
orange emissive trim, mechanical right forearm, dark cargo pants, armored boots.
Keep the EXACT same pose, body proportions, limb positions, silhouette, camera angle and full-body
framing as the reference, from head to toe. Do not add a weapon, cape, hat, long hair, backpack or
anything that changes the silhouette. {VIEW_HINT}
Solid chroma-key magenta background (#FF00FF), no shadow, no ground, no text, no border, no frame.
Clean 2D game character concept art, crisp edges, readable silhouette, high detail.
```

`{VIEW_HINT}` 在正视图是 `Strict front-facing T-pose...`，侧视图是 `Strict side profile facing right...`。
换主题时**务必保留** "same pose / silhouette / full-body framing" 和 "no props" 这两层约束，
否则 AI 改轮廓后，平面 UV 会对不上。

## 6. 精细版：按身体分块（ai_ronin_hd）

整身平面版有一个绕不过去的限制：所有部位共用一张图，1024 的全身图摊到脸、手指、机械臂上，
细节有限；而且一个顶点只有一套 UV，关节两侧的不同部位没有独立纹理空间。

`tools/ai-skin-parts.mjs` 的做法：

1. 按每个三角形的**主导骨骼**把它分到 6 块：
   `head` / `torso` / `arm_l` / `arm_r` / `leg_l` / `leg_r`。
   另外把 `neck` 主导的三角形划给 `torso`（`rebalanceNeck`），
   避免"头 + 脖子 + 肩根"整块贴图在转头时把脸拉长。
2. 每块复制自己用到的顶点（块边界顶点在相邻块里各有一份），三角面重映射。
   最后仍然只生成**一个 part**，所以 M2D 运行时的逐三角全局深度排序完全不变。
3. 正视图：每块单独渲染绑定姿态的局部参考图（`render-ref.mjs --group`），
   再用该块的局部提示词调 gpt-image-2（脸 / 夹克 / 机械臂 / 战术裤 / 靴子各有细节）。
   侧视图：肢体在绑定姿态下互相遮挡，逐块生成接缝很明显，所以统一从 `ai_ronin` 的
   整身侧视 AI 图里裁块（`--source full` 或默认 hybrid 的侧视分支）。
4. 6 块按 3×2 打包成一张 **2014×2008** 图集；每块的 UV 映射到自己的格子里，
   图集透明像素先清成黑色，避免双线性采样把品红背景带到边缘。
5. 写进 `characters-ai.json`，角色名 `ai_ronin_hd`；网格变成
   **7450 顶点 / 13757 三角 / 1 part**（比原始 7399 顶点多的是块边界复制）。

### 6.1 命令

精细版依赖整身侧视图（`ai_ronin`）来裁侧视块，所以先跑一次平面版：

```bash
export ARUHUB_API_KEY='...'

# 前置：整身平面版（正/侧各一张）
node tools/ai-skin.mjs --char male --name ai_ronin --views side,front

# 精细版：正视图 6 块逐块生成（6 次图片调用），侧视图裁块（0 次）
node tools/ai-skin-parts.mjs --char male --name ai_ronin_hd --views side,front
```

参数：

```bash
--source hybrid      # 默认：正视图逐块生成，侧视图裁整身图
--source generated   # 正/侧都逐块生成（侧视手臂参考图是压缩的，通常不建议）
--source full        # 全部从整身图裁块（不调 API，只重排 UV/图集）
--source custom      # 用 out/<view>/ai/parts/<name>-<group>-<view>.png 当分块图（不调 API）
--reuse              # 复用已有 ref/raw，只重做抠图/图集/网格
--no-api             # 不调 API（配合 --reuse）
--full-name ai_ronin # 侧视裁块用哪张整身图
--pose Walk          # 纹理姿态：用某段动画的某一帧求 UV/参考图；默认 bind
--pose-frame 0       # 纹理姿态帧号
--pose-groups arm_r  # 哪些块用纹理姿态；不写=全部（用 custom/generated 时有效）
--style chibi        # 造型预设：cyberpunk（默认）| chibi（Q版卡通）
--head-scale 2       # 只把 head 组顶点绕 head 骨骼原点放大；默认 1
--hide arm_l         # 某块全透明、不调 API（侧视隐藏远侧手臂用）
```

输出：

```
out/<view>/ai/parts/ref-ai_ronin_hd-<group>-<view>.png
out/<view>/ai/parts/raw-ai_ronin_hd-<group>-<view>.png
out/<view>/ai/parts/ai_ronin_hd-<group>-<view>.png
out/<view>/ai/ai_ronin_hd-atlas-<view>.png
out/<view>/characters-ai.json
out/<view>/ai/ai_ronin_hd-<view>.json     # 分块/图集元数据
```

演示页里选 `ai_ronin_hd · AI`，或者：

```
http://127.0.0.1:8899/web/index.html?view=front&char=ai_ronin_hd&clip=Walk&frame=0&play=0&bones=0
```

### 6.2 龙骨导出

分块图集角色同样能导出，并且仍是单 mesh slot：

```bash
node tools/export-dragonbones.mjs \
  --data out/front --out out/front/dragonbones \
  --extra out/front/characters-ai.json --chars ai_ronin_hd

node tools/verify-dragonbones.mjs \
  --db out/front/dragonbones/ai_ronin_hd.json \
  --data out/front --char ai_ronin_hd --clip Walk
```

实测 `ai_ronin_hd` 在官方 DragonBones 5.7 + Pixi 8 中逐帧骨骼矩阵/蒙皮顶点校验通过，
图集 `2014x2008` 正常加载。

### 6.3 提示词

每块的提示词由三部分组成：统一的 `CHARACTER BIBLE`（赛博朋克浪人、固定配色）、
该块的 `PART_PROMPT`（只画头/只画躯干/只画机械臂……）、以及 `VIEW_HINT`（正面 T-pose / 侧面朝右）。
所有块都强制：

```
Keep the exact same silhouette, proportions, pose and orientation as the reference body part.
Do not add extra limbs, a second leg/arm, a weapon, cape, hat, backpack, text or frame.
Solid chroma-key magenta background (#FF00FF), no shadow, no ground, one isolated part, centered.
```

改主题时改 `tools/ai-skin-parts.mjs` 里的 `BIBLE` / `PART_PROMPT` 即可。
也可以只重生成某一块：删掉该块的 `ref/raw` 文件，再带 `--reuse` 跑一遍，
其余块的生成图会复用。

### 6.4 效果与取舍

- 正视图：脸、护目镜、夹克拉链、机械臂、护膝/靴子的细节明显比整身平面版好。
- 块与块之间是**硬接缝**：相邻块各自采样自己的贴图，关节处颜色/纹理可能不完全连续。
  提示词统一配色可以减轻，但不能完全消除。
- 侧视图现在仍是整身图裁块，视觉上接近平面版——这是有意的：侧视手臂被躯干挡住，
  逐块生成参考图本身就是一团压缩的形状，生成结果反而更差。
- 头仍是一张正面脸贴图，头部大幅偏转（比如 Sword_Attack 的转头）时会有 2D 平面贴图的拉伸。
  要彻底解决，需要按头部朝向生成多张（前/3/4/侧）并在动画里切换，或回到真正的 3D 头部。
- 图集固定 2014×2008（3×2），6 块之外的角色分块需要改 `packAtlas` 的网格参数。

## 7. 原 UV 烘焙：直接利用原贴图集（ai_police）

先回答一个关键问题：**`out/<view>/tex/*.png` 不是手画的，也不是 AI 画的**，
它们是 `tools/convert.mjs` 从 Mesh2Motion 的 GLB 里烘出来的原始贴图。它们分两类：

| 角色 | 贴图 | UV 占用 | 采样到的颜色 | 能直接当语义图集用吗 |
|---|---|---|---|---|
| `male` / `naked` | 499×500 | 3.7%（95×98 px） | **2 种**（蓝/橙） | 不能，只是调色板 |
| `police_male` / `swat_male` / `female_8` / `monster` / `zombie` … | 512 或 1024 | 93%–96% | 100–1100 种 | **能**，是真正的 UV 图集 |

用 `tools/inspect-skin.mjs` 可以自己验：

```bash
node tools/inspect-skin.mjs --data out/side --char male
node tools/inspect-skin.mjs --data out/side --char police_male
node tools/inspect-skin.mjs --data out/side --all
```

`male` 的 UV 只落在贴图里 95×98 的一小块、只有蓝/橙两个颜色——这是"用调色板给纯色模型上色"的做法。
在这种 UV 里让 AI 画细节，网格根本采不到。**这正是我们前面要用新的平面 UV / 分块 UV 的原因。**

但 `police_male`、`female_8`、`monster` 这些角色本来就有**语义 UV 图集**：脸、手、衣服、腿分别是不相交的 UV 岛。
对它们，正确做法不是重新做平面 UV，而是：

1. 渲染这个角色的绑定姿态参考图；
2. 让 gpt-image-2 按参考图生成一张同姿势的整身角色图；
3. 按**每个三角形的绑定姿态屏幕坐标**，把 AI 图采样并写回**原来的 UV 图集**；
4. 网格、UV、权重、动画全部不动，只换贴图。

这就是 `tools/bake-ai-atlas.mjs`。它不需要复制顶点、不需要分块图集，也没有块与块之间的接缝；
每个 UV 岛拿到的是 AI 图在绑定姿态下对应位置的颜色。输出默认 2×（512→1024）。

### 7.1 命令

```bash
export ARUHUB_API_KEY='...'

# 1) 检查底模是不是语义 UV 图集
node tools/inspect-skin.mjs --data out/side --char police_male

# 2) 给底模生成整身参考图。--no-char 表示只留图/元数据，不往演示角色里加平面版
node tools/ai-skin.mjs --char police_male --name ai_police_src --views side,front --no-char

# 3) 烘焙进原 UV 图集（每个视角一次）
node tools/bake-ai-atlas.mjs --data out/front --char police_male --ai ai_police_src --name ai_police
node tools/bake-ai-atlas.mjs --data out/side  --char police_male --ai ai_police_src --name ai_police
```

演示页里选 `ai_police · AI`（或工具栏的「AI 原UV烘焙」）：

```
http://127.0.0.1:8899/web/index.html?view=front&char=ai_police&clip=Walk&frame=0&play=0&bones=0
```

`ai_police` 的统计是 **739 顶点 / 900 三角 / 1 part**——和 `police_male` 完全一样，
因为网格根本没改；只有 `textures` 指向 `out/<view>/ai/ai_police-atlas-<view>.png`（1024×1024）。

### 7.2 龙骨导出

因为网格/UV 没变，龙骨导出同样能过：

```bash
node tools/export-dragonbones.mjs \
  --data out/front --out out/front/dragonbones \
  --extra out/front/characters-ai.json --chars ai_police

node tools/verify-dragonbones.mjs \
  --db out/front/dragonbones/ai_police.json \
  --data out/front --char ai_police --clip Walk
```

实测通过；图集 1024×1024。

### 7.3 几版 AI 皮肤怎么选

| 版本 | 底模 | 网格/UV | 细节 | 接缝 | 适用 |
|---|---|---|---|---|---|
| `ai_ronin` | `male` 高模 7399 顶点 | 新建整身平面 UV | 中 | 无（整体一张图） | 通用、最快 |
| `ai_ronin_hd` | `male` 高模 | 6 块平面图集 | **高**（脸/机械臂/裤靴分块） | 有硬接缝 | 正视图展示 |
| `ai_ronin_v2` | `male` 高模 | 6 块平面图集，臂/靴单独出图 | 高 | 有；侧视手臂 UV 仍按 bind，会糊 | 旧实验，已被 v5 取代 |
| `ai_ronin_v5` | `male` 高模 | 6 块平面图集 + **Walk 0 纹理姿态** | 高 | 有；但去掉了幽灵手臂/手 | **推荐看侧视 / 完整机械臂** |
| `ai_police` | `police_male` 低模 739 顶点 | **原 UV 不动** | 中高（受 512 底图限制） | **无** | 原 UV 语义图集角色、要干净接缝 |

理想情况是"高模 + 原语义 UV + 分块生成"，但本仓库里的高模 `male` / `naked` 恰好是调色板 UV；
`police_male` / `female_8` 是语义 UV 但都是低模。要再进一步，需要给高模重新展开一套语义 UV
（按身体块切 UV 岛），再把 AI 图/AI 分块图烘焙进去——这是下一步最值得做的方向。

### 7.4 局限

- 底模的轮廓/面数决定了最终形状；`police_male` 只有 900 个三角面，近看会偏块状，
  AI 贴图不能增加几何细节。
- 侧视图的胳膊在绑定姿态下被躯干压缩，烘焙后手臂 UV 岛拿到的是侧视图中该屏幕位置的颜色，
  大幅摆臂时仍可能看起来偏薄。
- 烘焙只在绑定姿态的屏幕空间采样，背面的 UV 岛也会采到正面图；固定正/侧视角没问题，
  如果要做"转身 360°"，需要多视图烘焙或真正的 3D 贴图投影。
- 只适合有语义 UV 图集的角色；`male`/`naked` 不适用。

### 7.5 实验记录：独立手臂 / 新腿图 / 脚部碎裂排查

这轮又用 `gpt-image-2.5-flare` 生成了一批独立部件，并加了一个 `--source custom` 路径，
把外部生成的分块图直接塞回 `ai-skin-parts` 的图集，方便反复试：

- **侧视机械臂**：用文生图生成“isolated right mechanical arm, side view, hanging down”和
  “isolated left arm in jacket sleeve”，替换侧视的 `arm_r` / `arm_l` 分块图。
  之前侧视手臂分块其实是同一张肩甲截图（两臂 UV 重叠），所以小臂/手都是大臂纹理；
  换成独立手臂图后，`ai_ronin_v2` 的侧视能看到完整的机械小臂和金属手。
- **脚**：生成过独立的靴子图、把脚拆成独立 part、重生成整条腿（flare，干净的靴子），
  但正视图右脚趾仍然有撕裂感。把腿图整条刷成纯绿再渲染后发现：
  **撕裂处仍然是背景**——这不是贴图问题，是 `male` 高模脚部网格在这一帧的
  **自交/破洞/蒙皮夹缝**。平涂色时不易察觉，换成高对比 AI 靴子后就显眼了。
  单独给脚换贴图、拆 part 都不能补几何洞；需要补面/重新拓扑脚部，
  或者改用 `police_male` 这种脚部闭合的底模（`ai_police` 的脚就是干净的，但低模）。
- **结论**：侧视机械臂问题已修；脚部碎裂是几何问题，不再继续在贴图上绕。
  下一步要么给高模脚部补一块鞋底/补面，要么给高模重新展 UV 后用原 UV 烘焙。

### 7.6 直接生成“拆好的 parts sheet”试过了：概念图 ≠ 可用的分块模板

按你的思路，我用一条提示词直接生成了一张 **2×3 的独立部件 sheet**：
头 / 躯干 / 机械右臂 / 左袖臂 / 左腿 / 右腿，全部在品红底上分开、不重叠。
单看图非常漂亮，也确实是“拆好的”。

但把它按 2×3 均分裁开、直接映射到网格的 6 个分块 bbox 后，结果并不好：
手臂是悬空的、躯干缺肩、腿和髋部接不上。原因是**这张 sheet 是按“好看的立绘”生成的，
不是按网格的姿态/比例/取景生成的**：

- 网格正视图是 **T-pose**，两只手臂水平展开；sheet 里的手臂是**自然下垂**的竖直手臂，
  把竖直图塞进水平 bbox，比例和方向都不对。
- 躯干 sheet 是“一件夹克”，没有网格 torso 组里的颈口/肩根；腿也没有髋部连接。
- 每个部件的裁剪 bbox 和网格组的 bbox 不是同一套比例，直接线性映射只会把部件拉变形。

所以结论是：

> **“直接生成拆好的部件”本身是对的，但必须按每个网格组的姿态/取景生成，而不是按一张好看的立绘 sheet。**
> 也就是先用 `render-ref.mjs --group <组名>` 渲染该组的绑定姿态参考图，再让 gpt-image-2 只重绘这一组——
> 这正是 `ai-skin-parts.mjs` 的 `--source generated` 在做的事。

如果一定要一张 sheet，需要给它一张**模板**：把 6 个网格组的轮廓/取景框拼成一张控制图，
让 AI 在框内填材质，而不是自由构图。我已经把这张模板拼好并用
`gpt-image-2.5-flare` 跑出来了（`out/front/ai/assets/parts_template_out.png`）：六个部件都在自己的格子里、
姿态也对齐了（T-pose 的水平手臂、两条腿），单看非常漂亮。

但**即使姿态对齐，直接映射到网格仍然会散**：AI 会在格子里重新调整每个部件的比例/轮廓，
而我们的映射只是把“该部件内容 bbox”线性塞进“网格组 bbox”。夹克比网格的肩根窄、腿比髋部短，
结果就是手臂/腿看起来悬空。要真正用一张 sheet，需要 **masked inpainting（只填材质、不改轮廓）**
或按每个网格组的**精确剪影**做非刚性对齐；这已经不是“写一句好提示词”能解决的了。

所以目前可靠的两条路还是：
1. **逐块生成**：每块先用 `render-ref --group` 渲染该网格组的精确姿态参考图，再让 AI 只重绘这一块
   （`ai-skin-parts --source generated`，正视图已经在用）；
2. **原 UV 烘焙**：把整身 AI 图按三角形屏幕坐标烤回原 UV（`ai_police`，没有接缝，但底模低模）。

这轮的侧视最终采用折中：

- 可见的近侧（机械）手臂：单独生成、单独贴图；
- 远侧（被躯干挡住）手臂：全透明，直接不画——之前它会被裁成一块绿色大臂，看起来像
  “胳膊跟着腿走”；
- 头/躯干/腿：用整身侧视 AI 图裁块，保持身体连贯，不再逐块生成导致接缝。

### 7.7 颜色调试：确认机械臂贴在了“会动的那只手”上

为了排除“贴图贴错手臂”的怀疑，我做了一个纯色调试角色：
`head=红, torso=白, arm_l=绿, arm_r=蓝, leg_l=黄, leg_r=青`，逐帧对照动画。

结果：

- **蓝色 `arm_r` 是近侧、可见、会摆动的那条手臂**（帧 10/20 能明显看到肘部弯曲）；
- **绿色 `arm_l` 是远侧手臂**，大部分被躯干挡住，只从腰侧露出一条绿边——之前 HD 侧视把它也画出来，
  看起来就像“绿色大臂贴在腿根”；现在 v2 把它设成全透明隐藏。

对比图：左 = 纯色调试（蓝=arm_r，绿=arm_l），右 = v2 实际渲染：
另外，旧 HD 的侧视两张手臂图都是同一张 100×100 肩甲裁图；现在 **HD 侧视也换成了 v2 的修正映射**，
“AI 精细皮肤”按钮也改成直接打开 v2 侧视，不会再回到旧的那张。机械臂资产也换成了**整条全机械**
（肩关节到金属手指，无布料袖），不再是“上臂绿色、只有小臂金属”。

### 7.8 侧视手臂贴图为什么错：绑定姿态 UV 退化 + 整身裁块串色（v5 修法）

先给结论：**不是 AI 画的手臂不对，也不是骨骼或蒙皮权重坏了，是侧视手臂的 UV 采样姿态错了。**
v2 那张机械臂原图本身是完整的（肩球、肘关节、小臂、五指都在），但贴到网格上后，手指跑到肘部、
小臂糊成一片；腰胯处还多出一只手。这两个现象来自两类错误，但都能用同一套办法修。

#### 根因 1：侧视 T-pose 的手臂指向镜头，投影退化

- `male` 高模的绑定姿态是 T-pose，手臂沿世界 ±X；side 投影是 `sx = z, sy = y`，手臂长度方向正好落在镜头轴上。
- 因此绑定姿态下 `arm_r` 的 2D 包围盒只有约 **0.18 × 0.17**（`x -0.14..0.04, y 1.35..1.52`）：
  整条手臂在屏幕上被压成“肩部一个圆 + 手的一点点”。可用
  `node tools/render-ref.mjs out/side male bind 0 /tmp/arm.png --group arm_r` 亲眼确认。
- 旧逻辑拿这个 bbox 做 `planarUvsForBox`，等于把一张 5:1 的竖手臂图塞进一个近似正方形的框。
  顶点沿手臂方向的差异在屏幕上几乎为 0，UV 也几乎一样；动画把手臂放下来时，整条手臂只能反复采样
  贴图里的一小条，于是出现“手指爬到肘部”“小臂纹理糊成一片”。**换再好的手臂图也救不了。**

#### 根因 2：从整身图裁块，会把相邻的手臂/手一起裁进部件贴图

- 侧视的 `torso` / `leg_l` / `leg_r` 块是从整身 AI 图按各自 bbox 裁的。torso 的 bbox 覆盖了身前的手臂，
  leg 的 bbox 覆盖了腰胯处的手。
- 这些像素本意是“邻居/背景”，但部件的网格在屏幕空间与它们重叠，采样时就把手臂/手画到了躯干和腿上。
  v2 的“腰胯多出一只手”“躯干侧面有第二条胳膊”都是这个来源，不是骨骼多画了一条。
- 这也解释了纯色调试时为什么会“看不见手”：纯色图里手和腿同色，视觉上并进去了；换成高对比 AI 贴图才显眼。

#### 修法：纹理姿态（texture pose）+ 独立部件图

1. **纹理姿态**：侧视两条手臂都改用 `Walk` 第 0 帧求 UV。这一帧手臂已经伸开，`arm_r` 的 2D 包围盒
   `x -0.05..0.37, y 0.82..1.45`，`arm_l` 是 `x -0.20..0.05, y 0.70..1.43`，长度方向都完整。
   其他块仍用绑定姿态。`tools/pose2d.mjs` 复刻运行时/参考渲染器的 2D LBS；`ai-skin-parts.mjs` 新增：

   ```bash
   --pose Walk --pose-frame 0 --pose-groups arm_l,arm_r
   ```

   UV 只是换了“在哪一帧投影”，网格、权重、动画都不动；动画到别的姿势时纹理跟着蒙皮走。
2. **独立部件参考图**：`arm_l` / `arm_r` / `torso` / `leg` 都先用 `render-ref.mjs --group <块>` 渲染只含这一块的参考图，
   再做图生图。这样贴图里不可能混进邻居的手臂/手。
   - 近侧机械臂用 **Walk 0** 的 `arm_r` 单块渲染，提示词锁死“肩球左上、肘在中、五指右下、同姿势同轮廓”；
   - 远侧手臂同样用 **Walk 0** 的 `arm_l` 单块渲染，画成深色夹克袖子 + 黑手套；
   - 躯干用 bind 的 `torso` 单块；腿用 bind 的 `leg_r` 单块（左右腿可共用一张）。
3. **远侧手臂显示**：`arm_l` 不再设成全透明，而是给它单独生成一条深色袖子。深度排序按 3D 深度把它放在
   躯干后面，所以上臂/袖子只在躯干轮廓外露出来，手掌在腰侧可见——侧视能看到两条胳膊，又不会穿到身体前面。
4. 生成后用 `--source custom` 把独立部件图喂回 `ai-skin-parts`，打包成图集；侧视两条手臂用纹理姿态，
   正视图全部用 bind。

#### 复现命令

```bash
export ARUHUB_API_KEY='...'

# 1) 参考图：两条手臂用 Walk 0 的姿态，躯干/腿用 bind（只渲染该块，背景品红方便抠图）
node tools/render-ref.mjs out/side male Walk 0 out/side/ai/parts/ref-arm_r-walk0.png --group arm_r --bg ff00ff
node tools/render-ref.mjs out/side male Walk 0 out/side/ai/parts/ref-arm_l-walk0.png --group arm_l --bg ff00ff
node tools/render-ref.mjs out/side male bind 0 out/side/ai/parts/ref-torso-bind.png --group torso --bg ff00ff
node tools/render-ref.mjs out/side male bind 0 out/side/ai/parts/ref-leg-bind.png  --group leg_r --bg ff00ff

# 2) 用 POST /v1/images/edits 生成独立部件图（提示词见下），抠图后另存为：
#    out/side/ai/parts/ai_ronin_v5-<group>-side.png
#    arm_r = 机械臂，arm_l = 深色夹克袖子 + 黑手套；head 可继续用 v2 的整身裁块
# 3) 侧视：两条手臂都换纹理姿态
node tools/ai-skin-parts.mjs --char male --name ai_ronin_v5 --views side --source custom \
  --pose Walk --pose-frame 0 --pose-groups arm_l,arm_r

# 4) 正视图仍用 bind；把 v2 的正视分块图复制成 ai_ronin_v5-*-front.png 后：
node tools/ai-skin-parts.mjs --char male --name ai_ronin_v5 --views front --source custom
```

#### 这次实际用的提示词要点

机械臂（`gpt-image-2` + `images/edits`，参考图 = Walk 0 的 `arm_r` 单块）：

```text
Repaint the isolated arm in the reference image as a fully mechanical cybernetic RIGHT arm.
Keep the EXACT same pose, arm angle, elbow position, hand position, silhouette and full-arm framing:
shoulder ball joint at upper left, slightly bent elbow in the middle, articulated five-finger hand at lower right.
Brushed chrome and dark teal armor plates, orange glowing seams, articulated fingers, exposed pistons.
No body, no torso, no head, no extra arm, no weapon, no text, no frame.
Solid flat chroma-key magenta background (#FF00FF), one isolated arm centered.
```

远侧左臂（`gpt-image-2` + `images/edits`，参考图 = Walk 0 的 `arm_l` 单块）：

```text
TASK: paint ONLY the isolated LEFT ARM (shoulder to gloved hand).
Dark teal jacket sleeve with subtle orange piping, black glove, normal human hand.
No torso, no head, no legs, no mechanical parts.
The arm must fill the frame vertically, same pose and orientation as the reference.
Keep the exact same silhouette, proportions, pose and orientation as the reference body part.
Solid chroma-key magenta background (#FF00FF), one isolated arm centered.
```

躯干：强调 `lean adult MALE`、`flat chest`、`no sleeve / no arm hole / no arms`；
腿：强调 `only ONE leg, no hand, no arm, no torso`；
所有部件都要求 `same silhouette / proportions / side profile as the reference` + 品红底 + 单件居中。
图生图比文生图更容易保住原网格的姿势和比例；`gpt-image-2.5-flare` 也能用，但姿态跟随后处理要重新检查。

> 这次实际选的是 **flat chest** 那版：AI 在肩窝处画了一个圆洞，但侧视近侧机械臂的肩球正好把它盖住，
> 正面看没问题。如果换一个露肩的姿势，洞可能会露出来，需要重生成或给肩部补一块面。
> 另一版没有洞，但胸型偏女性；在“男性体型”和“无洞”之间，这次优先保了男性体型。

#### 结果与取舍

- v5 侧视的近侧机械臂从肩到五指是一条完整纹理，行走/待机帧不再出现“肘部手指”；腰胯的多余手也消失
  （腿图里不再有手，躯干图里不再有手臂）。
- 远侧手臂也单独生成了一条深色夹克袖子 + 黑手套，侧视两条胳膊都能看到；被躯干挡住的部分由深度排序
  自然隐藏，只在躯干轮廓外露出袖子和手套，不会穿到身体前面。
- v5 也能照常导出龙骨：`node tools/export-dragonbones.mjs --data out/side --out out/side/dragonbones
  --extra out/side/characters-ai.json --chars ai_ronin_v5`，`verify-dragonbones.mjs` 实测 Walk 51 帧
  骨骼最大误差 3.09e-4、顶点最大误差 3.11e-4，图集 2014×2008 正常加载。
- 代价：纹理姿态只保证在 **Walk 0** 对齐；`Sword_Attack` 这类肘部大幅弯曲的动作仍会有平面贴图的拉伸。
  要彻底解决肘部，需要把上臂/前臂/手拆成三段、每段一个 UV 格（limb UV），而不是整条手臂一张图。
- 躯干、腿是单独图生图的，和正视图的对应块不一定 100% 同色；这是分块 AI 皮肤的固有接缝问题。

#### 一句话回答

> **思路没错，错在侧视手臂的 UV 采样姿态。** T-pose 绑定姿态下手臂正对镜头，屏幕投影没有长度；
> 必须换到手臂伸开的帧（纹理姿态）求 UV，并且部件贴图要单独出图，不能从整身图裁。

对比图（左 = v2，右 = v5）：
### 7.9 Q 版卡通角色（ai_chibi）

同一套骨架 / 权重 / 动画，换一套 **卡通 Q 版** 贴图，并把头部网格放大 2 倍。
`ai-skin-parts.mjs` 为此加了几个开关：

| 参数 | 作用 |
|---|---|
| `--style chibi` | 用 Q 版 CHARACTER BIBLE / 分块提示词：大头、大眼睛、粗描边、亮色、圆润机械臂 |
| `--head-scale 2` | 只把 `head` 组顶点绕 `head` 骨骼原点放大 2 倍；UV / 权重 / 骨骼 / 动画都不动 |
| `--hide arm_l` | **可选**：某块全透明、不调 API（例如不想要远侧手臂时） |

命令（侧视 6 次生成，正视图 6 次；`--reuse` 可复用已有 ref/raw）：

```bash
export ARUHUB_API_KEY='...'

# 侧视：arm_l / arm_r 都用 Walk 0 纹理姿态；头部 2x
node tools/ai-skin-parts.mjs --char male --name ai_chibi --views side \
  --source generated --style chibi --model gpt-image-2 \
  --pose Walk --pose-frame 0 --pose-groups arm_l,arm_r --head-scale 2

# 正视图：T-pose，六块全生成；头部 2x
node tools/ai-skin-parts.mjs --char male --name ai_chibi --views front \
  --source generated --style chibi --model gpt-image-2 --head-scale 2

# 正视图（Q 版按钮打开这个）
# http://127.0.0.1:8899/web/index.html?view=front&char=ai_chibi&clip=Walk&frame=0&play=0&bones=0
```

> 第一版为了避开“远侧手臂被躯干挡住只剩一条边”的问题，把 `arm_l` 设成全透明；
> 后来发现侧视只能看到近侧机械臂，另一条胳膊完全消失，观感更怪。
> 现在改成 **给 `arm_l` 也单独生成一条米白袖子**，同样用 Walk 0 纹理姿态，
> 深度排序会把它放在躯干后面：大部分被挡住，但上臂/袖子/手套会在腰侧露出来，侧视就能看到两条胳膊。
> 如果某个动作里远侧手臂实在碍眼，仍可以临时加 `--hide arm_l` 关掉。

#### Q 版提示词要点

`--style chibi` 的 BIBLE：

```text
cute chibi cyberpunk street kid. Big head, huge expressive amber eyes, tiny nose, small smile, rosy cheeks,
spiky mint-green hair, chunky orange goggles pushed up on the forehead, warm light skin.
Oversized cream and teal bomber jacket with hot orange trim, black shorts,
chunky orange-and-teal sneakers.
LEFT arm: puffy cream jacket sleeve with orange stripe, big rounded mitten hand.
RIGHT arm: cute chunky mechanical arm, rounded teal and chrome plates, orange glowing joints,
big rounded three-finger mitten hand.
Thick clean cartoon outlines, cel-shaded flat colors, bright neon palette.
```

每个块仍是“只画这一块”：
- 头：`HUGE amber eyes (about one third of the face)`、小鼻子、腮红、薄荷绿刺猬头、橙色护目镜；
- 躯干：米白 + 青绿飞行夹克、大拉链、胸章、粗腰带，不要头/手臂/腿；
- 左臂：蓬松米白袖子 + 大圆手套；
- 右臂：圆润的青绿/铬色机械臂、橙色发光关节、三指大手套；
- 腿：宽松青绿工装裤、圆护膝、**薄橙底 + 高帮鞋面**的大运动鞋。

前视图的脚是**朝镜头**的，平面 UV 会把鞋面压得很扁；第一版用了厚橙底，渲染出来像“鸭蹼”。
第二版把提示词改成 **thin orange sole + tall cream/teal upper**，并把鞋面画满底部取景，渲染出来才像高帮鞋。
这是平面投影的固有限制，换更极端的脚部动作仍可能拉伸。

#### 头部 2x 是怎么实现的

`--head-scale` 在网格拼好、UV 算完之后执行：

```text
pivot = head 骨骼绑定姿态的全局原点
head 组每个顶点：v' = pivot + (v - pivot) * 2
```

- 只影响 `head` 组的 209 个顶点，头部贴图跟着几何拉伸（仍在同一块 UV 岛里）；
- 权重、骨骼、动画、逐帧深度都不改，所以同一套 Walk / Idle / Sword_Attack 直接能播；
- 头变大后总高度变高，运行时会按 `meshBounds` 自动重新取景；
- 龙骨导出同样正常：`ai_chibi` 侧视实测 Walk 51 帧，骨骼/顶点误差 < 1.1px（300px=1m）。

#### 结果与取舍

- 正视图：大头、琥珀大眼、薄荷绿刺猬头、橙色护目镜、米白/青绿飞行夹克、机械右臂、工装裤 + 高帮鞋，Q 版味道够了。
- 侧视图：头部 2x，近侧机械臂完整，远侧米白袖子和手套也能看到（被躯干挡在后面的部分自然隐藏）；
  走路时大头、两条胳膊和机械臂的轮廓都很清楚。
- **身体比例仍是成人**：只放大了头，没有缩短腿/躯干，所以是“大头卡通”而不是严格 3 头身 Q 版。
  要真正 3 头身，需要同时改骨骼长度 + 网格（非均匀重定向），这是下一步工作量更大的方向。
- 正/侧视图是两套独立生成的贴图，配色一致但细节不可能逐像素相同；分块边界仍是硬接缝。
- 头部贴图被拉伸 2 倍，近看会软一点；要更清晰可以把 head 单独生成到更大尺寸/单独一张图。
### 7.10 图在哪、是一块一张还是整张、怎么拿它当模板

#### 文件在哪

以 `ai_chibi` 侧视为例：

```text
out/side/ai/parts/ref-ai_chibi-<group>-side.png     # 768x768，纯几何参考图（灰底），最适合当模板
out/side/ai/parts/raw-ai_chibi-<group>-side.png     # 1024x1024，GPT 原图（品红/白底）
out/side/ai/parts/ai_chibi-<group>-side.png         # 抠图/裁边后的透明部件图
out/side/ai/ai_chibi-atlas-side.png                 # 最后打包的 3x2 图集（运行时用）
out/side/ai/ai_chibi-side.json                      # 每块的 atlasFrame / pose / chibi 元数据
out/side/characters-ai.json                         # 角色定义（指向图集）
```

正视图全部在 `out/front/ai/parts/`。`<group>` 是 `head` / `torso` / `arm_l` / `arm_r` / `leg_l` / `leg_r`。
`out/` 已被 git 忽略，所以这些图只在本地，不会提交进仓库。

#### 是一块一张，不是整张 sheet

**当前 v5 / ai_chibi 的管线是每个部位单独生成一张 1024x1024**，AI 从来没有看到过 3x2 拼图：

- 侧视 6 块：`head / torso / arm_l / arm_r / leg_l / leg_r`；
- 正视图 6 块；
- 每块先用 `render-ref.mjs --group <group>` 渲染该块的几何参考图，再 `images/edits`；
- 最后 `packAtlas()` 把 6 张部件图缩放进 650x980 的格子，拼成 **2014x2008** 图集。

历史上的 `out/side/ai/assets/parts_sheet.png`、`parts_template_out.png` 是“一张 2x3 sheet”实验，
不是当前管线；docs 7.6 记录过：一张 sheet 直接按格子切开再贴，AI 会改每个部件的比例/轮廓，
手臂会悬空、腿接不上，所以后来改成一块一张。

#### 提示词结构

每个块发给 GPT 的 prompt 是四段拼起来的（`tools/ai-skin-parts.mjs:287`）：

```text
BIBLE + PART_PROMPT[group] + VIEW_HINT[view] + COMMON
```

- `BIBLE`：整套角色必须一致的部分（发色、服装、左右臂设定、画风）；
- `PART_PROMPT[group]`：只画这一块，并明确“不要头/不要躯干/不要另一条腿”；
- `VIEW_HINT`：`front = strict front T-pose` / `side = strict side profile facing right`；
- `COMMON`：锁轮廓、锁姿势、不要道具、品红底、单件居中。

`--style chibi` 的 BIBLE 和六段 PART_PROMPT 在 [`tools/ai-skin-parts.mjs`](tools/ai-skin-parts.mjs#L124-L167)；
`cyberpunk` 默认风格在 [`tools/ai-skin-parts.mjs`](tools/ai-skin-parts.mjs#L91-L122)。
侧视手臂用 `--pose Walk` 时，参考图是“手臂已经放下/伸出”的，提示词里“horizontally”是按正面 T-pose 写的，
实际以参考图姿势为准；要自己写风格时，最好把方向写成占位符（按 view/pose 替换），或者分两套 prompt。

#### 拿现有图当模板自己画

**最推荐的模板是 `ref-*.png`**：它是该块网格的精确姿态/轮廓，灰底，没有当前角色的花纹。
在它上面描线、上色，再把参考图的橙色/灰底去掉，导出透明 PNG。

1. 选一个视角，拿这 6 张参考图当底：
   ```text
   out/side/ai/parts/ref-ai_chibi-<group>-side.png
   out/front/ai/parts/ref-ai_chibi-<group>-front.png
   ```
   侧视的 `arm_l` / `arm_r` 参考图是 **Walk 0** 姿态（手臂伸开），不是 T-pose。
2. 每个部位画一张透明 PNG，存成：
   ```text
   out/side/ai/parts/<myname>-<group>-side.png
   out/front/ai/parts/<myname>-<group>-front.png
   ```
   背景透明；部件内容尽量填满参考图的轮廓，别加披风/武器/帽子改变包围盒。
3. 重建：
   ```bash
   # 侧视：两条手臂用 Walk 0 纹理姿态
   node tools/ai-skin-parts.mjs --char male --name myname --views side --source custom \
     --pose Walk --pose-frame 0 --pose-groups arm_l,arm_r

   # 正视图：T-pose
   node tools/ai-skin-parts.mjs --char male --name myname --views front --source custom

   # 可选：Q 版大头
   #   --head-scale 2
   ```

**注意**：`planarUvsForBox` 是把“图片内容包围盒”线性映射到“网格块包围盒”。如果新画的角色轮廓/比例
和参考图差很多，会被拉伸或偏移；加披风、长武器、大帽子会改变包围盒，更容易错位。
真要换轮廓，需要重做网格/UV/权重，不是换贴图能解决的。

#### 让 AI 图生图基于模板生成其他角色

可以，而且就是现在的 `--source generated` 在做的：

```bash
# 用 ai_chibi 的参考图 + chibi 风格的 prompt，生成一个新角色（先只跑侧视试）
node tools/ai-skin-parts.mjs --char male --name mychar2 --views side \
  --source generated --style chibi --model gpt-image-2 \
  --pose Walk --pose-frame 0 --pose-groups arm_l,arm_r --head-scale 2
```

- `ref-*` 是图生图的输入；`raw-*` 是 AI 返回图；`--reuse` 复用已有 ref/raw，只重跑缺的块；
- **注意**：`--source generated` 的图生图输入是 `ref-*` 几何参考图，不是已经生成的成品皮。
  想拿 `ai_chibi-<group>-<view>.png` 这种成品皮当风格参考，直接调用 `generateEdit`，
  把 `refPath` 指向成品图（透明底建议先合成到纯色/品红底），生成后存成
  `<myname>-<group>-<view>.png`，再走 `--source custom`；
- 想换主题，复制 `STYLES.chibi` 改一套 `BIBLE` / `PART_PROMPT` / `COMMON`，加一个 `mystyle`，
  再用 `--style mystyle`；
- 也可以直接调用 `tools/aruhub.mjs` 的 `generateEdit({ refPath, prompt, rawPath })`，
  自己控制每块的提示词；
- AI 容易改比例/加道具。每次生成后检查 `raw-*` 和最终渲染；只要内容包围盒比例和参考图差太多，
  就会在网格上拉伸。必要时要重新生成该块，而不是硬贴。

#### 能不能用最终那张 3x2 图集当模板？

技术上可以，但不推荐：

- 图集里的每块已经被 `packAtlas` **缩放**到 650x980 的格子里，部件在格子中居中、带透明边；
- 网格 UV 指向的是 `atlasFrame`（在 `ai_chibi-side.json` 里），不是整个格子；
- 直接在整张图集上画，需要严格按每块的 `atlasFrame` 比例，并且不能改变各块的相对大小/位置，
  比在 `ref-*` 上画更容易错。
- 如果你想要“一张 sheet 画完再切”，需要额外的切图脚本，并且每格必须和对应 `ref-*` 的姿态/取景一致。
  当前工具只吃“一块一张”的文件；要加 sheet 导入可以再写一个 `--sheet` 模式。

单张整身图仍然有另一条路：`tools/ai-skin.mjs`（一张全身图 + 整身平面 UV），
但侧视手臂会有 7.8 说的退化问题，适合快速试风格，不适合精细分块。

### 7.11 手绘模板包与导入工具

仓库里已经带了一套可直接描线的模板，生成物在 `templates/`（**已入库**，不是 `out/`）：

```text
templates/
  side/
    template-<group>.png   1024x1024，透明底 + 品红轮廓
    canvas-<group>.png     1024x1024，全透明画布
    sheet.png              3072x2048，3x2（head/torso/arm_l/arm_r/leg_l/leg_r）
    README.md
  front/
    ... 同上
```

![手绘模板 sheet](../templates/side/sheet.png)

#### 画 / 导入

1. 打开 `template-<group>.png`，在上层新建图层描线；品红只是 guide，导入时会被剥掉；
2. 尽量画在轮廓内，保持同样姿势/朝向/取景；
3. 整张 3x2 画完存 `sheet.png`，或分块存 `<myname>-<group>-<view>.png`；
4. 导入：

```bash
# 整张 sheet
node tools/import-part-drawing.mjs --view side --sheet templates/side/sheet.png --name mychar

# 或 6 张分块图
node tools/import-part-drawing.mjs --view side --dir mydrawings --prefix mychar --name mychar

# 正视图
node tools/import-part-drawing.mjs --view front --sheet templates/front/sheet.png --name mychar

# Q 版大头
node tools/import-part-drawing.mjs --view side --sheet templates/side/sheet.png --name mychar --head-scale 2

# 只写部件，不构建
node tools/import-part-drawing.mjs --view side --sheet templates/side/sheet.png --name mychar --no-build
```

导入工具会做：

- `sheet`：按 3x2 等分，顺序 `GROUP_ORDER`；
- 剥掉品红 guide（`--keep-guide` 可关）；
- 去背景/裁边，写到 `out/<view>/ai/parts/<name>-<group>-<view>.png`；
- 调 `ai-skin-parts --source custom` 构建 `<name>`。

侧视默认加 `--pose Walk --pose-frame 0 --pose-groups arm_l,arm_r`（模板手臂就是 Walk 0）；
正视图不需要 pose。`--head-scale` 会传给构建步骤。

#### 重新生成模板

```bash
node tools/make-templates.mjs --views side,front --size 1024
```

它用 `render-ref.mjs` 渲染 `male` 基础网格的 6 块几何参考图：侧视 `arm_l`/`arm_r` 用 `Walk 0`，
其他块用 `bind`；正视图全部 `bind`。然后生成品红 guide、透明 canvas、3x2 sheet 和每视角的 README。
模板包（含 `base-male.json` / `pose-walk0.json`）约 2.2MB，直接入库；`out/` 里的 AI 图仍然不入库。

#### 限制

- 平面 UV 是“图片内容包围盒 → 网格块包围盒”的线性映射：**画在轮廓内**最稳；
  加披风/长武器/大帽子会改变包围盒，贴上去会拉伸或错位。
- 侧视手臂必须用 Walk 0 的姿势；如果你在 T-pose 模板上画侧视手臂，导入时不要加 `--pose`，
  但侧视 T-pose 手臂在 2D 里是退化的（见 7.8），效果不会好。
- 换身体比例（短腿、矮身）需要重做网格/权重/骨架，`--head-scale` 只能放大头。
- 模板基于 `male` 基础网格；其他底模/骨架要先用 `make-templates` 重新渲染。
- 品红/粉紫会被当成 guide 剥掉；角色本身要用这类颜色时，先删 guide 图层，导入时加 `--keep-guide`。

完整操作说明见 [`templates/README.md`](../templates/README.md)。

### 7.12 可视化导入器（本地 Web 界面）

命令行导入之外，还有一个零依赖的本地 Web 界面：

```bash
node tools/import-ui-server.mjs
# 手绘皮肤导入器: http://127.0.0.1:8898/
# 端口可改：IMPORT_UI_PORT=8900 node tools/import-ui-server.mjs
```
界面做这些事：

- **输入**：3×2 sheet 拖拽/选择，或切到“6 张部件图”逐块上传；
- **预览**：先调 `import-part-drawing.mjs --no-build`，把 6 块处理结果（透明底、剥掉品红 guide）
  显示出来，确认没问题再构建；
- **选项**：角色名、侧视/正视图、头放大 1×/1.5×/2×、保留品红、允许覆盖同名角色；
- **构建**：调 `ai-skin-parts --source custom`，显示图集、演示页链接和完整日志；
- **安全**：默认不允许覆盖已有角色；只有勾选“允许覆盖同名角色”才写同名角色。

它复用的是命令行工具，**不调 AI 接口、不上传云端**，所有文件都在本机 `out/`。
演示页工具栏也加了 **“手绘导入 ↗”** 按钮，打开同一个界面。

启动后可以这样试：

1. 打开 `http://127.0.0.1:8898/`；
2. 下载/打开 `templates/side/sheet.png`，画完保存 PNG；
3. 拖进页面 → “预览 6 块” → 看处理结果 → “构建角色”；
4. 点结果里的“打开演示页”。

服务只绑定 `127.0.0.1`，不要暴露到公网；它没有登录/权限系统。

#### 不用服务也能用：静态 / 离线模式
页面也能在没有 `import-ui-server` 的情况下工作。用任意静态文件服务器从工程根目录打开：

```bash
python3 -m http.server 8898
# http://127.0.0.1:8898/web/import.html
```

页面会检测不到服务标记，自动进入 **离线模式**：

- 在浏览器里完成拆分、剥品红、抠图、3x2 图集打包和角色 JSON 生成；
- 点“构建并下载”后得到两个文件：
  - `<name>-atlas-<view>.png` → 放进 `out/<view>/ai/`
  - `characters-ai.json` → 覆盖到 `out/<view>/`
- 如果你的静态服务器能读到 `out/<view>/characters-ai.json`，会自动把现有 AI 角色合并进去；
  读不到会提示“只含新角色”，覆盖前先备份。
- 离线构建依赖 `templates/<view>/base-male.json` 和 `templates/side/pose-walk0.json`
  （由 `make-templates` 生成，已入库）。只支持 `side` / `front` 和 `male` 基础网格。

注意：`file://` 直接双击会被浏览器 CORS 拦住（读不到 `templates/` / `out/` JSON），
请用静态服务器打开。静态模式不需要 Node 后端、不调 AI、不联网。

### 7.13 AI 皮肤生成器页面（只填角色描写）

除了“手绘导入”，还有一个直接调 **OpenAI 兼容图片 API** 的生成页面（API 地址由用户填）：

```text
静态服务器：http://<host>/.../web/generate.html
推荐：python3 -m http.server 8898 → http://127.0.0.1:8898/web/generate.html
Node 服务：http://127.0.0.1:8898/generate.html
```
#### 只填这些

- **API 请求地址**（OpenAI 兼容，如 `https://api.openai.com/v1` 或你自己的代理）
- **API Key**
- **角色描写**：性别/体型、头发/眼睛/肤色、衣服/配色、左/右臂是否机械、鞋/配饰
- **风格**：Q版 / 写实（两套独立提示词，见下）
- **视角**：侧视 / 正视图
- **部位**：head / torso / arm_l / arm_r / leg_l / leg_r，或“全部 6 块（依次）”
- **模型**：gpt-image-2 / 2.5-flare / 2.5-sunburst / 2.6-flare / 2.6-sunburst

其他提示词全部内置在 [`web/generate.js`](../web/generate.js)：

```text
CHARACTER DESIGN:
<你填的角色描写>

STYLE:
<Q版 或 写实 风格段>

<当前部位的 PART_PROMPT>
<VIEW_HINT>
<COMMON>
```

- **Q版 / 写实是两套独立风格提示词**：`STYLE_PRESETS.chibi` / `.realistic`，不会混用；
- **6 个部位各有独立 PART_PROMPT**：只画这一块，明确 `No torso / No head / No legs / No other leg`；
- **骨骼/姿势不在文字提示词里**：由 `templates/<view>/ref-<group>.png` 这张几何参考图锁定；
- **不绑定服务商**：页面请求 `<你填的地址>/images/edits`，可以是 OpenAI、AruHub 或其它兼容代理；不是 Google Imagen；
- 角色描写是唯一的“设计变量”，其余都是默认模板。

#### 生成流程

1. 页面加载 `templates/<view>/ref-<group>.png`（768×768 的平涂几何参考图）；
2. `fetch` 直接调 `<你填的地址>/images/edits`，`FormData` 里放 ref + prompt；
3. 返回 `b64_json` / `url`，页面显示 raw 图；
4. 用 `OfflineBuild.processImage` 去背景、裁边，显示透明图；
5. 单个部位可下载；选“全部”会按 `head → torso → arm_l → arm_r → leg_l → leg_r` **依次**生成 6 张
   （每张约 20–60 秒；实测 6 张约 2–3 分钟）；
6. 下载 6 张透明图，去 [手绘导入 / 构建](../web/import.html) 上传后构建角色（或继续用命令行）。
#### 重要限制

- **Q版/写实只改“画风”**，不改网格比例。Q版的大头要在构建时加 `--head-scale 2`，
  页面本身只生成贴图；真正的短腿/矮身需要重做网格/权重。
- 6 块是独立生成的，颜色/缝线/材质会有差异（截图里的头和身体就能看出来）；不满意请单独重生成。
- 没有 seed、mask、多视图参考；一致性靠角色描写 + 各自 ref + 逐块检查。
- API Key 在浏览器内存；勾选“记住本标签页”才写 `sessionStorage`，不经过本项目服务器。
  页面直接请求你填的 API 地址；如果网络/CORS 失败，用服务端代理或命令行。

### 7.14 右臂摆动时肩膀被扯：torso 块上臂权重距离衰减

#### 现象

所有动画里右臂一摆，右肩/胸口那块蒙皮被拉成三角形，跟着大臂一起走。
最明显的是 `ai_ronin_v5` / `ai_chibi` 的 `Walk`、`Sword_Attack`、`Punch_Jab`，正/侧视都有。

#### 根因

不是 AI 贴图错位，也不是骨骼动画本身错；是**源模型的上臂权重覆盖到了躯干肩部**：

- 3D 源模型（Mesh2Motion 自动蒙皮）在肩窝/肩胛附近有 `upperarm_l/r` 权重；
- `splitMeshGroups()` 按主导骨把三角形分到 `torso` 块，但这些三角形的**顶点**仍带着 `upperarm` 权重；
- 右臂摆动 → 这些 torso 顶点跟着 `upperarm` 走 → 胸口贴图被拉长；
- 侧视里锁骨/上臂又高度重叠，视觉上就是“肩膀被右臂扯着走”。

验证过程：

1. 先怀疑 `clavicle_r` 的 2D 投影不稳定；把锁骨轨道冻结后胸口确实不拉了，但**手臂姿势也变了**
   （远侧手臂会抬起来）——说明锁骨在链上，不能直接冻结。
2. 改成只动权重：把 torso 块里离肩关节较远的 `upperarm` 权重按距离衰减，
   手臂链/动画完全不动；胸口稳定，右臂姿势不变。
3. 对比原始/修复后的 `Sword_Attack`：
左：修复前，胸口被拉出长三角形；右：修复后，胸口轮廓稳定，手臂姿势不变。

#### 工具

[`tools/fix-shoulder-weights.mjs`](../tools/fix-shoulder-weights.mjs)：

```bash
# 处理 out/side、out/front 的 characters.json + characters-ai.json
node tools/fix-shoulder-weights.mjs --views side,front

# 调半径（默认 r0=0.03, r1=0.09，单位是 2D 世界坐标）
node tools/fix-shoulder-weights.mjs --views side --r0 0.03 --r1 0.09

# 已经打过标记仍要重跑（不推荐，会二次衰减）
node tools/fix-shoulder-weights.mjs --views side --force
```

算法：

```text
对每个 torso 块的顶点 v：
  对每根 upperarm_l/r：
    d = |v - upperarm 绑定姿态原点|
    keep = clamp((r1 - d) / (r1 - r0), 0, 1)
    把 w_upperarm 从 w 降到 w * keep
    削掉的 (w - w*keep) 加到 spine_03
  重新归一化到 4 根骨
```

- 离肩关节近（`d <= r0`）保留全部上臂权重，肩窝还能跟着手臂；
- 离得远（`d >= r1`）全部转给 `spine_03`，胸口不再被拉；
- 中间平滑过渡，避免硬切出洞；
- 只处理 **torso 块**，arm/head/leg 块不动；
- 修复前先把三角分组固化到 `partGroups`：权重一改，“主导骨”会变，肩部边界三角形可能跳到别的块，
  模板/ref/贴图会多出尖刺。`ai-image.mjs` 和 `web/offline-build.js` 都优先用 `partGroups`；
- 每个角色写入 `shoulderFix` 标记，重复执行会跳过；
- 新构建的 AI 角色会从修过的 base 深拷贝 `shoulderFix`，不会二次衰减。

`tools/bake-all.sh` 已接入：每次转换后先修权重，再导出龙骨。

#### 验证

- 侧视 12 个动画逐帧抽查（Walk/Jog/Sprint/Jump/Sword/Punch/Dance/Roll/Zombie/Pistol/Crouch/Idle），
  右肩/胸口不再被拉；手臂姿势与修复前一致：
- 正视 `Walk/Sword_Attack/Punch_Jab/Pistol_Shoot` 抽查，肩部正常；
- 重新导出 DragonBones 后官方运行时校验通过：
  `ai_ronin_v5` / `ai_chibi` 侧视、`ai_ronin_v5` 正视，骨骼/顶点误差 < 1.5px；
- 基础 `male` 和其他 AI 角色也一起修了权重（同一套 torso 块逻辑）。

#### 注意

- 这是**权重修复**，不是改骨骼/动画；所有动画共用修后的权重。
- 极端姿势下远侧手臂的**肩窝缝隙**可能仍在（那是 arm 块与 torso 块的硬接缝/几何缺口），
  和“胸口被拉走”不是同一个问题；需要的话再给肩窝补一块过渡几何。
- 重新烘焙（`bake-all.sh`）会自动再修；如果只重新生成了 AI 角色、没重烘 base，
  新角色从已修的 base 构建即可；旧角色可重跑工具（必要时 `--force`）。
- `out/` 不入库；工具、`bake-all.sh`、文档入库。

### 7.15 跑步时右肩“被拉走”：侧视躯干肩窝黑洞

7.14 修的是 **torso 被 upperarm 权重拖动**；跑步时还有一个**贴图层**的问题：

- 侧视 `torso` 是从“没有手臂的 torso 参考图”生成的，AI 把肩窝画成了一整块黑色；
- 手臂前摆时，机械肩球让开，**黑色肩窝**露出来；
- 看起来就像右肩皮肤被手臂拉走/拉破。

这不是权重能修的：把 torso 权重再削，肩窝黑洞仍然在（它只是贴图上的黑色区域）。
当前 `ai_ronin_v5` 侧视已经补成**暗色机械内衬 + 金属圈**，看起来像肩窝接口，而不是破洞：
工具：

```bash
# 补当前 out/side/ai/parts/ai_ronin_v5-torso-side.png 的肩窝
node tools/patch-shoulder-socket.mjs

# 补完直接重建 ai_ronin_v5（side / custom / Walk 0 手臂姿态）
node tools/patch-shoulder-socket.mjs --rebuild

# 换角色/换图时自己量中心与半径
node tools/patch-shoulder-socket.mjs --file out/side/ai/parts/<name>-torso-side.png   --name <name> --center 82,228 --radius 64 --rebuild
```

- 只改**侧视 torso 贴图**；不动骨骼、动画、权重；
- 正视图 torso 没有这个黑洞，不用补；
- `ai_chibi` 的 torso 是完整夹克，也没有这个洞；
- 重建后要重新导出龙骨（`export-dragonbones.mjs`），当前 v5 已重导并通过校验。

**以后生成新角色时**：侧视 torso 的参考图本身缺手臂，AI 容易把肩窝涂黑。
生成后先跑一下跑步动画看肩窝；黑了就用这个工具补，或者把 torso 参考图的肩窝先填成中性色再生成。

### 7.16 跑步时右肩皮肤向前移动/变形：冻结右后肩的 clavicle 权重

现象：跑步右臂前伸时，右肩那块夹克肩皮**明显向前移动**，看起来被拉变形，不是正常肩部。

根因不是 7.15 的肩窝黑洞，也不是“肩皮粘住”。7.14 已经削掉了 torso 的 `upperarm` 权重，
但右后肩 panel 还带着 **`clavicle_r`** 权重；跑步时锁骨跟着手臂转，把这块肩皮带着向前走。
之前试过把 panel 权重转给 `upperarm_r`（让肩皮跟着大臂），结果前移更明显，已回退。

正确修法：只把**右后肩 panel**的 `clavicle_r` 权重冻结到 `spine_03`，让肩皮留在躯干上；
`upperarm`、胸口、脖子不动：

```text
box: x -0.30..-0.02, y 1.40..1.56（侧视右后肩）
每个 box 内 torso 顶点：
  clavicle_r 权重 → spine_03
  其余不变，归一化
```

```bash
node tools/fix-shoulder-panel.mjs --data out/side --name ai_ronin_v5
```
左：肩皮被锁骨带着前移；右：clavicle 权重冻结到 spine_03，肩皮留在原位。

- 当前 `ai_ronin_v5` 已应用（40 个顶点），并重新导出/校验龙骨；
- 7.15 的肩窝 socket 仍然保留，补的是另一层；
- 只适合侧视右肩；换角色/视角要重量 `--box`；
- 这个脚本不改变骨骼/动画，只改 v5 的侧视权重；
- 如果肩皮还动，先确认它是不是 `torso` 块：`--box` 里可能没盖到，或者它属于 arm 块（那要另做肩盖/重分组）。

### 7.17 Q版 ai_chibi 的右肩衣服扭曲

用户给的截图是 **Q版 `ai_chibi`**，不是 v5。跑步/Jog 时右肩那块奶油色夹克面板被骨骼拉成
三角形，看起来衣服扭曲；和 7.16 是同一类问题，但 Q版 torso 的肩皮同时带 `clavicle_r`
和 `upperarm_r` 权重。

修法：Q版侧视右后肩 box 内，把 `clavicle_r + upperarm_r` 权重一起冻结到 `spine_03`：

```bash
node tools/fix-shoulder-panel.mjs --data out/side --name ai_chibi --both
```
左：奶油色肩皮被拉成三角形；右：冻结后肩皮平滑，手臂姿势不变。

- 当前 `ai_chibi` 已应用（55 个顶点），并重新导出/校验龙骨；
- v5 用 7.16 的 clavicle-only，Q版用 `--both`；
- box 还是 `x -0.30..-0.02, y 1.40..1.56`；Q版头部放大不影响 torso 坐标；
- 只改侧视权重，不改骨骼/动画；正视图没有这块侧视肩皮。

### 7.18 皮肤工作室：生成 + 导入整合，单文件无需服务

新入口：[`web/studio.html`](../web/studio.html)
- 两个 tab：**AI 生成** / **导入 / 构建**；
- 生成完 6 块后点“用这 6 块去导入/构建”，会自动切到导入 tab 并填好 6 个槽位
  （视角/风格/头放大一起带过去），再“预览 → 构建并下载”；
- 生成页和导入页仍然可以单独打开。
#### 不需要任何服务

导入/构建用到的数据已经打包进 [`web/studio-data.js`](../web/studio-data.js)：

- `templates/<view>/base-male.json`
- `templates/side/pose-walk0.json`
- `templates/<view>/ref-<group>.png`（12 张）

所以页面**不需要 fetch 本地 JSON/PNG**，直接双击 `web/studio.html` 就能用：

```text
file:///.../web/studio.html
```

- 导入：选 sheet/6 块 → 预览 → 构建并下载；已有 `characters-ai.json` 可以通过文件选择框合并；
- 生成：只需联网 + API 地址/Key，不启动本地服务（直接请求你填的地址）；
- 生成和导入的脚本/字体/数据都是相对路径，放在同一目录即可。

#### 已验证

- `file://` 下导入 sheet → 预览 → 构建 → 下载，控制台无报错；
- `file://` 下选择现有 `characters-ai.json` → 合并 6 个角色 → 构建，正常；
- `file://` 下生成单块 head：54 秒；全部 6 块：218 秒；
- 6 块生成后点 handoff → 导入页收到 6 块 → 预览 → 构建并下载，全流程无报错；
- 通过 Node 服务打开 `http://127.0.0.1:8898/studio.html` 也可以；studio 的导入 iframe 会强制离线，
  不会误走 `/api`。

#### 维护

模板/ref/base 改了之后要重新生成嵌入数据：

```bash
node tools/make-studio-data.mjs
```

`web/studio-data.js` 约 1.85MB（base/pose/refs 全内嵌），已入库。
注意：浏览器仍然不能直接写工程目录，构建结果还是下载 `atlas.png` + `characters-ai.json` 后手动放进
`out/<view>/`；如果连下载都想省掉，只能用本地 Node 服务模式。

### 7.19 批量生成不同主题/画风的角色套图

[`tools/generate-character-sets.mjs`](../tools/generate-character-sets.mjs) 用 GPT Image 批量生成 5 组角色，
每组 6 个侧视部位，处理成透明部件后自动构建进 `characters-ai.json`。

| 名字 | 主题 | 画风 | 头放大 |
|---|---|---|---|
| `ai_mage` | Q版幻想法师 | 柔和水彩/赛璐璐 | 2× |
| `ai_steam` | 蒸汽朋克发明家 | 半写实厚涂插画 | 1× |
| `ai_wuxia` | 水墨仙侠剑客 | 水墨/朱砂 | 1× |
| `ai_waste` | 废土拾荒者 | 粗粝美漫/墨线 | 1× |
| `ai_fairy` | 森林小精灵 | 柔和水彩绘本 | 2× |

```bash
ARUHUB_API_KEY=... node tools/generate-character-sets.mjs
# 只生成其中几组
ARUHUB_API_KEY=... node tools/generate-character-sets.mjs --only ai_mage,ai_wuxia
# 强制重跑已有部件
ARUHUB_API_KEY=... node tools/generate-character-sets.mjs --only ai_steam --force
```

每个部位一次 `images/edits`（`gpt-image-2` / 1024 / medium），提示词结构：

```text
<CHARACTER DESIGN / BIBLE>
STYLE: <该角色的画风>
<PART_PROMPT：只画这一块 + 排除其他部位>
VIEW_HINT: strict side profile facing right
COMMON: 锁轮廓/姿势、品红底、不要道具/额外肢体
```

- ref 用 `templates/side/ref-<group>.png`（侧视手臂是 Walk 0 几何）；
- 每个角色 6 次调用；失败会重试 4 次（502/网络抖动实测会遇到）；
- 生成后 `ai-skin-parts --source custom` 构建，Q版加 `--head-scale 2`；
- 生成图在 `out/`（git 忽略），只提交脚本和说明；API key 只走环境变量。
这 5 组和 studio 里的 Q版/写实 preset 是两条线：studio 适合交互式改描写；这个脚本适合一次性批量出套图。
目前只生成侧视；要正视可 `--views side,front`（调用量翻倍，耗时约 20 分钟）。

### 7.20 index 前端直接导出 Cocos Creator 3.8.4 包

演示页按钮 **“导出 Cocos 3.8.4 ⤓”** 是前端现场导出，不依赖预生成 JSON，也不需要 Node/HTTP 导出服务：

1. 从当前 `characters.json + anim.json` 调 `web/dragonbones-export.js` 生成 DragonBones 5.5 数据；
2. 输出 Cocos Creator 3.8.4 可直接拷入的包：
   ```text
   <char>-cocos384/
     README.md
     assets/dragonbones/<char>/
       <char>_ske.json   ← DragonBonesAsset
       <char>_tex.json   ← DragonBonesAtlasAsset
       <char>_tex.png    ← 纹理
     assets/scripts/
       DragonBonesPlayer.ts
   ```
3. 前端最小 ZIP 打包下载；解压后把 `assets` 拷进 Cocos 项目即可。

Cocos 3.8.x 的 `dragonBones.ArmatureDisplay` 支持 DragonBones 5.6.3 及以下，这份是 5.5。
Canvas 下建节点 → 加 **DragonBones → ArmatureDisplay** → 指定 `Dragon Asset`/`Dragon Atlas Asset`，
`Armature Name` 填 `<char>`，动画选 `Idle_A` 即可。完整步骤见
[docs/cocos-creator-3.8.4.md](cocos-creator-3.8.4.md)。

实测与约定：

- 导出统一 **300px = 1 米** 并按网格包围盒居中；`male` 约 549px 高，原点居中；
- 关键帧从逐帧全键抽稀到 0.25px/0.05° 容差：`male` 81018 → 25651 个键，JSON ~4.5MB → ~1.8MB；
- Cocos 包用 `meshEdges:false`，不带 Pro 专属的 `edges/userEdges`；
- 正视导出会使用 `<char>_front` 前缀，armature 仍是 `<char>`；
- CLI 的 combined JSON（带 `edges`）仍用于官方 DragonBones 运行时逐帧校验，骨骼/顶点/贴图集全部通过（<1.1px）；
- 只依赖 index 能读 `out/` 的静态服务器，不需要 `import-ui-server`。

**Pro / LoongBones**：同一套 `_ske/_tex/png` 是标准 DragonBones 5.5，但 Pro 的网格导入还有自己的兼容要求
（同名、`edges`、`width/height`），见 [docs/研究报告.md](研究报告.md) 第 6 节；优先用 Cocos 包接入引擎。

CLI 仍然保留（输出 combined JSON，给官方运行时/批量导出）：

```bash
node tools/export-dragonbones.mjs --data out/side --out out/side/dragonbones \
  --extra out/side/characters-ai.json
```

## 8. 局限

1. **平面投影不是真正的 UV 展开**：正/背面、左右重叠的肢体共用同一块屏幕区域。
   侧视绑定姿态下手臂正对镜头，投影会退化成肩部一个圆；`ai_ronin_v5` 用 **Walk 0 的纹理姿态**缓解，
   但 `Sword_Attack` 这类肘部大幅弯曲的动作仍会拉伸。彻底做法是按骨段做 limb UV（上臂/前臂/手各一格）。
   分块版把身体拆成 6 个独立 UV 区域，但块之间是硬接缝、头部的平面脸在转头时仍会拉伸。
2. **依赖 AI 保持轮廓**：AI 如果加披风、武器、长发，包围盒会变，贴图整体偏移。
   提示词里必须锁姿势、锁轮廓、不要道具。图生图（`images/edits`）比文生图稳，但也要检查姿态。
3. **分块图不是真正的语义 UV**：每块仍是“该块的屏幕包围盒 → 图片内容框”的平面映射，
   不是按骨骼/圆柱展开；所以块的边缘会硬接缝，极端的关节旋转仍可能拉伸。
   下一步可以把上臂/前臂/手、大腿/小腿/脚再拆开，做真正的 limb atlas。
4. **分辨率**：1024 整身图摊到 7399 个顶点上，脸和手指的细节有限；分块版可以逐块 1024，
   但单块仍然受 AI 重绘轮廓的影响。
5. **生成图不入库**：`out/` 已被 git 忽略，AI 图需要用自己的 key 重新生成。
   本仓库只提交工具、提示词和接入说明。

## 9. 安全

- 不要在命令行历史/截图/提交里留 key；推荐 `export ARUHUB_API_KEY=...` 或本地 `.env`。
- 如果 key 曾经发到公开聊天/截图里，**立刻去 AruHub 后台作废并新建一个**。
- 本工具不会把 key 写入 `characters-ai.json`、纹理或元数据；可以自行 `grep` 验证。
