# Cocos Creator 3.8.4 接入（DragonBones · male）

样例包：`dist/cocos384-dragonbones-male.zip`。这是给 **Cocos Creator 3.8.4** 用的 DragonBones 5.5 资源。
角色是侧视 `male`，数据已经按 **300px = 1 米** 放大并居中，站立高约 **549px**。

Cocos Creator 3.8.x 的 DragonBones 组件支持 DragonBones **5.6.3 及以下**，这份是 5.5，能直接导入。
其他角色可以先用演示页“导出 Cocos 3.8.4 ⤓”导出，再把 `_ske/_tex/png` 三件套按本文放进 Cocos。

---

## 1. 拷贝资源

把样例包里的 `assets/dragonbones` 和 `assets/scripts` 复制到你的 Cocos Creator 3.8.4 项目的 `assets/` 下，例如：

```text
你的项目/assets/
  dragonbones/male/
    male_ske.json      ← DragonBones 骨骼 + 动画
    male_tex.json      ← 纹理集配置
    male_tex.png       ← 纹理
  scripts/
    DragonBonesPlayer.ts
```

Cocos 会自动按后缀识别：

- `*_ske.json` → **DragonBonesAsset**
- `*_tex.json` → **DragonBonesAtlasAsset**
- `*_tex.png` → 纹理

**不要改文件名后缀**；如果 Cocos 把它们识别成普通 JsonAsset，检查后缀是否还是 `_ske.json` / `_tex.json`。

---

## 2. 在场景里用（不用写代码也可以）

1. 新建/打开一个 **2D 场景**（有 Canvas 和 Camera）。
2. 在 Canvas 下新建空节点，命名 `Male`。
3. 选中 `Male`，**添加组件 → DragonBones → ArmatureDisplay**。
4. 在属性面板里：
   - **Dragon Asset**：拖 `male_ske`
   - **Dragon Atlas Asset**：拖 `male_tex`
   - **Armature Name**：`male`
   - **Animation**：`Idle_A`（或 Walk / Jog / Sprint / Sword_Attack …）
   - **Play Times**：`0` 表示循环
5. 运行预览。角色默认在节点原点居中；如果太大，把 `Male` 节点的 **Scale** 设成 `0.5`（或按你的 UI 比例调）。

---

## 3. 用脚本播放/切动画

把 `assets/scripts/DragonBonesPlayer.ts` 拷进项目，等 Cocos 编译完成后：

1. Canvas 下新建空节点，添加 **DragonBonesPlayer** 组件；
2. 属性面板里指定 `Dragon Asset = male_ske`、`Dragon Atlas Asset = male_tex`；
3. 运行，默认播 `Idle_A`。

脚本核心就是：

```ts
const display = this.node.addComponent(dragonBones.ArmatureDisplay);
display.dragonAsset = this.dragonAsset;
display.dragonAtlasAsset = this.dragonAtlasAsset;
display.armatureName = 'male';
display.playAnimation('Idle_A', 0);
```

运行时切换：

```ts
this.getComponent(DragonBonesPlayer)?.play('Walk');
```

可用动画名：

```text
Idle_A  Walk  Jog  Sprint  Jump_air  Sword_Attack
Punch_Jab  Dance_Simple  Roll  Zombie_Walk  Pistol_Shoot  Crouch_Walk
```

---

## 4. 常见问题

**Q：角色太大/太小？**  
数据是 300px = 1 米，`male` 约 549px 高。2D Canvas 下如果觉得大，调节点 Scale；不建议改 JSON。

**Q：贴图是整张色块/花屏？**  
确认 `male_tex.png` 和 `male_tex.json` 是一起导入的，并且 `male_tex` 这个 **DragonBonesAtlasAsset** 的 `texture` 指向 `male_tex.png`。
正常情况 Cocos 会自动配对；如果没配，选中 `male_tex` 在 Inspector 里手动指定纹理。

**Q：动画名对不上？**  
`Armature Name` 是 `male`，不是 `Armature`；动画在 `male` 这个 armature 下。

**Q：3D 场景里看不到？**  
`ArmatureDisplay` 是 2D 渲染组件，放在 Canvas/2D 层；不要挂在 3D 相机直接看的位置。

**Q：为什么和 Pro 里的坐标不一样？**  
这份是给引擎运行时用的 300px/m、居中数据；Pro 编辑器的 mesh 导入有它自己的兼容性问题，两者不是一回事。

---

## 5. 资源说明

- 数据版本：DragonBones 5.5（`version`/`compatibleVersion`）
- 骨骼：66 根
- 网格：1 个蒙皮网格，7399 顶点 / 13757 三角
- 动画：12 个，30fps；关键帧已抽稀（0.25px / 0.05° 容差）
- 贴图：`male_tex.png` 499×500
- 授权：模型/动画来自 Mesh2Motion，CC0；代码 MIT
