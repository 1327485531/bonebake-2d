#!/usr/bin/env bash
# 在解压目录启动本地静态服务器；浏览器不允许 file:// 直接加载 ES module / fetch out 数据。
cd "$(dirname "$0")"
echo "打开: http://127.0.0.1:8899/web/index.html"
if command -v node >/dev/null 2>&1; then
  exec node tools/serve.mjs
fi
exec python3 tools/serve.py
