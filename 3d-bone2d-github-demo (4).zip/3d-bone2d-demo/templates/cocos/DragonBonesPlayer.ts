import { _decorator, Component, dragonBones } from 'cc';
const { ccclass, property } = _decorator;

/**
 * 把 DragonBones 资源挂到节点上并播放动画。
 * 用法：
 * 1. 把本脚本放进 Cocos 项目的 assets/scripts，等编译；
 * 2. Canvas 下新建空节点，添加本组件；
 * 3. 把 male_ske.json 拖到 Dragon Asset，male_tex.json 拖到 Dragon Atlas Asset；
 * 4. 运行，默认播放 Idle_A。
 */
@ccclass('DragonBonesPlayer')
export class DragonBonesPlayer extends Component {
    @property(dragonBones.DragonBonesAsset)
    dragonAsset: dragonBones.DragonBonesAsset | null = null;

    @property(dragonBones.DragonBonesAtlasAsset)
    dragonAtlasAsset: dragonBones.DragonBonesAtlasAsset | null = null;

    @property
    armatureName = 'male';

    @property
    animationName = 'Idle_A';

    /** 0 = 无限循环；1 = 播一次；-1 = 用配置里的 playTimes */
    @property
    playTimes = 0;

    private _display: dragonBones.ArmatureDisplay | null = null;

    start () {
        if (!this.dragonAsset || !this.dragonAtlasAsset) {
            console.warn('[DragonBonesPlayer] 先指定 Dragon Asset 和 Dragon Atlas Asset');
            return;
        }

        let display = this.getComponent(dragonBones.ArmatureDisplay);
        if (!display) {
            display = this.node.addComponent(dragonBones.ArmatureDisplay);
        }
        // 先设资源，再设骨架/动画，避免组件在空资源上初始化一遍。
        display.dragonAsset = this.dragonAsset;
        display.dragonAtlasAsset = this.dragonAtlasAsset;
        display.armatureName = this.armatureName;
        display.playTimes = this.playTimes;
        display.playAnimation(this.animationName, this.playTimes);
        this._display = display;
    }

    /** 运行时切动画，例如 player.play('Walk') */
    play (name: string, times = this.playTimes) {
        this.animationName = name;
        this._display?.playAnimation(name, times);
    }

    /** 所有动画名，方便做下拉/调试 */
    get animationNames (): string[] {
        return this._display?.getAnimationNames() ?? [];
    }
}
