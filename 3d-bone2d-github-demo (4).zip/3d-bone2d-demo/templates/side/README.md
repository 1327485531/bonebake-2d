# 手绘模板包（side）

每个格子 1024x1024，顺序（从左到右、从上到下）：
`head / torso / arm_l / arm_r / leg_l / leg_r`

## 文件

| 文件 | 用途 |
|---|---|
| `template-<group>.png` | 1024x1024，透明底 + 品红轮廓；直接当参考层描线 |
| `canvas-<group>.png` | 1024x1024，全透明画布；把 guide 放另一个窗口/图层对照 |
| `sheet.png` | 3072x2048，3x2，可整张画完直接导入 |
| `ref-<group>.png` | 768x768 几何参考图；AI 生成器的图生图输入 |
| `base-male.json` | 离线导入器用的 male 骨骼/网格 |
| `pose-walk0.json` | 侧视 Walk 0 顶点位置（离线构建手臂 UV 用；front 没有） |

品红（#FF00FF）只是 guide，导入工具会自动剥掉；如果不想保留 guide，在导出前隐藏/删除它。
侧视手臂用的是 **Walk 第 0 帧**（手臂伸开），不是 T-pose。

## 画法

1. 打开 `template-<group>.png`，新建一个图层在上层描线/上色；
2. 尽量画在品红轮廓内，保持同样的姿势和取景；
3. 导出透明 PNG（或纯色背景也可以，导入工具会抠）；
4. 整张 sheet 画完就存 `sheet.png`；分块画就存 6 张 `<myname>-<group>-side.png`。

## 导入 / 构建

```bash
# 整张 3x2 sheet
node tools/import-part-drawing.mjs --view side --sheet templates/side/sheet.png --name mychar

# 或 6 张部件图
node tools/import-part-drawing.mjs --view side --dir templates/side --prefix template --name mychar
```

侧视默认会用 `--pose Walk --pose-frame 0 --pose-groups arm_l,arm_r`；
要 Q 版大头追加 `--head-scale 2`。**不要加披风/武器/大帽子改变轮廓**，否则内容包围盒会变，
平面 UV 会把新图拉伸。换身体比例需要重做网格/权重，不是换贴图能解决的。

## 可视化导入

- **服务模式**：`node tools/import-ui-server.mjs` → `http://127.0.0.1:8898/`，构建直接写 `out/`。
- **离线模式**：用任意静态服务器打开 `web/import.html`（例如 `python3 -m http.server 8898`），
  页面会在浏览器里抠图/打包，构建后下载 `atlas.png` + `characters-ai.json`，手动放进 `out/<view>/`。
- 离线构建靠本目录的 `base-male.json` 和 `pose-walk0.json`；由 `make-templates` 生成。
