# 2D 骨骼皮肤手绘模板包

给这套 66 骨 / 12 动画的角色画新皮肤用的 **可描线模板**。骨架、网格、权重、动画都不变，
你只换 6 张部件贴图。

## 目录

```text
templates/
  side/
    template-<group>.png   1024x1024，透明底 + 品红轮廓（可直接当参考层）
    canvas-<group>.png     1024x1024，全透明画布
    ref-<group>.png        768x768，平涂几何参考图（AI 生成器的图生图输入）
    sheet.png              3072x2048，3x2，一整张画完直接导入
    base-male.json         离线导入器用的 male 骨骼/网格
    pose-walk0.json        侧视 Walk 0 顶点位置（离线构建手臂 UV 用）
    README.md              这一视角的详细说明
  front/
    ... 同上（front 没有 pose-walk0.json）
```

`<group>` 顺序（从左到右、从上到下）：

```text
head / torso / arm_l / arm_r / leg_l / leg_r
```

## 怎么画

1. 打开 `template-<group>.png`，新建一个图层在上面描线/上色；
2. 尽量画在品红轮廓内，保持参考图同样的姿势、朝向和取景；
3. 导出 **PNG**（透明底最稳；纯色底也能自动抠）；
4. 整张画完：保存 3x2 的 `sheet.png`；分块画：保存 6 张 `<myname>-<group>-<view>.png`。

品红 `#FF00FF` 只是 guide，导入工具会自动剥掉。也可以在导出前隐藏/删除 guide 图层。
如果角色本身就要大面积品红/粉紫，**先删掉 guide 图层**，导入时加 `--keep-guide` 关掉自动剥色，
否则粉色区域会被当成 guide 一起清掉。

**不要加披风、长武器、大帽子**改变轮廓；平面 UV 是按“图片内容包围盒 → 网格块包围盒”
线性映射的，轮廓一变就会拉伸/错位。要换身体比例需要重做网格/权重，不是换贴图能解决的。

## 导入 / 构建

```bash
# 整张 3x2 sheet（推荐）
node tools/import-part-drawing.mjs --view side --sheet templates/side/sheet.png --name mychar

# 或 6 张分块图
node tools/import-part-drawing.mjs --view side --dir mydrawings --prefix mychar --name mychar

# 正视图
node tools/import-part-drawing.mjs --view front --sheet templates/front/sheet.png --name mychar

# Q 版大头
node tools/import-part-drawing.mjs --view side --sheet templates/side/sheet.png --name mychar --head-scale 2

# 只看部件/构建命令，不构建
node tools/import-part-drawing.mjs --view side --sheet templates/side/sheet.png --name mychar --no-build
```

不想用命令行也可以开可视化导入器：

```bash
# 服务模式：预览/构建直接写 out/
node tools/import-ui-server.mjs
# http://127.0.0.1:8898/

# 离线模式：不用 Node 服务，用任意静态服务器打开页面
python3 -m http.server 8898
# http://127.0.0.1:8898/web/import.html
# 页面自动进入离线模式，构建后下载 atlas.png + characters-ai.json，手动放进 out/<view>/
```

服务模式默认不允许覆盖同名角色。离线模式需要能读取 `templates/<view>/base-male.json`、
`templates/side/pose-walk0.json` 和 `out/<view>/characters-ai.json`；用静态服务器从工程根目录打开即可。

侧视默认会用 `--pose Walk --pose-frame 0 --pose-groups arm_l,arm_r`，因为模板里的两条手臂
是 Walk 0 姿态；正视图是 T-pose。导入完成后刷新：

```text
http://127.0.0.1:8899/web/index.html?view=side&char=mychar&clip=Walk&frame=0&play=0&bones=0
```

## 重新生成模板

模板是从 `male` 基础网格的几何参考图生成的；网格/骨架变了可以重建：

```bash
node tools/make-templates.mjs --views side,front --size 1024
```

侧视手臂会渲染 `Walk 0`，其他块用 `bind`；生成物在 `templates/side` / `templates/front`。
