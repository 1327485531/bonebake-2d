# 发 GitHub / 打包前检查

这个仓库**只提交源码、工具、提示词、模板和文档**；烘焙产物和上游克隆都不入库。

## 不要打包的目录

| 路径 | 大小（本机） | 原因 |
|---|---:|---|
| `mesh2motion-app/` | 114 MB | 上游参考仓库；按 README 现 clone 即可，且里面含 CMU/mocap 样例 |
| `out/` | 410 MB | 烘焙产物（anim.json / characters / atlas / dragonbones / AI 图） |
| `shots/` | 14 MB | UI 截图/AI 图，按仓库约定不入库 |
| `node_modules/` | - | 项目零 npm 依赖，不需要 |

`.gitignore` 已经忽略这些；不要用“把整个目录 zip 起来”的方式发布，否则会把 500+ MB 和第三方样例一起发出去。

推荐的打包方式（只包含 git 跟踪的文件）：

```bash
git archive --format=zip --prefix=3d-bone2d/ HEAD -o 3d-bone2d-src.zip
```

GitHub Release / Pages 还需要一份“打开就能看”的样例时，单独附 `dist/cocos384-dragonbones-male.zip`
（Cocos 3.8.4 三件套 + 脚本 + 说明），不要把它塞进主仓库；`dist/` 已被 `.gitignore` 忽略。

## 新克隆怎么跑

```bash
git clone --depth 1 https://github.com/Mesh2Motion/mesh2motion-app.git
./tools/bake-all.sh          # 正/侧两个视角 + DragonBones 导出
python3 -m http.server 8899 --bind 127.0.0.1
# http://127.0.0.1:8899/web/index.html
```

注意：`web/index.html` 依赖 `out/<view>/`，而 `out/` 不在仓库里。**源码 clone 后必须先烘焙**，
否则 index 是空的。想做一个“打开就能跑”的 GitHub Pages 演示，需要单独准备一份最小 `out/`
（建议放 GitHub Release 或 `gh-pages` 分支，不要塞进主仓库）。

`web/studio.html` 的导入/构建在 `file://` 下不需要服务，但它构建出的角色同样要放进 `out/` 才能看 demo。

## 动画导出选哪种

- **index 当前用的**：自研 2D 骨骼动画（`out/<view>/anim.json` + 网格/权重 + 图集），
  浏览器里实时 LBS，不是序列图。
- **index 的「导出 Cocos 3.8.4 ⤓」**：现场生成 `<char>-cocos384.zip`，含
  `assets/dragonbones/<char>/` 三件套 + `assets/scripts/DragonBonesPlayer.ts` + README，
  直接拷进 Cocos Creator 3.8.4 项目；说明见 `docs/cocos-creator-3.8.4.md`。
- **DragonBones CLI / 官方运行时**：`node tools/export-dragonbones.mjs ...` 生成 DragonBones 5.5 JSON + 图集，
  给 DragonBones/Pixi 或支持龙骨的引擎用；`web/dragonbones.html` 是官方运行时实测页。
- **序列图/GIF/MP4**：当前没有导出器。它只适合做 README/itch 预览，不是动画的运行时格式；
  需要的话可以再加“浏览器逐帧截图 → ffmpeg”的工具。

## 第三方 / 许可

见 [THIRD_PARTY_LICENSES.md](THIRD_PARTY_LICENSES.md)。

- 当前 index 的 12 个动画来自 `human-base-animations.glb`，Mesh2Motion 声明 CC0，可商用。
- `CarnegieMellonAnimations/` 和 `human-mocap-animations.glb` **不是当前 index 用的动画**：
  - 前者是 CMU mocap 的 FBX 样例（rancidmilk 提供）；
  - 后者是 mocap 转换出的 GLB；
  - CMU 数据允许用于商业产品，但**不允许直接转售数据本身**（含转换后的数据）。
    所以不要把它们打进 GitHub 仓库/发布包；`mesh2motion-app/` 整个不入库就没事。
- AI 生成的角色贴图（`ai_ronin*` / `ai_chibi` / `ai_mage` 等）不是 CC0；它们在 `out/`，
  商用前单独确认 AruHub/OpenAI 条款。
- 字体 Noto Sans SC：OFL 1.1；DragonBones/Pixi：MIT；保留各自许可文件/头部声明。

## 发布前自检

```bash
# 不应出现真实 key
grep -RIn "sk-[A-Za-z0-9]" --exclude-dir=.git --exclude-dir=node_modules . || true

# 不应有 >100MB 的 tracked 文件
git ls-files -z | xargs -0 du -h | sort -hr | head

# 确认没有把 out/mesh2motion/shots 加进来
git ls-files | grep -E '^(out|mesh2motion-app|shots)/' || echo "clean"

# 工作区状态
git status --short
```
