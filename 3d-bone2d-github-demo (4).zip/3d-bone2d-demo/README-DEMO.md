# 3d-bone2d 可运行 Demo

这个包已经带了 `male` 的最小 `out/` 数据，解压后：

## Windows

1. 双击根目录的 `start-server.bat`；
2. 浏览器打开 <http://127.0.0.1:8899/web/index.html>；
3. 选 `male`，点 **“导出 Cocos 3.8.4 ⤓”** 下载 Cocos Creator 3.8.4 用的包。

**不要直接双击 `web/index.html`**：浏览器会拦 `file://` 的 ES module 和 `out/` 数据读取。

## macOS / Linux

```bash
./start-server.sh
# 打开 http://127.0.0.1:8899/web/index.html
```

## 说明

- 只带了 `male` 的侧视/正视最小数据；其他角色需要按主 README 重新烘焙 `out/`。
- 要整套角色/动画，见根目录 `README.md` 的“快速开始”。
