// 龙骨导出实测页：只使用官方 DragonBones + Pixi 运行时。
// 数据来自 out/<view>/dragonbones/<char>.json（tools/export-dragonbones.mjs 导出）。
const DATA_BASE = '../out/'
const $ = (id) => document.getElementById(id)

const state = {
  view: 'side',
  char: null,
  clip: null,
  chars: null,
  db: null,
  armature: null,
  factory: null,
  display: null,
  frames: 0,
  fps: 30,
  playing: true,
  speed: 1,
  playhead: 0,
  bounds: null,
  loading: false
}

let app = null

function logError (e) {
  console.error(e)
  const el = $('loading')
  el.classList.remove('hide')
  el.classList.add('err')
  el.textContent = '出错了：' + (e && e.message ? e.message : e) + '\n（详情看控制台）'
}

async function initPixi () {
  app = new PIXI.Application()
  await app.init({
    canvas: $('cv'),
    backgroundAlpha: 0,
    antialias: true,
    resolution: Math.min(window.devicePixelRatio || 1, 2),
    autoDensity: true,
    resizeTo: document.querySelector('.stage')
  })
  $('i-pixiver').textContent = PIXI.VERSION

  app.ticker.add((ticker) => {
    const arm = state.armature
    if (!arm) return
    if (state.playing) {
      const dt = Math.min(ticker.deltaMS, 100) / 1000 * state.speed
      arm.advanceTime(dt)
      const dur = state.frames / state.fps
      state.playhead = (state.playhead + dt) % dur
      showFrame()
    }
  })

  const ro = new ResizeObserver(() => applyFit())
  ro.observe(document.querySelector('.stage'))
}

function showFrame () {
  const f = Math.min(state.frames - 1, Math.floor(state.playhead * state.fps + 1e-6))
  $('i-frame').textContent = `${f} / ${state.frames - 1}`
  $('framev').textContent = String(f)
  if (document.activeElement !== $('scrub')) $('scrub').value = String(f)
  const back = $('back')
  if (back) {
    const q = new URLSearchParams({
      view: state.view,
      char: state.char || '',
      clip: state.clip || '',
      frame: String(f),
      play: '0'
    })
    back.href = 'index.html?' + q.toString()
  }
}

/** 用当前动画的一批帧估计显示包围盒，返回 local bounds */
function measureBounds () {
  const arm = state.armature
  const F = state.frames
  const b = new PIXI.Bounds()
  const saved = state.playhead
  const step = Math.max(1, Math.floor(F / 12))
  for (let f = 0; f < F; f += step) {
    seek(f)
    const lb = arm.display.getLocalBounds()
    if (Number.isFinite(lb.minX)) {
      b.minX = Math.min(b.minX, lb.minX)
      b.minY = Math.min(b.minY, lb.minY)
      b.maxX = Math.max(b.maxX, lb.maxX)
      b.maxY = Math.max(b.maxY, lb.maxY)
    }
  }
  seek(Math.min(F - 1, Math.round(saved * state.fps)))
  return b
}

function applyFit () {
  if (!app || !state.display || !state.bounds) return
  const b = state.bounds
  if (!Number.isFinite(b.minX) || b.maxX <= b.minX || b.maxY <= b.minY) return
  const W = app.screen.width, H = app.screen.height
  const pad = 0.86
  const scale = Math.min(W * pad / (b.maxX - b.minX), H * pad / (b.maxY - b.minY))
  const cx = (b.minX + b.maxX) / 2, cy = (b.minY + b.maxY) / 2
  state.display.scale.set(scale)
  state.display.position.set(W / 2 - cx * scale, H / 2 - cy * scale)
}

async function loadCharacters () {
  const [c, ai] = await Promise.all([
    fetch(`${DATA_BASE}${state.view}/characters.json`).then(r => r.json()),
    fetch(`${DATA_BASE}${state.view}/characters-ai.json`)
      .then(r => (r.ok ? r.json() : null))
      .catch(() => null)
  ])
  if (ai && ai.characters) Object.assign(c.characters, ai.characters)
  state.chars = c
  const sel = $('char')
  sel.innerHTML = ''
  for (const name of Object.keys(state.chars.characters)) {
    const o = document.createElement('option')
    o.value = name
    o.textContent = state.chars.characters[name].ai ? `${name} · AI` : name
    sel.appendChild(o)
  }
}

async function loadChar (name) {
  if (state.loading) return
  state.loading = true
  const el = $('loading')
  el.classList.remove('hide', 'err')
  el.textContent = '载入龙骨数据…'
  try {
    if (state.armature) {
      state.armature.animation.stop()
      state.armature.dispose()
      if (state.display && state.display.parent) state.display.parent.removeChild(state.display)
      if (state.display) state.display.destroy({ children: true })
    }
    state.armature = null
    state.display = null
    state.db = null

    const dbUrl = new URL(`${DATA_BASE}${state.view}/dragonbones/${name}.json`, location.href).href
    const db = await fetch(dbUrl).then(r => {
      if (!r.ok) throw new Error(`找不到 ${dbUrl}（先跑 tools/export-dragonbones.mjs）`)
      return r.json()
    })
    state.db = db
    state.char = name

    const factory = new dragonBones.PixiFactory(null, false)
    factory.clear()
    factory.parseDragonBonesData(db, 'M2D')
    const textures = []
    for (const atlas of db.textureAtlas || []) {
      const imgUrl = new URL(atlas.imagePath, dbUrl).href
      textures.push(await PIXI.Assets.load(imgUrl))
    }
    // parseDragonBonesData 会把 JSON 里的 textureAtlas 一起建成数据对象，
    // 这里把真正的 Pixi 贴图塞进去（而不是再 parse 一次，避免重复 atlas）
    factory.updateTextureAtlases(textures, 'M2D')
    state.factory = factory

    const arm = factory.buildArmature(name, 'M2D')
    if (!arm) throw new Error('官方运行时没能 buildArmature')
    state.armature = arm
    state.display = arm.display
    app.stage.addChild(arm.display)

    const animNames = Object.keys(arm.armatureData.animations)
    const animSel = $('anim')
    animSel.innerHTML = ''
    for (const an of animNames) {
      const o = document.createElement('option')
      o.value = an
      o.textContent = an
      animSel.appendChild(o)
    }
    state.clip = animNames.includes('Walk') ? 'Walk' : animNames[0]
    animSel.value = state.clip

    // 统计信息
    const armDef = db.armature.find(a => a.name === name) || db.armature[0]
    const slotDefs = armDef.skin[0].slot
    let nv = 0, nt = 0
    for (const s of slotDefs) for (const d of s.display) { nv += (d.vertices || []).length / 2; nt += (d.triangles || []).length / 3 }
    $('i-dbver').textContent = dragonBones.DragonBones.VERSION
    $('i-arm').textContent = armDef.name
    $('i-bones').textContent = Object.keys(armDef.bone).length
    $('i-slots').textContent = `${slotDefs.length} / ${slotDefs.reduce((s, x) => s + x.display.length, 0)}`
    $('i-mesh').textContent = `${nv} / ${nt}`
    $('i-anims').textContent = String(animNames.length)
    $('i-fps').textContent = `${db.frameRate} fps`

    setClip(state.clip, 0)
    el.classList.add('hide')
  } catch (e) {
    logError(e)
  } finally {
    state.loading = false
  }
}

function setClip (clip, frame = 0) {
  const arm = state.armature
  if (!arm) return
  const anim = arm.armatureData.animations[clip]
  if (!anim) return
  state.clip = clip
  state.frames = anim.frameCount
  state.fps = arm.armatureData.frameRate || 30
  $('i-frames').textContent = String(anim.frameCount)
  const scrub = $('scrub')
  scrub.max = String(anim.frameCount - 1)
  scrub.value = String(frame)

  arm.animation.play(clip, 0)
  seek(frame)
  state.bounds = measureBounds()
  applyFit()
  showFrame()
}

/** 精确定位到某一帧（不重建骨架） */
function seek (frame) {
  const arm = state.armature
  if (!arm) return
  const st = arm.animation.lastAnimationState
  if (!st) return
  state.playhead = frame / state.fps
  st._time = frame / state.fps + 1e-6
  arm.advanceTime(0)
  showFrame()
}

async function boot () {
  window.__dbg = { state, app }
  try {
    await initPixi()
    const q = new URLSearchParams(location.search)
    if (q.get('view') === 'front') state.view = 'front'
    $('view').value = state.view
    await loadCharacters()

    const wanted = q.get('char')
    const chars = Object.keys(state.chars.characters)
    if (!chars.length) throw new Error('characters.json 是空的')
    $('char').value = chars.includes(wanted) ? wanted : chars[0]

    await loadChar($('char').value)

    // URL 参数：?view=front&char=zombie&clip=Walk&frame=20&play=0
    const wantedClip = q.get('clip')
    if (wantedClip && $('anim').querySelector(`option[value="${wantedClip}"]`)) {
      $('anim').value = wantedClip
      setClip(wantedClip, Number(q.get('frame') || 0))
    } else if (q.get('frame') !== null) {
      seek(Number(q.get('frame') || 0))
    }
    if (q.get('play') === '0') {
      state.playing = false
      $('play').textContent = '播放'
    }

    $('view').addEventListener('change', async () => {
      state.view = $('view').value
      await loadCharacters()
      $('char').value = state.char
      if (!state.chars.characters[state.char]) $('char').value = Object.keys(state.chars.characters)[0]
      await loadChar($('char').value)
    })
    $('char').addEventListener('change', () => loadChar($('char').value))
    $('anim').addEventListener('change', () => setClip($('anim').value, 0))
    $('play').addEventListener('click', () => {
      state.playing = !state.playing
      $('play').textContent = state.playing ? '暂停' : '播放'
    })
    $('speed').addEventListener('input', () => {
      state.speed = Number($('speed').value)
      $('speedv').textContent = state.speed.toFixed(1) + '×'
    })
    $('scrub').addEventListener('input', () => seek(Number($('scrub').value)))
    window.addEventListener('resize', applyFit)
  } catch (e) {
    logError(e)
  }
}

boot()
