// 浏览器版 DragonBones 5.5 导出核心（无 Node / DOM 依赖，Node 侧 CLI 也直接 import 这一份）。
//
// 两个"能进 Pro 但看不见"的坑（2026-11 用 LoongBones web 编辑器实测）：
//   1. 单位：M2D 是米，角色高 ~1.8；DragonBones Pro/LoongBones 按像素工作。
//      原样导入后角色只有 2px 高，画布上等于看不见。这里统一放大 300 px/m。
//   2. 位置：M2D 脚底在 y=0、身体向 +y；转成 y 向下后整个人落在负 y，
//      而编辑器初始视口以原点为中心。这里按网格包围盒把角色居中，再写 aabb。
//   3. 贴图匹配：Pro 是按 slot / display / SubTexture 的**同名**去找图的；
//      旧版 slot_0 / mesh_0 / male_0.png 对不上，Pro 就显示 Missing 方块。
//      这里三者统一成 <texture>_<n>，mesh 不写 path；保留 edges 外轮廓，
//      width/height 用网格包围盒（用整图宽高 Pro 会把网格压成竖条）。
//   另外 Pro 的时间轴默认显示所有关键帧；逐帧烘焙会让每根骨每帧都有键。
//   这里在像素误差容差内抽关键帧（RDP），播放效果不变，时间轴可编辑。
const RAD = 180 / Math.PI

/** 1 米 = 300 像素。和 Pro 里 ~550px 高的角色比例接近。 */
export const M2D_SCALE = 300
/** 抽帧容差：平移 0.25px、旋转 0.05°；逐帧渲染误差实测 < 1.1px。 */
export const KEYFRAME_TOL_PX = 0.25
export const KEYFRAME_TOL_DEG = 0.05
/** 单段旋转不要超过 170°，否则龙骨运行时会走"最短路径"插值，转反。 */
const MAX_ROT_SEGMENT_DEG = 170

function aff (x, y, r) {
  const c = Math.cos(r), s = Math.sin(r)
  return [c, s, -s, c, x, y]
}

function mul (A, B) {
  return [
    A[0] * B[0] + A[2] * B[1], A[1] * B[0] + A[3] * B[1],
    A[0] * B[2] + A[2] * B[3], A[1] * B[2] + A[3] * B[3],
    A[0] * B[4] + A[2] * B[5] + A[4], A[1] * B[4] + A[3] * B[5] + A[5]
  ]
}

/** 每根骨的绑定姿态世界矩阵（2D 仿射，输入已经是龙骨坐标） */
function bindWorldMatrices (bones) {
  const out = new Array(bones.length)
  for (let i = 0; i < bones.length; i++) {
    const b = bones[i]
    const local = aff(b.x, b.y, b.rot)
    out[i] = b.parent < 0 ? local : mul(out[b.parent], local)
  }
  return out
}

/** 一维折线 RDP：返回需要保留的下标（首尾必留） */
function simplify1D (values, tol) {
  const n = values.length
  if (n <= 2) return n === 0 ? [] : n === 1 ? [0] : [0, n - 1]
  const keep = new Uint8Array(n)
  keep[0] = keep[n - 1] = 1
  const stack = [[0, n - 1]]
  while (stack.length) {
    const [a, b] = stack.pop()
    if (b <= a + 1) continue
    const va = values[a], vb = values[b]
    const span = b - a
    let worst = -1, wi = -1
    for (let i = a + 1; i < b; i++) {
      const t = (i - a) / span
      const d = Math.abs(values[i] - (va + (vb - va) * t))
      if (d > worst) { worst = d; wi = i }
    }
    if (worst > tol && wi > a) {
      keep[wi] = 1
      stack.push([a, wi], [wi, b])
    }
  }
  const out = []
  for (let i = 0; i < n; i++) if (keep[i]) out.push(i)
  return out
}

/** 二维折线 RDP（平移 x/y 必须一起看，否则 x 的转折点可能漏掉 y 的） */
function simplify2D (points, tol) {
  const n = points.length
  if (n <= 2) return n === 0 ? [] : n === 1 ? [0] : [0, n - 1]
  const keep = new Uint8Array(n)
  keep[0] = keep[n - 1] = 1
  const stack = [[0, n - 1]]
  while (stack.length) {
    const [a, b] = stack.pop()
    if (b <= a + 1) continue
    const va = points[a], vb = points[b]
    const span = b - a
    let worst = -1, wi = -1
    for (let i = a + 1; i < b; i++) {
      const t = (i - a) / span
      const dx = points[i][0] - (va[0] + (vb[0] - va[0]) * t)
      const dy = points[i][1] - (va[1] + (vb[1] - va[1]) * t)
      const d = Math.hypot(dx, dy)
      if (d > worst) { worst = d; wi = i }
    }
    if (worst > tol && wi > a) {
      keep[wi] = 1
      stack.push([a, wi], [wi, b])
    }
  }
  const out = []
  for (let i = 0; i < n; i++) if (keep[i]) out.push(i)
  return out
}

/** 去掉首尾同值、中间都在容差内的两键时间轴 */
function collapseFlat (indices, dist, tol) {
  if (indices.length !== 2) return indices
  const first = indices[0]
  let worst = 0
  for (let i = first; i <= indices[1]; i++) worst = Math.max(worst, dist(i, first))
  return worst <= tol ? [first] : indices
}

/** 角度序列按最短路径展开，避免 -179°/179° 被当成 358° 的大回转 */
function unwrapDegrees (values) {
  const out = new Array(values.length)
  out[0] = values[0]
  for (let i = 1; i < values.length; i++) {
    let d = values[i] - values[i - 1]
    d = ((d + 180) % 360 + 360) % 360 - 180
    out[i] = out[i - 1] + d
  }
  return out
}

function wrapDegrees (v) {
  return ((v + 180) % 360 + 360) % 360 - 180
}

/** 保证相邻关键帧的展开角差 <= 170°，否则插入中间帧强制分段 */
function ensureRotSegments (indices, values, maxDelta) {
  const out = [indices[0]]
  for (let k = 1; k < indices.length; k++) {
    const b = indices[k]
    let a = out[out.length - 1]
    while (b > a + 1 && Math.abs(values[b] - values[a]) > maxDelta) {
      let chosen = -1
      for (let i = b - 1; i > a; i--) {
        if (Math.abs(values[i] - values[a]) <= maxDelta) { chosen = i; break }
      }
      if (chosen < 0) chosen = a + 1
      out.push(chosen)
      a = chosen
    }
    out.push(b)
  }
  return out
}

function keyframes (indices, frameCount, make) {
  return indices.map((idx, k) => {
    const next = k + 1 < indices.length ? indices[k + 1] : frameCount
    return { duration: next - idx, tweenEasing: 0, ...make(idx) }
  })
}

/**
 * @param {object} o
 * @param {object} o.charDef      characters.json 里的单个角色
 * @param {string} o.charName
 * @param {object} o.animData     anim.json
 * @param {string[]} o.clips      要导出的动画名（null = 全部）
 * @param {string} o.name         DragonBonesData 名字
 * @param {(texRel:string, charName:string)=>object} o.textureResolver
 *        返回 { name, imagePath, width, height }；name 是 SubTexture 名（建议不带扩展名）
 * @param {number} [o.scale]      米 → 像素倍率，默认 300
 * @param {boolean} [o.center]    是否按网格包围盒居中，默认 true
 * @param {boolean} [o.meshEdges] 是否写 Pro 的 edges/userEdges；Cocos/运行时不需要，默认 true
 */
export function exportDragonBones ({
  charDef, charName, animData, clips = null, name = 'M2D', textureResolver = null,
  scale = M2D_SCALE, center = true, meshEdges = true
}) {
  const srcBones = charDef.bones
  const nBones = srcBones.length
  const mesh = charDef.mesh

  // M2D(y-up, 米) → 龙骨(y-down, 像素)：y 取反、旋转取反，再乘 scale。
  // 先算网格在龙骨坐标里的包围盒，再把整个角色平移到原点附近。
  let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity
  for (let i = 0; i < mesh.verts.length / 2; i++) {
    const x = mesh.verts[i * 2] * scale
    const y = -mesh.verts[i * 2 + 1] * scale
    if (x < minX) minX = x
    if (x > maxX) maxX = x
    if (y < minY) minY = y
    if (y > maxY) maxY = y
  }
  if (!Number.isFinite(minX)) { minX = minY = 0; maxX = maxY = 1 }
  const offset = center ? [-(minX + maxX) / 2, -(minY + maxY) / 2] : [0, 0]

  const bones = srcBones.map(b => ({
    name: b.name,
    parent: b.parent,
    x: b.x * scale,
    y: -b.y * scale,
    rot: -b.rot,
    len: (b.len || 0) * scale
  }))
  // 只把偏移加在根骨上；子骨的局部坐标不用动。网格顶点和 bonePose 同步平移。
  for (const b of bones) {
    if (b.parent < 0) {
      b.x += offset[0]
      b.y += offset[1]
    }
  }
  const boneNames = bones.map(b => b.name)
  const bindWorld = bindWorldMatrices(bones)

  // ---- 骨骼 ----
  const boneList = bones.map(b => {
    const o = { name: b.name }
    if (b.parent >= 0) o.parent = boneNames[b.parent]
    o.transform = {
      x: round(b.x, 3),
      y: round(b.y, 3),
      skX: round(b.rot * RAD, 3),
      skY: round(b.rot * RAD, 3)
    }
    return o
  })

  // ---- 贴图集 ----
  // Pro 的命名约定：slot.name = display.name = SubTexture.name。
  // 一个 part 一个 SubTexture（共享同一张图时也各起唯一名），这样 Pro 的
  // "按图片名匹配骨架" 才能把 mesh 认成网格；只写 path 的话 Pro 5.6 会落成 Missing/方块。
  const textureAtlases = []
  const atlasByName = new Map()
  const atlasFor = (texRel, subName) => {
    if (!textureResolver) return null
    const info = textureResolver(texRel, charName)
    if (!info) return null
    let atlas = atlasByName.get(info.name)
    if (!atlas) {
      atlas = {
        name: info.name,
        imagePath: info.imagePath,
        width: info.width,
        height: info.height,
        SubTexture: []
      }
      atlasByName.set(info.name, atlas)
      textureAtlases.push(atlas)
    }
    if (!atlas.SubTexture.some(s => s.name === subName)) {
      atlas.SubTexture.push({ name: subName, x: 0, y: 0, width: info.width, height: info.height })
    }
    return { name: subName, width: info.width, height: info.height }
  }

  // ---- 插槽 + 网格 ----
  const slots = []
  const skinSlots = []
  const parts = mesh.parts
  const mi = mesh.skinIndices
  const mw = mesh.skinWeights

  parts.forEach((part, pi) => {
    // 每个 part 的"主骨"：按用到的唯一顶点累加权重（按三角形角落累加会把手指这种
    // 三角面密集的区域放大好几倍，之前整个身体网格挂到了 ring_01_l 上）。
    const usedVerts = new Set()
    for (let t = 0; t < part.indices.length; t++) usedVerts.add(part.indices[t])
    const acc = new Map()
    for (const v of usedVerts) {
      for (let k = 0; k < 4; k++) {
        const w = mw[v * 4 + k]
        if (w <= 0) continue
        acc.set(mi[v * 4 + k], (acc.get(mi[v * 4 + k]) || 0) + w)
      }
    }
    let mainBone = 0
    let best = -1
    for (const [b, w] of acc) if (w > best) { best = w; mainBone = b }

    const texRel = charDef.textures[part.tex] || null
    const texBase = texRel
      ? (textureResolver ? (textureResolver(texRel, charName) || {}).name : null)
      : null
    // 单 part 用纹理名；多 part 共享一张图时加后缀，保证 slot/display/SubTexture 名唯一。
    const partName = parts.length === 1
      ? (texBase || 'body')
      : `${texBase || 'part'}_${pi}`
    if (texRel) atlasFor(texRel, partName)

    // 收集本 part 用到的顶点，按源下标升序导出（校验脚本按同一顺序对比）
    const sortedVerts = [...usedVerts].sort((a, b) => a - b)
    const vmap = new Map()
    const outVerts = []
    const outUvs = []
    const weights = []
    const weightBones = new Set()
    let pMinX = Infinity, pMinY = Infinity, pMaxX = -Infinity, pMaxY = -Infinity

    sortedVerts.forEach((v, idx) => {
      vmap.set(v, idx)
      // 顶点保持骨架空间（绑定姿态）坐标，做 y 翻转 + 缩放 + 整体居中
      const x = mesh.verts[v * 2] * scale + offset[0]
      const y = -mesh.verts[v * 2 + 1] * scale + offset[1]
      if (x < pMinX) pMinX = x
      if (x > pMaxX) pMaxX = x
      if (y < pMinY) pMinY = y
      if (y > pMaxY) pMaxY = y
      outVerts.push(round(x, 3))
      outVerts.push(round(y, 3))
      outUvs.push(round(mesh.uvs[v * 2], 5))
      outUvs.push(round(mesh.uvs[v * 2 + 1], 5))

      const list = []
      for (let k = 0; k < 4; k++) {
        const w = mw[v * 4 + k]
        if (w <= 0) continue
        list.push([mi[v * 4 + k], w])
      }
      list.sort((a, b) => b[1] - a[1])
      const keep = list.slice(0, 4)
      let sum = 0
      for (const e of keep) sum += e[1]
      if (keep.length === 0 || sum <= 0) {
        keep.length = 0
        keep.push([mainBone, 1])
        sum = 1
      }
      weights.push(keep.length)
      for (const [bi, w] of keep) {
        weights.push(bi)
        weights.push(round(w / sum, 4))
        weightBones.add(bi)
      }
    })

    const triangles = []
    let edges = null
    if (meshEdges) {
      const edgeCount = new Map()
      const addEdge = (a, b) => {
        const k = a < b ? `${a},${b}` : `${b},${a}`
        edgeCount.set(k, (edgeCount.get(k) || 0) + 1)
      }
      for (let t = 0; t < part.indices.length; t += 3) {
        const a = vmap.get(part.indices[t])
        const b = vmap.get(part.indices[t + 1])
        const c = vmap.get(part.indices[t + 2])
        addEdge(a, b); addEdge(b, c); addEdge(c, a)
      }
      // Pro 的 mesh 带 edges（外轮廓，按环的顺序排列）。Cocos/标准运行时不需要，
      // 用 meshEdges=false 可以完全不写，避免多一份 Pro 专属数据。
      const adj = new Map()
      for (const [k, count] of edgeCount) {
        if (count !== 1) continue
        const [a, b] = k.split(',').map(Number)
        if (!adj.has(a)) adj.set(a, [])
        if (!adj.has(b)) adj.set(b, [])
        adj.get(a).push(b)
        adj.get(b).push(a)
      }
      const edgeKey = (a, b) => a < b ? `${a},${b}` : `${b},${a}`
      const usedEdges = new Set()
      edges = []
      for (const start of adj.keys()) {
        for (const n of adj.get(start)) {
          if (usedEdges.has(edgeKey(start, n))) continue
          let cur = start
          let prev = -1
          while (cur !== -1) {
            const next = (adj.get(cur) || []).find(v => !usedEdges.has(edgeKey(cur, v)))
            if (next === undefined) break
            usedEdges.add(edgeKey(cur, next))
            edges.push(cur, next)
            prev = cur
            cur = next
            if (cur === start || cur === prev) break
          }
        }
      }
    }
    for (let t = 0; t < part.indices.length; t += 3) {
      triangles.push(vmap.get(part.indices[t]))
      triangles.push(vmap.get(part.indices[t + 1]))
      triangles.push(vmap.get(part.indices[t + 2]))
    }

    // bonePose：参与蒙皮的骨骼 + 其绑定姿态世界矩阵（int + a,b,c,d,tx,ty）
    const bonePose = []
    for (const bi of [...weightBones].sort((a, b) => a - b)) {
      const M = bindWorld[bi]
      bonePose.push(bi, round(M[0], 5), round(M[1], 5), round(M[2], 5),
        round(M[3], 5), round(M[4], 3), round(M[5], 3))
    }

    slots.push({ name: partName, parent: boneNames[mainBone], displayIndex: 0 })
    skinSlots.push({
      name: partName,
      display: [{
        // 和 Pro 自己导出的 mesh 完全一致：slot/display/SubTexture 同名、不写 path
        // （运行时 parser 会把 path 默认成 name）。Pro 才能按图片名匹配到网格。
        name: partName,
        type: 'mesh',
        // 宽高用网格自身包围盒，和第一版一致；不要用整张图集尺寸，
        // 否则 Pro 的 mesh 导入可能按它缩放网格（实测会压成竖条）。
        width: round(pMaxX - pMinX, 2),
        height: round(pMaxY - pMinY, 2),
        vertices: outVerts,
        uvs: outUvs,
        triangles,
        weights,
        slotPose: [1, 0, 0, 1, 0, 0],
        bonePose,
        ...(meshEdges ? { edges, userEdges: [] } : {})
      }]
    })
  })

  // ---- 动画 ----
  // 龙骨时间轴存的是"相对绑定姿态的增量"，这里按帧做差；y 与旋转同时翻转。
  // 然后在 0.25px / 0.05° 容差内抽关键帧，避免 Pro 时间轴"每帧都是满的"。
  const animations = []
  const clipNames = clips && clips.length ? clips : Object.keys(animData.clips)
  for (const clipName of clipNames) {
    const clip = animData.clips[clipName]
    if (!clip) continue
    const tracks = clip.charTracks && clip.charTracks[charName]
      ? clip.charTracks[charName]
      : clip.tracks
    const F = clip.frames
    const boneTimelines = []

    for (let i = 0; i < nBones; i++) {
      const name = boneNames[i]
      const b = bones[i]
      const isRoot = b.parent < 0
      const tr = tracks[name]
      if (!tr) continue

      const trans = new Array(F)
      const rot = new Array(F)
      let maxMove = 0
      let maxTurn = 0
      for (let f = 0; f < F; f++) {
        const o = f * 4
        // M2D 当帧绝对局部变换（y-up，米）；根骨再叠加整体居中偏移
        const ax = tr[o] * b.len + (isRoot ? offset[0] : 0)
        const ay = -tr[o + 1] * b.len + (isRoot ? offset[1] : 0)
        const ar = -tr[o + 2]
        // 转成龙骨局部（y-down，像素）后减绑定姿态
        const dx = ax - b.x
        const dy = ay - b.y
        const dr = (ar - b.rot) * RAD
        trans[f] = [dx, dy]
        rot[f] = dr
        maxMove = Math.max(maxMove, Math.abs(dx), Math.abs(dy))
        maxTurn = Math.max(maxTurn, Math.abs(dr))
      }

      const move = maxMove > KEYFRAME_TOL_PX
      const turn = maxTurn > KEYFRAME_TOL_DEG
      if (!move && !turn) continue

      const timeline = { name }
      if (move) {
        let idx = simplify2D(trans, KEYFRAME_TOL_PX)
        idx = collapseFlat(idx, (i, j) => Math.hypot(
          trans[i][0] - trans[j][0], trans[i][1] - trans[j][1]
        ), KEYFRAME_TOL_PX)
        timeline.translateFrame = keyframes(idx, F, (f) => ({
          x: round(trans[f][0], 3),
          y: round(trans[f][1], 3)
        }))
      }
      if (turn) {
        // RDP 在"展开角"上做，避免 ±180° 跳变被当成大旋转；输出再折回 [-180,180]。
        const unwrapped = unwrapDegrees(rot)
        let idx = simplify1D(unwrapped, KEYFRAME_TOL_DEG)
        idx = collapseFlat(idx, (i, j) => Math.abs(unwrapped[i] - unwrapped[j]), KEYFRAME_TOL_DEG)
        idx = ensureRotSegments(idx, unwrapped, MAX_ROT_SEGMENT_DEG)
        timeline.rotateFrame = keyframes(idx, F, (f) => ({
          rotate: round(wrapDegrees(unwrapped[f]), 3)
        }))
      }
      boneTimelines.push(timeline)
    }

    animations.push({
      name: clipName,
      playTimes: 0,
      duration: F,
      bone: boneTimelines
    })
  }

  // DragonBones Pro 导出里 armature 带 aabb；官方 runtime 不要求，但 Pro 需要它显示包围盒。
  const aabb = {
    x: round(minX + offset[0], 2),
    y: round(minY + offset[1], 2),
    width: round(maxX - minX, 2),
    height: round(maxY - minY, 2)
  }

  return {
    name,
    version: '5.5',
    compatibleVersion: '5.5',
    frameRate: animData.fps || 30,
    textureAtlas: textureAtlases,
    armature: [{
      name: charName,
      type: 'Armature',
      frameRate: animData.fps || 30,
      aabb,
      bone: boneList,
      slot: slots,
      skin: [{ slot: skinSlots }],
      animation: animations,
      defaultActions: animations.length ? [{ gotoAndPlay: animations[0].name }] : []
    }]
  }
}

function round (v, d) {
  const f = Math.pow(10, d)
  return Math.round(v * f) / f
}
