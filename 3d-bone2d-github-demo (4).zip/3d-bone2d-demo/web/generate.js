// AI 皮肤生成器：用户只填 API Key + 角色描写，选风格/视角/部位。
// 其余提示词内置；ref 图来自 templates/<view>/ref-<group>.png。
// 直接调 AruHub /v1/images/edits（CORS 允许），不经过本项目服务器。
const GROUPS = ['head', 'torso', 'arm_l', 'arm_r', 'leg_l', 'leg_r']
const GROUP_LABEL = {
  head: 'head · 头 / 脖子',
  torso: 'torso · 躯干',
  arm_l: 'arm_l · 左臂',
  arm_r: 'arm_r · 右臂',
  leg_l: 'leg_l · 左腿',
  leg_r: 'leg_r · 右腿'
}

const $ = (s) => document.querySelector(s)

const STYLE_PRESETS = {
  chibi: {
    label: 'Q版 / 卡通',
    text: `Q-version chibi 2D game character art. Cute stylized proportions: oversized head,
big expressive eyes (for the head: huge eyes, tiny nose, small smile, rosy cheeks), rounded/chunky limbs,
thick clean cartoon outlines, cel-shaded flat colors, bright readable palette, crisp edges,
consistent 2D game character art.`
  },
  realistic: {
    label: '写实 / 赛博',
    text: `Detailed semi-realistic 2D game character concept art. Adult proportions, crisp edges,
rich material and fabric detail, consistent cinematic lighting, coherent color palette,
high-detail game character art.`
  }
}

const PART_PROMPTS = {
  head: `TASK: paint ONLY the isolated HEAD AND NECK (face, hair, ears, neck).
Use the CHARACTER DESIGN for hair, eyes, skin, accessories and colors.
No shoulders, no jacket, no arms, no hands, no torso.
The head must fill the frame and use the same angle/orientation as the reference.`,
  torso: `TASK: paint ONLY the isolated TORSO (neck opening to waist/hips).
Use the CHARACTER DESIGN for jacket/top, belts, harness, pouches and colors.
No head, no arms, no hands, no legs.
The torso must fill the frame and use the same orientation as the reference.`,
  arm_l: `TASK: paint ONLY the isolated LEFT ARM (shoulder to hand/fingers), including sleeve,
glove or mechanical design from the CHARACTER DESIGN.
No torso, no head, no legs, no right arm.
The arm must fill the frame along the reference arm, same orientation as the reference.`,
  arm_r: `TASK: paint ONLY the isolated RIGHT ARM (shoulder to hand/fingers), including sleeve,
glove or mechanical design from the CHARACTER DESIGN.
No torso, no head, no legs, no left arm.
The arm must fill the frame along the reference arm, same orientation as the reference.`,
  leg_l: `TASK: paint ONLY the isolated LEFT LEG (hip to boot/foot), including pants,
knee pad and shoe design from the CHARACTER DESIGN.
No torso, no arm, no hand, no other leg.
The leg must fill the frame vertically, same orientation as the reference.`,
  leg_r: `TASK: paint ONLY the isolated RIGHT LEG (hip to boot/foot), including pants,
knee pad and shoe design from the CHARACTER DESIGN.
No torso, no arm, no hand, no other leg.
The leg must fill the frame vertically, same orientation as the reference.`
}

const VIEW_HINT = {
  front: 'View: strict front view, same T-pose as the reference, symmetrical.',
  side: 'View: strict side profile facing right, same pose as the reference.'
}

const COMMON = `Keep the exact same silhouette, proportions, pose, orientation and framing as the reference body part.
The reference is a flat-shaded geometry render: ignore its orange color and use the CHARACTER DESIGN colors.
Do not add extra limbs, a second arm/leg, a weapon, cape, hat, backpack, text or frame.
One isolated part, centered, solid chroma-key magenta background (#FF00FF), no shadow, no ground.`

const EXAMPLE = '赛博朋克少女，银白色短发，紫色发光瞳孔，浅冷肤色，黑色机能风夹克（橙色拉链），右臂是红色机械义肢，黑色短裤，厚底战术靴，橙紫霓虹配色。'

const state = {
  style: 'chibi',
  view: 'side',
  part: 'head',
  model: 'gpt-image-2',
  results: {}, // group -> { rawUrl, processedUrl, blob, part, prompt }
  refs: {},    // view:group -> Blob
  busy: false,
  abort: null
}

function setStatus (msg, cls = '') {
  const el = $('#status')
  el.textContent = msg
  el.className = 'status ' + cls
}

function setBusy (busy) {
  state.busy = busy
  $('#generateBtn').disabled = busy
  $('#cancelBtn').disabled = !busy
  for (const sel of ['#view', '#part', '#model']) $(sel).disabled = busy
  for (const radio of document.querySelectorAll('input[name=style]')) radio.disabled = busy
}

function buildPrompt ({ style, view, part, description }) {
  return `You are repainting exactly ONE body part of a 2D game character, using the reference image only for geometry, pose and framing.

CHARACTER DESIGN:
${description}

STYLE:
${STYLE_PRESETS[style].text}

${PART_PROMPTS[part]}

${VIEW_HINT[view]}

${COMMON}`
}

function refUrl (view, group) {
  const embedded = window.STUDIO_DATA && window.STUDIO_DATA[view] && window.STUDIO_DATA[view].refs
  return (embedded && embedded[group]) || new URL(`../templates/${view}/ref-${group}.png`, location.href).href
}

function renderPreview () {
  const part = $('#part').value
  const view = $('#view').value
  const style = document.querySelector('input[name=style]:checked').value
  const desc = $('#description').value.trim() || '（先写角色描写）'
  $('#descCount').textContent = `${$('#description').value.trim().length} 字`

  const wrap = $('#refPreview')
  if (part === 'all') {
    wrap.className = 'refs'
    wrap.innerHTML = GROUPS.map(g => `<div class="ref-item"><img src="${refUrl(view, g)}" alt="${g}"><span>${g}</span></div>`).join('')
    $('#promptPreview').textContent = buildPrompt({ style, view, part: 'head', description: desc })
      + '\n\n[全部模式会依次把 TASK 段替换为 torso / arm_l / arm_r / leg_l / leg_r，其余 BIBLE/风格/视角/约束不变]'
  } else {
    wrap.className = 'ref-wrap'
    wrap.innerHTML = `<img src="${refUrl(view, part)}" alt="${part}">`
    $('#promptPreview').textContent = buildPrompt({ style, view, part, description: desc })
  }
}

// 读取 ref（生成时用）；预览用 <img> 直接显示
async function getRef (view, group) {
  const key = `${view}:${group}`
  if (state.refs[key]) return state.refs[key]
  const res = await fetch(refUrl(view, group), { cache: 'no-store' })
  if (!res.ok) throw new Error(`参考图不存在：templates/${view}/ref-${group}.png（先运行 node tools/make-templates.mjs）`)
  const blob = await res.blob()
  state.refs[key] = blob
  return blob
}

function base64ToBlob (b64, type = 'image/png') {
  const bin = atob(b64)
  const arr = new Uint8Array(bin.length)
  for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i)
  return new Blob([arr], { type })
}

async function apiGenerate ({ apiBase, apiKey, model, style, view, group, description, signal }) {
  const refBlob = await getRef(view, group)
  const prompt = buildPrompt({ style, view, part: group, description })
  const form = new FormData()
  form.set('model', model)
  form.set('image', refBlob, `${view}-${group}.png`)
  form.set('prompt', prompt)
  form.set('size', '1024x1024')
  form.set('quality', 'medium')
  form.set('n', '1')

  const res = await fetch(`${apiBase}/images/edits`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${apiKey}` },
    body: form,
    signal
  })
  const text = await res.text()
  if (!res.ok) throw new Error(`API ${res.status}: ${text.slice(0, 600)}`)
  let json
  try { json = JSON.parse(text) } catch { throw new Error('API 返回不是 JSON: ' + text.slice(0, 300)) }
  const item = json.data && json.data[0]
  if (!item) throw new Error('API 返回里没有 data[0]: ' + text.slice(0, 300))
  let blob
  if (item.b64_json) blob = base64ToBlob(item.b64_json)
  else if (item.url) {
    const r = await fetch(item.url)
    if (!r.ok) throw new Error('下载生成图失败 ' + r.status)
    blob = await r.blob()
  } else throw new Error('API 返回里没有 b64_json/url')
  return { blob, prompt }
}

function blobToImage (blob) {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(blob)
    const img = new Image()
    img.onload = () => resolve({ img, url })
    img.onerror = () => { URL.revokeObjectURL(url); reject(new Error('生成图加载失败')) }
    img.src = url
  })
}

async function processGenerated (blob, group) {
  const { img, url } = await blobToImage(blob)
  try {
    const c = document.createElement('canvas')
    c.width = img.naturalWidth
    c.height = img.naturalHeight
    const ctx = c.getContext('2d')
    ctx.drawImage(img, 0, 0)
    const data = ctx.getImageData(0, 0, c.width, c.height)
    const part = OfflineBuild.processImage({ width: c.width, height: c.height, data: data.data }, 0.06)
    part.name = group
    const pc = document.createElement('canvas')
    pc.width = part.width
    pc.height = part.height
    pc.getContext('2d').putImageData(new ImageData(new Uint8ClampedArray(part.data), part.width, part.height), 0, 0)
    return { part, processedUrl: pc.toDataURL('image/png') }
  } finally {
    URL.revokeObjectURL(url)
  }
}

function makeCard (group, result) {
  const card = document.createElement('div')
  card.className = 'result-card'
  card.dataset.group = group
  card.innerHTML = `
    <div class="name">${GROUP_LABEL[group]} · ${state.style} · ${state.view}</div>
    <div class="imgwrap"><img alt="${group}"></div>
    <div class="actions">
      <button class="ghost" type="button">下载透明图</button>
      <button class="ghost" type="button">下载原图</button>
    </div>
    <div class="raw">raw 预览（未抠图）<img alt="${group} raw"></div>`
  const [procImg] = card.querySelectorAll('img')
  procImg.src = result.processedUrl
  card.querySelector('.raw img').src = result.rawUrl
  const [dlProc, dlRaw] = card.querySelectorAll('button')
  dlProc.addEventListener('click', () => download(result.processedUrl, `${group}-${state.view}-transparent.png`))
  dlRaw.addEventListener('click', () => download(result.rawUrl, `${group}-${state.view}-raw.png`))
  return card
}

function renderResults () {
  const panel = $('#resultsPanel')
  const grid = $('#resultsGrid')
  grid.innerHTML = ''
  const groups = GROUPS.filter(g => state.results[g])
  if (!groups.length) { panel.hidden = true; $('#handoffRow').hidden = true; return }
  panel.hidden = false
  for (const g of groups) grid.appendChild(makeCard(g, state.results[g]))
  $('#handoffRow').hidden = groups.length !== 6
}

function download (url, name) {
  const a = document.createElement('a')
  a.href = url
  a.download = name
  document.body.appendChild(a)
  a.click()
  a.remove()
}

function getKey () {
  const key = $('#apiKey').value.trim()
  if (!key) throw new Error('先填 API Key')
  return key
}

function getApiBase () {
  const v = $('#apiBase').value.trim().replace(/\/+$/, '')
  if (!/^https?:\/\//i.test(v)) throw new Error('先填 API 请求地址（例如 https://api.openai.com/v1）')
  return v
}

function saveKey () {
  const key = $('#apiKey').value.trim()
  const base = $('#apiBase').value.trim()
  if ($('#rememberKey').checked) {
    sessionStorage.setItem('aruhub_key', key)
    sessionStorage.setItem('image_api_base', base)
  } else {
    sessionStorage.removeItem('aruhub_key')
    sessionStorage.removeItem('image_api_base')
  }
}

async function generate () {
  let apiKey, apiBase, description
  try {
    apiKey = getKey()
    apiBase = getApiBase()
    description = $('#description').value.trim()
    if (description.length < 8) throw new Error('角色描写太短，至少写清楚体型/头发/眼睛/衣服/配色')
  } catch (e) { setStatus(e.message, 'err'); return }

  const view = $('#view').value
  const part = $('#part').value
  const style = document.querySelector('input[name=style]:checked').value
  const model = $('#model').value
  const groups = part === 'all' ? GROUPS : [part]
  const ctrl = new AbortController()
  state.abort = ctrl
  state.results = {}
  state.refs = {}
  renderResults()
  setBusy(true)
  saveKey()

  const t0 = Date.now()
  try {
    for (let i = 0; i < groups.length; i++) {
      const group = groups[i]
      if (ctrl.signal.aborted) throw new DOMException('aborted', 'AbortError')
      setStatus(`生成 ${i + 1}/${groups.length}：${group}…（${model}，通常 20-60 秒）`)
      const { blob, prompt } = await apiGenerate({ apiBase, apiKey, model, style, view, group, description, signal: ctrl.signal })
      const rawUrl = URL.createObjectURL(blob)
      const { part: processedPart, processedUrl } = await processGenerated(blob, group)
      state.results[group] = { rawUrl, processedUrl, blob, part: processedPart, prompt }
      renderResults()
      setStatus(`已完成 ${group}（${i + 1}/${groups.length}）`, 'ok')
    }
    setStatus(`生成完成：${groups.length} 块，用时 ${((Date.now() - t0) / 1000).toFixed(0)}s。` +
      (groups.length === 6 ? ' 下载 6 张透明图后去“手绘导入/构建”上传。' : ''), 'ok')
  } catch (e) {
    if (e.name === 'AbortError') setStatus('已取消', 'err')
    else setStatus(e.message, 'err')
  } finally {
    setBusy(false)
    state.abort = null
  }
}

// ---------------- 事件 ----------------
$('#description').addEventListener('input', () => renderPreview())
$('#exampleBtn').addEventListener('click', () => {
  $('#description').value = EXAMPLE
  renderPreview()
  setStatus('已填入示例，可改成自己的角色')
})
$('#part').addEventListener('change', () => renderPreview())
$('#view').addEventListener('change', () => {
  state.view = $('#view').value
  state.refs = {}
  state.results = {}
  renderResults()
  renderPreview()
})
for (const radio of document.querySelectorAll('input[name=style]')) {
  radio.addEventListener('change', () => {
    state.style = radio.value
    state.results = {}
    renderResults()
    renderPreview()
  })
}
$('#model').addEventListener('change', () => { state.model = $('#model').value })
$('#generateBtn').addEventListener('click', generate)
$('#cancelBtn').addEventListener('click', () => { if (state.abort) state.abort.abort() })
$('#rememberKey').addEventListener('change', saveKey)
$('#apiKey').addEventListener('input', () => { if ($('#rememberKey').checked) saveKey() })

$('#handoffBtn').addEventListener('click', () => {
  if (GROUPS.some(g => !state.results[g])) return
  const parts = GROUPS.map(g => ({ group: g, png: state.results[g].processedUrl }))
  const msg = { type: 'studio-parts', parts, view: state.view, style: state.style, headScale: state.style === 'chibi' ? 2 : 1 }
  if (window.parent !== window) parent.postMessage(msg, '*')
  else {
    setStatus('请下载 6 张透明图，打开 import.html 上传；或从 studio.html 打开可一键传送。')
  }
})

function boot () {
  if (new URLSearchParams(location.search).has('embed')) {
    const h = document.querySelector('header'); if (h) h.style.display = 'none'
  }
  const saved = sessionStorage.getItem('aruhub_key')
  if (saved) { $('#apiKey').value = saved; $('#rememberKey').checked = true }
  const savedBase = sessionStorage.getItem('image_api_base')
  if (savedBase) $('#apiBase').value = savedBase
  renderPreview()
  setStatus('先填 Key 和角色描写，再选部位/风格。')
}
boot()
