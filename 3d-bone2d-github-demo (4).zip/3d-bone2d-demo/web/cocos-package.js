// Cocos Creator 3.8.4 导出包里的两个文本文件：DragonBonesPlayer.ts + README.md。
// 纯字符串构造，浏览器和 Node 都能用。

export function cocosPlayerSource ({ armatureName = 'male', defaultAnimation = 'Idle_A' } = {}) {
  return `import { _decorator, Component, dragonBones } from 'cc';
const { ccclass, property } = _decorator;

/**
 * Cocos Creator 3.8.4 DragonBones 播放器。
 * 1. 把本脚本放进 assets/scripts；
 * 2. Canvas 下新建节点，添加本组件；
 * 3. 把 *_ske.json 拖到 Dragon Asset，*_tex.json 拖到 Dragon Atlas Asset；
 * 4. 运行。
 */
@ccclass('DragonBonesPlayer')
export class DragonBonesPlayer extends Component {
    @property(dragonBones.DragonBonesAsset)
    dragonAsset: dragonBones.DragonBonesAsset | null = null;

    @property(dragonBones.DragonBonesAtlasAsset)
    dragonAtlasAsset: dragonBones.DragonBonesAtlasAsset | null = null;

    @property
    armatureName = '${armatureName}';

    @property
    animationName = '${defaultAnimation}';

    /** 0 = 无限循环；1 = 播一次；-1 = 用配置里的 playTimes */
    @property
    playTimes = 0;

    private _display: dragonBones.ArmatureDisplay | null = null;

    start () {
        if (!this.dragonAsset || !this.dragonAtlasAsset) {
            console.warn('[DragonBonesPlayer] 先指定 Dragon Asset 和 Dragon Atlas Asset');
            return;
        }

        let display = this.getComponent(dragonBones.ArmatureDisplay);
        if (!display) display = this.node.addComponent(dragonBones.ArmatureDisplay);

        display.dragonAsset = this.dragonAsset;
        display.dragonAtlasAsset = this.dragonAtlasAsset;
        display.armatureName = this.armatureName;
        display.playTimes = this.playTimes;
        display.playAnimation(this.animationName, this.playTimes);
        this._display = display;
    }

    /** 运行时切动画，例如 player.play('Walk') */
    play (name: string, times = this.playTimes) {
        this.animationName = name;
        this._display?.playAnimation(name, times);
    }

    get animationNames (): string[] {
        return this._display?.getAnimationNames() ?? [];
    }
}
`
}

export function cocosReadme ({
  char = 'male',
  view = 'side',
  packageName = char,
  armatureName = char,
  animations = [],
  texNames = [],
  boneCount = 0,
  vertexCount = 0,
  triangleCount = 0
} = {}) {
  const viewName = view === 'front' ? '正视' : '侧视'
  const texList = texNames.length ? texNames.join(', ') : `${packageName}_tex.png`
  return `# Cocos Creator 3.8.4 接入（DragonBones · ${char} · ${viewName}）

这是给 **Cocos Creator 3.8.4** 用的 DragonBones 5.5 资源，角色 **${char}**（${viewName}）。
数据已按 **300px = 1 米** 放大并居中，站立高约 550px。

Cocos Creator 3.8.x 的 DragonBones 组件支持 DragonBones **5.6.3 及以下**，这份是 5.5，可直接导入。

---

## 1. 拷贝资源

把包里的 \`assets/dragonbones\` 和 \`assets/scripts\` 复制到 Cocos 项目的 \`assets/\` 下：

~~~text
你的项目/assets/
  dragonbones/${packageName}/
    ${packageName}_ske.json   ← DragonBonesAsset（骨骼 + 动画）
    ${packageName}_tex.json   ← DragonBonesAtlasAsset（图集配置）
    ${packageName}_tex.png    ← 纹理
  scripts/
    DragonBonesPlayer.ts      ← 可选
~~~

Cocos 会按后缀自动识别：

- \`*_ske.json\` → DragonBonesAsset
- \`*_tex.json\` → DragonBonesAtlasAsset
- \`*_tex.png\` → 纹理

**不要改文件名后缀**；如果被识别成普通 JsonAsset，检查是否还是 \`_ske.json\` / \`_tex.json\`。

---

## 2. 在场景里用（不写代码也可以）

1. 新建/打开 **2D 场景**（Canvas + Camera）；
2. Canvas 下新建空节点，命名 \`${char}\`；
3. 添加组件 **DragonBones → ArmatureDisplay**；
4. 设置：
   - **Dragon Asset**：\`${packageName}_ske\`
   - **Dragon Atlas Asset**：\`${packageName}_tex\`
   - **Armature Name**：\`${armatureName}\`
   - **Animation**：\`${animations[0] || 'Idle_A'}\`
   - **Play Times**：\`0\`（循环）
5. 运行预览。角色在节点原点居中；如果太大，把节点 **Scale** 调到 0.5。

---

## 3. 用脚本播放/切动画

把 \`assets/scripts/DragonBonesPlayer.ts\` 拷进项目，编译后：

1. Canvas 下新建空节点，添加 **DragonBonesPlayer** 组件；
2. 指定 \`Dragon Asset\`、\`Dragon Atlas Asset\`；
3. 运行，默认播 \`${animations[0] || 'Idle_A'}\`。

运行时切换：

~~~ts
this.getComponent(DragonBonesPlayer)?.play('Walk');
~~~

可用动画：

~~~text
${animations.join('  ') || 'Idle_A'}
~~~

---

## 4. 常见问题

**角色太大/太小？**
数据是 300px = 1 米，${char} 约 550px 高；2D Canvas 下调节点 Scale 即可。

**贴图是整张色块/不显示？**
确认 \`${packageName}_tex.png\` 和 \`${packageName}_tex.json\` 一起导入，并检查 \`${packageName}_tex\` 这个
**DragonBonesAtlasAsset** 的 \`texture\` 是否指向 \`${packageName}_tex.png\`。正常会自动配对。

**动画名对不上？**
\`Armature Name\` 是 \`${armatureName}\`，不是 \`Armature\`。

**3D 场景看不到？**
\`ArmatureDisplay\` 是 2D 渲染组件，放在 Canvas/2D 层，不要挂到 3D 相机直接看的位置。

---

## 5. 资源信息

- 数据版本：DragonBones 5.5
- 骨骼：${boneCount} 根
- 网格：1 个蒙皮网格，${vertexCount} 顶点 / ${triangleCount} 三角
- 动画：${animations.length} 个，30fps；关键帧已抽稀
- 纹理：${texList}
- 授权：模型/动画来自 Mesh2Motion（CC0）；代码 MIT
`
}
