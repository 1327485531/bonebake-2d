// 演示页逻辑：加载烘焙好的 M2D 数据 → 渲染 + 骨架叠加 + 角色墙
import { M2DRuntime } from './runtime.js'
import { exportDragonBones as buildDragonBonesJSON } from './dragonbones-export.js'
import { cocosPlayerSource, cocosReadme } from './cocos-package.js'

const DATA_BASE = '../out/'
const $ = (id) => document.getElementById(id)

const state = {
  view: 'side',
  charIndex: null,
  animData: null,
  runtime: null,
  clipName: null,
  frame: 0,
  playing: true,
  speed: 1,
  showBones: true,
  showWire: false,
  sortDepth: true,
  t: 0,
  lastTs: 0,
  wall: []
}

async function loadView (view) {
  const [c, a, ai] = await Promise.all([
    fetch(`${DATA_BASE}${view}/characters.json`).then(r => r.json()),
    fetch(`${DATA_BASE}${view}/anim.json`).then(r => r.json()),
    // AI 皮肤是可选的：没有 characters-ai.json 时照常运行
    fetch(`${DATA_BASE}${view}/characters-ai.json`)
      .then(r => (r.ok ? r.json() : null))
      .catch(() => null)
  ])
  if (ai && ai.characters) Object.assign(c.characters, ai.characters)
  state.charIndex = c
  state.animData = a
}

function fillSelects () {
  const charSel = $('char')
  charSel.innerHTML = ''
  for (const name of Object.keys(state.charIndex.characters)) {
    const o = document.createElement('option')
    o.value = name
    o.textContent = state.charIndex.characters[name].ai ? `${name} · AI` : name
    charSel.appendChild(o)
  }
  const animSel = $('anim')
  animSel.innerHTML = ''
  for (const name of Object.keys(state.animData.clips)) {
    const o = document.createElement('option')
    o.value = name; o.textContent = name
    animSel.appendChild(o)
  }
  charSel.value = charSel.options[0].value
  animSel.value = [...animSel.options].some(o => o.value === 'Walk') ? 'Walk' : animSel.options[0].value
  $('ai-hd').style.display = (state.charIndex.characters.ai_ronin_v5 || state.charIndex.characters.ai_ronin_v2 || state.charIndex.characters.ai_ronin_hd) ? '' : 'none'
  $('ai-chibi').style.display = state.charIndex.characters.ai_chibi ? '' : 'none'
  $('ai-bake').style.display = state.charIndex.characters.ai_police ? '' : 'none'
}

/** 计算"能装下这个角色这套动画"的视野范围（只按当前动画算，人物才够大） */
function computeFit (rt, clip) {
  const [x0, y0, x1, y1] = rt.meshBounds
  let mnx = x0, mny = y0, mxx = x1, mxy = y1
  const clips = clip ? [clip] : Object.values(state.animData.clips)
  for (const c of clips) {
    rt.setAnimation(c)
    const step = Math.max(1, Math.floor(c.frames / 24))
    for (let f = 0; f < c.frames; f += step) {
      rt.pose(f)
      for (const g of rt.globals) {
        mnx = Math.min(mnx, g[4] - 0.12); mxx = Math.max(mxx, g[4] + 0.12)
        mny = Math.min(mny, g[5] - 0.12); mxy = Math.max(mxy, g[5] + 0.12)
      }
    }
  }
  return [mnx, mny, mxx, mxy]
}

async function loadMainCharacter (name) {
  const def = state.charIndex.characters[name]
  const canvas = $('gl')
  if (state.runtime) { state.runtime.disposeBuffers() }
  const rt = new M2DRuntime(canvas, $('overlay'))
  await rt.loadCharacter(def, DATA_BASE + state.view + '/', name)
  rt.fitBounds = computeFit(rt, state.animData.clips[state.clipName || $('anim').value])
  state.runtime = rt
  $('i-char').textContent = name
  $('i-bones').textContent = def.bones.length
  $('i-mesh').textContent = `${def.mesh.verts.length / 2} / ${def.mesh.parts.reduce((s, p) => s + p.indices.length / 3, 0)}`
  $('i-skin').textContent = def.ai
    ? (def.ai.kind === 'parts' ? 'AI 分块皮肤（6 块图集）'
      : def.ai.kind === 'atlas-bake' ? 'AI 贴图烘焙（原 UV）'
        : 'AI 皮肤（平面投影 UV）')
    : def.autoSkinned ? '自动蒙皮' : '模型自带'
  return rt
}

/** 按元素实际显示尺寸设置画布（角色墙也要近距离看） */
function viewportFor (canvas) {
  const dpr = Math.min(2, window.devicePixelRatio || 1)
  const w = Math.max(80, canvas.clientWidth || canvas.width)
  const h = Math.max(60, canvas.clientHeight || canvas.height)
  return [Math.round(w * dpr), Math.round(h * dpr)]
}

function resizeMain () {
  const stage = document.querySelector('.stage')
  const dpr = Math.min(2, window.devicePixelRatio || 1)
  const w = Math.max(320, stage.clientWidth), h = Math.max(240, stage.clientHeight)
  state.runtime.setViewport(Math.round(w * dpr), Math.round(h * dpr))
}

function drawOverlay () {
  const rt = state.runtime
  const cv = $('overlay')
  const ctx = cv.getContext('2d')
  ctx.setTransform(1, 0, 0, 1, 0, 0)
  ctx.clearRect(0, 0, cv.width, cv.height)
  const dpr = Math.min(2, window.devicePixelRatio || 1)
  const lw = 2 * dpr

  if (state.showWire) {
    ctx.strokeStyle = 'rgba(110,168,254,0.16)'
    ctx.lineWidth = 1 * dpr
    ctx.beginPath()
    const verts = rt.charDef.mesh.verts
    // 只画一部分三角面，避免叠加层过重
    const step = Math.max(1, Math.floor(rt.tris.length / 4000))
    for (let t = 0; t < rt.tris.length; t += step) {
      const [a, b, c] = rt.tris[t]
      const pa = screenSkinned(rt, a), pb = screenSkinned(rt, b), pc = screenSkinned(rt, c)
      ctx.moveTo(pa[0], pa[1]); ctx.lineTo(pb[0], pb[1]); ctx.lineTo(pc[0], pc[1]); ctx.closePath()
    }
    ctx.stroke()
  }

  if (!state.showBones) return
  ctx.lineWidth = lw
  ctx.strokeStyle = 'rgba(110,168,254,0.95)'
  ctx.beginPath()
  for (let i = 0; i < rt.nBones; i++) {
    const p = rt.parentOf[i]
    if (p === -1) continue
    const a = rt.toScreen(rt.globals[i][4], rt.globals[i][5])
    const b = rt.toScreen(rt.globals[p][4], rt.globals[p][5])
    ctx.moveTo(a[0], a[1]); ctx.lineTo(b[0], b[1])
  }
  ctx.stroke()
  ctx.fillStyle = '#ffd166'
  for (let i = 0; i < rt.nBones; i++) {
    const p = rt.toScreen(rt.globals[i][4], rt.globals[i][5])
    ctx.beginPath(); ctx.arc(p[0], p[1], 2.1 * dpr, 0, Math.PI * 2); ctx.fill()
  }
}

const skinTmp = { p: [0, 0] }
function screenSkinned (rt, v) {
  const mesh = rt.charDef.mesh
  const bx = mesh.verts[v * 2], by = mesh.verts[v * 2 + 1]
  let x = 0, y = 0
  for (let k = 0; k < 4; k++) {
    const w = mesh.skinWeights[v * 4 + k]
    if (w <= 0) continue
    const bi = mesh.skinIndices[v * 4 + k]
    const M = mulArr(rt.globals[bi], rt.bindInverse[bi])
    x += w * (M[0] * bx + M[2] * by + M[4])
    y += w * (M[1] * bx + M[3] * by + M[5])
  }
  return rt.toScreen(x, y)
}
function mulArr (A, B) {
  return [
    A[0] * B[0] + A[2] * B[1], A[1] * B[0] + A[3] * B[1],
    A[0] * B[2] + A[2] * B[3], A[1] * B[2] + A[3] * B[3],
    A[0] * B[4] + A[2] * B[5] + A[4], A[1] * B[4] + A[3] * B[5] + A[5]
  ]
}

function tick (ts) {
  const dt = state.lastTs ? Math.min(0.1, (ts - state.lastTs) / 1000) : 0
  state.lastTs = ts
  const rt = state.runtime
  if (rt && rt.clip && rt.buffers) {
    const fps = state.animData.fps
    if (state.playing) {
      state.t += dt * state.speed
      const dur = rt.clip.duration
      if (state.t > dur) state.t -= dur
      state.frame = Math.floor(state.t * fps) % rt.clip.frames
    }
    rt.pose(state.frame)
    if (state.sortDepth) {
      rt.render()
    } else {
      rt.boneDepths.fill(0)
      rt.render()
    }
    drawOverlay()
    $('i-frame').textContent = state.frame
    $('i-draws').textContent = (rt.lastDraws || []).length
    $('framev').textContent = state.frame
    $('scrub').value = state.frame
  }
  // 角色墙同步
  for (const w of state.wall) {
    if (!w.rt || !w.rt.clip || !w.rt.buffers) continue
    w.rt.pose(state.frame % w.rt.clip.frames)
    w.rt.render()
  }
  requestAnimationFrame(tick)
}

async function buildWall () {
  const wall = $('wall')
  wall.innerHTML = ''
  const prefer = ['monster', 'swat_male', 'killer_4', 'doctor_m', 'police_male', 'male_5', 'female_8', 'female', 'male']
  const have = Object.keys(state.charIndex.characters)
  const picks = prefer.filter(p => have.includes(p)).slice(0, 4)
  for (const name of picks) {
    const cell = document.createElement('div')
    cell.className = 'cell'
    const cv = document.createElement('canvas')
    const label = document.createElement('div')
    label.textContent = name
    cell.appendChild(cv); cell.appendChild(label)
    wall.appendChild(cell)
    const rt = new M2DRuntime(cv, null)
    await rt.loadCharacter(state.charIndex.characters[name], DATA_BASE + state.view + '/', name)
    rt.fitBounds = computeFit(rt, state.animData.clips[state.clipName] || Object.values(state.animData.clips)[0])
    rt.setViewport(...viewportFor(cv))
    state.wall.push({ name, rt, canvas: cv })
  }
}


// ---------------- 导出当前角色的 Cocos Creator 3.8.4 包（三件套 + 脚本 + README，ZIP） ----------------
const CRC_TABLE = (() => {
  const t = new Uint32Array(256)
  for (let n = 0; n < 256; n++) {
    let c = n
    for (let k = 0; k < 8; k++) c = (c & 1) ? (0xedb88320 ^ (c >>> 1)) : (c >>> 1)
    t[n] = c >>> 0
  }
  return t
})()

function crc32 (data) {
  let c = 0xffffffff
  for (let i = 0; i < data.length; i++) c = CRC_TABLE[(c ^ data[i]) & 0xff] ^ (c >>> 8)
  return (c ^ 0xffffffff) >>> 0
}

function dosDateTime (d = new Date()) {
  const year = Math.max(1980, d.getFullYear())
  const date = ((year - 1980) << 9) | ((d.getMonth() + 1) << 5) | d.getDate()
  const time = (d.getHours() << 11) | (d.getMinutes() << 5) | (d.getSeconds() >> 1)
  return { date, time }
}

/** 最小 ZIP（store，无压缩）：DragonBones JSON + 图集 */
function zipStore (files) {
  const enc = new TextEncoder()
  const chunks = [], central = []
  const { date, time } = dosDateTime()
  let offset = 0
  for (const f of files) {
    const name = enc.encode(f.path)
    const data = f.data instanceof Uint8Array ? f.data : new Uint8Array(f.data)
    const crc = crc32(data)
    const local = new Uint8Array(30 + name.length)
    const dv = new DataView(local.buffer)
    dv.setUint32(0, 0x04034b50, true)
    dv.setUint16(4, 20, true)
    dv.setUint16(6, 0x0800, true)
    dv.setUint16(8, 0, true)
    dv.setUint16(10, time, true)
    dv.setUint16(12, date, true)
    dv.setUint32(14, crc, true)
    dv.setUint32(18, data.length, true)
    dv.setUint32(22, data.length, true)
    dv.setUint16(26, name.length, true)
    dv.setUint16(28, 0, true)
    local.set(name, 30)
    chunks.push(local, data)

    const cen = new Uint8Array(46 + name.length)
    const cv = new DataView(cen.buffer)
    cv.setUint32(0, 0x02014b50, true)
    cv.setUint16(4, 20, true)
    cv.setUint16(6, 20, true)
    cv.setUint16(8, 0x0800, true)
    cv.setUint16(10, 0, true)
    cv.setUint16(12, time, true)
    cv.setUint16(14, date, true)
    cv.setUint32(16, crc, true)
    cv.setUint32(20, data.length, true)
    cv.setUint32(24, data.length, true)
    cv.setUint16(28, name.length, true)
    cv.setUint16(30, 0, true)
    cv.setUint16(32, 0, true)
    cv.setUint16(34, 0, true)
    cv.setUint16(36, 0, true)
    cv.setUint32(38, 0, true)
    cv.setUint32(42, offset, true)
    cen.set(name, 46)
    central.push(cen)
    offset += local.length + data.length
  }
  const centralSize = central.reduce((s, c) => s + c.length, 0)
  const end = new Uint8Array(22)
  const ev = new DataView(end.buffer)
  ev.setUint32(0, 0x06054b50, true)
  ev.setUint16(4, 0, true)
  ev.setUint16(6, 0, true)
  ev.setUint16(8, files.length, true)
  ev.setUint16(10, files.length, true)
  ev.setUint32(12, centralSize, true)
  ev.setUint32(16, offset, true)
  ev.setUint16(20, 0, true)
  return new Blob([...chunks, ...central, end], { type: 'application/zip' })
}

async function exportCurrentDragonBones () {
  const view = state.view
  const char = $('char').value
  const charDef = state.charIndex && state.charIndex.characters[char]
  if (!charDef || !state.animData) { alert('角色数据还没加载完'); return }

  const packageName = view === 'front' ? `${char}_front` : char
  const root = `${packageName}-cocos384`
  const btn = $('export-db')
  const old = btn.textContent
  btn.disabled = true
  btn.textContent = '导出中…'
  try {
    // 收集这个角色用到的贴图（基础角色 tex/…；AI 角色 ai/…）
    const rels = [...new Set((charDef.mesh.parts || []).map(p => charDef.textures[p.tex]).filter(Boolean))]
    const texMap = new Map()
    for (const rel of rels) {
      const url = new URL(`${DATA_BASE}${view}/${rel}`, location.href)
      const r = await fetch(url)
      if (!r.ok) throw new Error(`贴图 ${rel}: HTTP ${r.status}`)
      const blob = await r.blob()
      const bmp = await createImageBitmap(blob)
      const fileName = rel.split('/').pop().replace(/[^\w.-]/g, '_')
      const subName = fileName.replace(/\.[^.]+$/, '')
      texMap.set(rel, {
        blob,
        width: bmp.width,
        height: bmp.height,
        fileName,
        subName
      })
      bmp.close()
    }

    // Cocos 用标准 DragonBones 5.5 数据，不需要 Pro 的 edges/userEdges。
    const db = buildDragonBonesJSON({
      charDef,
      charName: char,
      animData: state.animData,
      clips: null,
      name: packageName,
      meshEdges: false,
      textureResolver: (rel) => {
        const t = texMap.get(rel)
        if (!t) return null
        return { name: t.subName, imagePath: t.fileName, width: t.width, height: t.height }
      }
    })

    const armature = db.armature[0]
    const animations = (armature.animation || []).map(a => a.name)
    // 三件套：<package>_ske.json + <package>_tex.json + <package>_tex.png
    // Cocos 按 _ske/_tex 后缀识别成 DragonBonesAsset / DragonBonesAtlasAsset。
    const ske = {
      name: packageName,
      version: db.version,
      compatibleVersion: db.compatibleVersion,
      frameRate: db.frameRate,
      armature: db.armature
    }

    const texConfigs = []
    const pngFiles = []
    const texNames = []
    let ti = 0
    for (const atlas of db.textureAtlas) {
      const imgFile = atlas.imagePath.split('/').pop()
      const texName = ti === 0 ? packageName : `${packageName}_${ti}`
      const texFile = `${texName}_tex.json`
      const pngName = `${texName}_tex.png`
      const tex = {
        name: texName,
        imagePath: pngName,
        width: atlas.width,
        height: atlas.height,
        SubTexture: atlas.SubTexture
      }
      texConfigs.push({
        path: `${root}/assets/dragonbones/${packageName}/${texFile}`,
        data: new TextEncoder().encode(JSON.stringify(tex))
      })
      const key = [...texMap.keys()].find(k => texMap.get(k).fileName === imgFile)
      if (!key) throw new Error(`贴图资源 ${imgFile} 未找到`)
      pngFiles.push({
        path: `${root}/assets/dragonbones/${packageName}/${pngName}`,
        data: new Uint8Array(await texMap.get(key).blob.arrayBuffer())
      })
      texNames.push(pngName)
      ti++
    }

    let triangleCount = 0
    for (const part of charDef.mesh.parts) triangleCount += part.indices.length / 3
    const readme = cocosReadme({
      char,
      view,
      packageName,
      armatureName: char,
      animations,
      texNames,
      boneCount: charDef.bones.length,
      vertexCount: charDef.mesh.verts.length / 2,
      triangleCount
    })

    const files = [
      { path: `${root}/README.md`, data: new TextEncoder().encode(readme) },
      {
        path: `${root}/assets/dragonbones/${packageName}/${packageName}_ske.json`,
        data: new TextEncoder().encode(JSON.stringify(ske))
      },
      ...texConfigs,
      ...pngFiles,
      {
        path: `${root}/assets/scripts/DragonBonesPlayer.ts`,
        data: new TextEncoder().encode(cocosPlayerSource({
          armatureName: char,
          defaultAnimation: animations[0] || 'Idle_A'
        }))
      }
    ]

    const blob = zipStore(files)
    const a = document.createElement('a')
    a.href = URL.createObjectURL(blob)
    a.download = `${packageName}-cocos384.zip`
    document.body.appendChild(a)
    a.click()
    a.remove()
    setTimeout(() => URL.revokeObjectURL(a.href), 10000)
  } catch (e) {
    alert('导出 Cocos 包失败：' + e.message)
  } finally {
    btn.disabled = false
    btn.textContent = old
  }
}

async function boot () {
  const q = new URLSearchParams(location.search)
  if (q.get('view') === 'front') state.view = 'front'
  $('view').value = state.view
  await loadView(state.view)
  fillSelects()
  if (q.get('char') && state.charIndex.characters[q.get('char')]) $('char').value = q.get('char')
  if (q.get('clip') && state.animData.clips[q.get('clip')]) $('anim').value = q.get('clip')
  await loadMainCharacter($('char').value)
  state.runtime.setAnimation(state.animData.clips[$('anim').value])
  state.clipName = $('anim').value
  $('scrub').max = state.animData.clips[state.clipName].frames - 1
  $('i-frames').textContent = state.animData.clips[state.clipName].frames
  resizeMain()
  await buildWall()

  // URL 参数：?view=front&char=zombie&clip=Walk&frame=20&play=0（方便和龙骨页对照）
  const wantFrame = Number(q.get('frame'))
  if (Number.isFinite(wantFrame) && q.get('frame') !== null) {
    state.playing = false
    state.frame = Math.max(0, Math.min(state.animData.clips[state.clipName].frames - 1, Math.floor(wantFrame)))
    state.t = state.frame / state.animData.fps
    $('play').textContent = '播放'
    $('play').classList.add('on')
  }
  if (q.get('play') === '0') {
    state.playing = false
    $('play').textContent = '播放'
    $('play').classList.add('on')
  }
  // 截图/对照用：?bones=0 / ?wire=1 / ?depth=0
  if (q.get('bones') === '0') { state.showBones = false; $('bones').classList.remove('on') }
  if (q.get('wire') === '1') { state.showWire = true; $('wire').classList.add('on') }
  if (q.get('depth') === '0') { state.sortDepth = false; $('depth').classList.remove('on') }

  $('char').addEventListener('change', async (e) => {
    await loadMainCharacter(e.target.value)
    const clip = state.animData.clips[state.clipName]
    state.runtime.setAnimation(clip)
    resizeMain()
  })
  $('anim').addEventListener('change', (e) => {
    state.clipName = e.target.value
    const clip = state.animData.clips[state.clipName]
    state.runtime.setAnimation(clip)
    state.t = 0; state.frame = 0
    $('scrub').max = clip.frames - 1
    $('i-frames').textContent = clip.frames
    // 视野跟着这套动画重新取景，人物才够大
    state.runtime.fitBounds = computeFit(state.runtime, clip)
    state.runtime.setAnimation(clip)
    resizeMain()
    for (const w of state.wall) {
      if (!w.rt) continue
      w.rt.fitBounds = computeFit(w.rt, clip)
      w.rt.setAnimation(clip)
      w.rt.setViewport(...viewportFor(w.canvas))
    }
  })
  $('view').addEventListener('change', async (e) => {
    state.view = e.target.value
    await loadView(state.view)
    // 贴图缓存在旧 runtime 里，重建主角色与角色墙
    for (const w of state.wall) w.rt.disposeBuffers()
    state.wall = []
    await loadMainCharacter($('char').value)
    state.runtime.setAnimation(state.animData.clips[state.clipName])
    resizeMain()
    await buildWall()
  })
  $('play').addEventListener('click', (e) => {
    state.playing = !state.playing
    e.target.textContent = state.playing ? '暂停' : '播放'
    e.target.classList.toggle('on', !state.playing)
  })
  $('speed').addEventListener('input', (e) => {
    state.speed = Number(e.target.value)
    $('speedv').textContent = state.speed.toFixed(1) + '×'
  })
  $('scrub').addEventListener('input', (e) => {
    state.frame = Number(e.target.value)
    state.t = state.frame / state.animData.fps
    state.playing = false
    $('play').textContent = '播放'
    $('play').classList.add('on')
  })
  $('bones').addEventListener('click', (e) => { state.showBones = !state.showBones; e.target.classList.toggle('on', state.showBones) })
  $('wire').addEventListener('click', (e) => { state.showWire = !state.showWire; e.target.classList.toggle('on', state.showWire) })
  $('depth').addEventListener('click', (e) => { state.sortDepth = !state.sortDepth; e.target.classList.toggle('on', state.sortDepth) })
  $('ai-hd').addEventListener('click', () => {
    // v5 = 纹理姿态 UV + 独立部件贴图；没有时依次退回 v2 / hd
    const best = state.charIndex.characters.ai_ronin_v5 ? 'ai_ronin_v5'
      : state.charIndex.characters.ai_ronin_v2 ? 'ai_ronin_v2' : 'ai_ronin_hd'
    location.href = `index.html?view=side&char=${best}&clip=Walk&frame=0&play=0&bones=0`
  })
  $('ai-chibi').addEventListener('click', () => {
    // Q 版看正视图：大头 + 卡通五官最清楚；侧视图可以手动切
    location.href = 'index.html?view=front&char=ai_chibi&clip=Walk&frame=0&play=0&bones=0'
  })
  $('ai-bake').addEventListener('click', () => {
    location.href = 'index.html?view=front&char=ai_police&clip=Walk&frame=0&play=0&bones=0'
  })
  $('import-ui').addEventListener('click', () => {
    // 可视化导入器是单独的本地服务；默认 8898（IMPORT_UI_PORT 可改）
    window.open('http://127.0.0.1:8898/', '_blank', 'noopener')
  })
  $('export-db').addEventListener('click', exportCurrentDragonBones)

  $('db').addEventListener('click', () => {
    const q = new URLSearchParams({
      view: state.view,
      char: $('char').value,
      clip: state.clipName,
      frame: String(state.frame),
      play: state.playing ? '1' : '0'
    })
    location.href = 'dragonbones.html?' + q.toString()
  })

  window.addEventListener('resize', () => {
    resizeMain()
    for (const w of state.wall) w.rt.setViewport(...viewportFor(w.canvas))
  })
  window.__ready = true
  window.__dbg = { state, skinBBox, glInfo }
  requestAnimationFrame(tick)
}

boot().catch(err => {
  document.body.insertAdjacentHTML('beforeend',
    `<pre style="color:#ff6b6b;padding:16px;white-space:pre-wrap">启动失败：${err.message}\n${err.stack || ''}</pre>`)
  throw err
})
// ---- 排查用：在页面里用运行时自己的数据复算蒙皮结果 + 读 GL 状态 ----
function skinBBox () {
  const rt = state.runtime
  if (!rt) return null
  const mesh = rt.charDef.mesh
  const n = mesh.verts.length / 2
  let mnx = 1e9, mny = 1e9, mxx = -1e9, mxy = -1e9
  for (let v = 0; v < n; v++) {
    const bx = mesh.verts[v * 2], by = mesh.verts[v * 2 + 1]
    let x = 0, y = 0
    for (let k = 0; k < 4; k++) {
      const w = mesh.skinWeights[v * 4 + k]
      if (w <= 0) continue
      const bi = mesh.skinIndices[v * 4 + k]
      const M = mulArr(rt.globals[bi], rt.bindInverse[bi])
      x += w * (M[0] * bx + M[2] * by + M[4])
      y += w * (M[1] * bx + M[3] * by + M[5])
    }
    mnx = Math.min(mnx, x); mxx = Math.max(mxx, x)
    mny = Math.min(mny, y); mxy = Math.max(mxy, y)
  }
  return { mnx, mny, mxx, mxy, frame: state.frame, draws: (state.runtime.lastDraws || []).length }
}

function glInfo () {
  const rt = state.runtime
  if (!rt) return null
  const gl = rt.gl
  return {
    error: gl.getError(),
    maxVertexUniformVectors: gl.getParameter(gl.MAX_VERTEX_UNIFORM_VECTORS),
    nBones: rt.nBones,
    locs: rt.loc,
    xform: rt.xform,
    fitBounds: rt.fitBounds,
    bone0: Array.from(rt.boneData.slice(0, 8)),
    bone1: [rt.boneData[8], rt.boneData[9], rt.boneData[10], rt.boneData[11], rt.boneData[12], rt.boneData[13]],
    skinIdx0: Array.from(rt.charDef.mesh.skinIndices.slice(0, 8)),
    idxOrderHead: Array.from(rt.indexOrder.slice(0, 9)),
    nTri: rt.nTri
  }
}
