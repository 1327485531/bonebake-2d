// 纯浏览器版分块皮肤构建：把 6 张手绘部件图 + male 基础网格 → characters-ai.json + atlas PNG。
// 由 web/import.js 在“静态模式”（没有 /api）时调用；也可以单独用 window.OfflineBuild。
//
// 逻辑从 tools/ai-image.mjs / tools/pose2d.mjs 移植；不依赖 Node、不上传服务器。
;(function () {
  'use strict'

  const GROUP_ORDER = ['head', 'torso', 'arm_l', 'arm_r', 'leg_l', 'leg_r']
  const GROUP_LABEL = {
    head: '头 / 脖子',
    torso: '躯干 / 夹克',
    arm_l: '左臂 + 手',
    arm_r: '右臂 + 手（机械臂）',
    leg_l: '左腿 + 靴',
    leg_r: '右腿 + 靴'
  }

  const round = (v, d) => {
    const f = 10 ** d
    return Math.round(v * f) / f
  }

  // ---------------- 抠图 / 裁边（从 ai-image.mjs 移植） ----------------
  const dist2 = (d, i, r, g, b) => {
    const dr = d[i] - r, dg = d[i + 1] - g, db = d[i + 2] - b
    return dr * dr + dg * dg + db * db
  }
  function pickBackground (img) {
    const { width, height, data } = img
    const pts = [[2, 2], [width - 3, 2], [2, height - 3], [width - 3, height - 3]]
    const rgb = [0, 0, 0]
    for (const [x, y] of pts) {
      const i = (y * width + x) * 4
      rgb[0] += data[i]; rgb[1] += data[i + 1]; rgb[2] += data[i + 2]
    }
    return rgb.map(v => Math.round(v / pts.length))
  }

  /** 去背景 + 裁到内容包围盒 + 2px 补边；返回 {width,height,data,u0..v1} */
  function processImage (img, padRatio = 0.012) {
    const { width: w, height: h, data } = img
    let hasAlpha = false
    for (let i = 3; i < data.length; i += 4) if (data[i] < 240) { hasAlpha = true; break }
    const opaque = new Uint8Array(w * h).fill(1)
    if (hasAlpha) {
      for (let i = 0; i < w * h; i++) opaque[i] = data[i * 4 + 3] > 32 ? 1 : 0
      for (let i = 0; i < w * h; i++) if (opaque[i]) data[i * 4 + 3] = 255
    } else {
      const [r, g, b] = pickBackground(img)
      const tol = 105 * 105
      const stack = []
      const seen = new Uint8Array(w * h)
      const push = (x, y) => {
        if (x < 0 || y < 0 || x >= w || y >= h) return
        const i = y * w + x
        if (seen[i] || !opaque[i]) return
        if (dist2(data, i * 4, r, g, b) > tol) return
        seen[i] = 1; stack.push(i)
      }
      for (let x = 0; x < w; x++) { push(x, 0); push(x, h - 1) }
      for (let y = 0; y < h; y++) { push(0, y); push(w - 1, y) }
      while (stack.length) {
        const i = stack.pop()
        opaque[i] = 0
        const x = i % w, y = (i / w) | 0
        push(x - 1, y); push(x + 1, y); push(x, y - 1); push(x, y + 1)
      }
      // 清品红描边：从边缘往里削 4 圈
      for (let pass = 0; pass < 4; pass++) {
        const kill = []
        for (let y = 1; y < h - 1; y++) {
          for (let x = 1; x < w - 1; x++) {
            const i = y * w + x
            if (!opaque[i]) continue
            if (!opaque[i - 1] || !opaque[i + 1] || !opaque[i - w] || !opaque[i + w]) kill.push(i)
          }
        }
        if (kill.length === 0) break
        for (const i of kill) { opaque[i] = 0; data[i * 4 + 3] = 0 }
      }
    }
    for (let i = 0; i < w * h; i++) if (!opaque[i]) data[i * 4 + 3] = 0
    // 清高饱和品红残留
    for (let i = 0; i < w * h; i++) {
      if (!opaque[i]) continue
      const R = data[i * 4], G = data[i * 4 + 1], B = data[i * 4 + 2]
      if (R > 70 && B > 70 && G < Math.min(R, B) * 0.7) { opaque[i] = 0; data[i * 4 + 3] = 0 }
    }
    // 紫色描边 despill
    for (let i = 0; i < w * h; i++) {
      if (!opaque[i]) continue
      const R = data[i * 4], G = data[i * 4 + 1], B = data[i * 4 + 2]
      const m = Math.min(R, B) - G
      if (m > 8) {
        data[i * 4] = Math.max(0, Math.round(R - m * 0.85))
        data[i * 4 + 2] = Math.max(0, Math.round(B - m * 0.85))
      }
    }
    for (let i = 0; i < w * h; i++) if (!opaque[i]) data[i * 4 + 3] = 0

    let x0 = w, y0 = h, x1 = -1, y1 = -1
    for (let y = 0; y < h; y++) {
      for (let x = 0; x < w; x++) {
        if (!opaque[y * w + x]) continue
        if (x < x0) x0 = x
        if (x > x1) x1 = x
        if (y < y0) y0 = y
        if (y > y1) y1 = y
      }
    }
    if (x1 < 0) throw new Error('抠图后没有任何不透明像素')
    const pad = Math.max(2, Math.round(Math.min(w, h) * padRatio * 0.2))

    const dist = new Int32Array(w * h).fill(-1)
    const queue = []
    for (let i = 0; i < w * h; i++) if (opaque[i]) { dist[i] = 0; queue.push(i) }
    let head = 0
    while (head < queue.length) {
      const i = queue[head++]
      const d0 = dist[i]
      if (d0 >= pad) continue
      const x = i % w, y = (i / w) | 0
      for (const [nx, ny] of [[x - 1, y], [x + 1, y], [x, y - 1], [x, y + 1]]) {
        if (nx < 0 || ny < 0 || nx >= w || ny >= h) continue
        const ni = ny * w + nx
        if (dist[ni] >= 0) continue
        dist[ni] = d0 + 1
        for (let k = 0; k < 3; k++) data[ni * 4 + k] = data[i * 4 + k]
        data[ni * 4 + 3] = 255
        queue.push(ni)
      }
    }

    const cx0 = Math.max(0, x0 - pad), cy0 = Math.max(0, y0 - pad)
    const cx1 = Math.min(w - 1, x1 + pad), cy1 = Math.min(h - 1, y1 + pad)
    const cw = cx1 - cx0 + 1, ch = cy1 - cy0 + 1
    const out = new Uint8Array(cw * ch * 4)
    for (let y = 0; y < ch; y++) {
      const src = ((y + cy0) * w + cx0) * 4
      out.set(data.subarray(src, src + cw * 4), y * cw * 4)
    }
    return {
      width: cw,
      height: ch,
      data: out,
      u0: (x0 - cx0) / cw,
      v0: (y0 - cy0) / ch,
      u1: (x1 + 1 - cx0) / cw,
      v1: (y1 + 1 - cy0) / ch
    }
  }

  /** 剥掉品红 guide（模板上的轮廓/取景框/十字） */
  function stripGuide (img, keepGuide) {
    if (keepGuide) return img
    const d = img.data
    for (let i = 0; i < d.length; i += 4) {
      const r = d[i], g = d[i + 1], b = d[i + 2], a = d[i + 3]
      if (a === 0) continue
      const lo = Math.min(r, b)
      if (r > 100 && b > 100 && Math.abs(r - b) < 70 && g < lo * 0.92) d[i + 3] = 0
      else if (a < 8) d[i + 3] = 0
    }
    return img
  }

  // ---------------- 身体分块 / UV / 图集 ----------------
  function groupOfBone (name) {
    const n = String(name).toLowerCase()
    const side = /(^|_)l($|_)/.test(n) || n.endsWith('_l') ? 'l' : /(^|_)r($|_)/.test(n) || n.endsWith('_r') ? 'r' : ''
    if (/(head|neck|eye|jaw|face|hair)/.test(n)) return 'head'
    if (/(upperarm|lowerarm|forearm|hand|finger|thumb|index|middle|ring|pinky)/.test(n)) return 'arm_' + side
    if (/(thigh|calf|shin|foot|ball|toe)/.test(n)) return 'leg_' + side
    return 'torso'
  }

  function finalizeGroups (groups, mesh) {
    for (const g of groups) {
      g.verts = [...new Set(g.tris.flatMap(tr => [tr.a, tr.b, tr.c]))].sort((a, b) => a - b)
      let minX = 1e9, minY = 1e9, maxX = -1e9, maxY = -1e9
      for (const v of g.verts) {
        const x = mesh.verts[v * 2], y = mesh.verts[v * 2 + 1]
        if (x < minX) minX = x
        if (x > maxX) maxX = x
        if (y < minY) minY = y
        if (y > maxY) maxY = y
      }
      g.box = [minX, minY, maxX, maxY]
    }
  }

  function dominantBone (mesh, tr) {
    const acc = new Map()
    for (const v of [tr.a, tr.b, tr.c]) {
      for (let k = 0; k < 4; k++) {
        const w = mesh.skinWeights[v * 4 + k]
        if (w <= 0) continue
        const bi = mesh.skinIndices[v * 4 + k]
        acc.set(bi, (acc.get(bi) || 0) + w)
      }
    }
    let best = 0, bestW = -1
    for (const [bi, w] of acc) if (w > bestW) { bestW = w; best = bi }
    return best
  }

  function splitMeshGroups (charDef) {
    const mesh = charDef.mesh
    const nBones = charDef.bones.length
    const boneGroup = charDef.bones.map(b => groupOfBone(b.name))
    const groupIndex = new Map(GROUP_ORDER.map((g, i) => [g, i]))
    const groups = GROUP_ORDER.map(name => ({ name, tris: [], verts: new Set() }))

    // 与 tools/ai-image.mjs 对齐：优先用修复前固化的三角分组，避免权重修完后
    // 肩部边界三角形跳到别的块，模板/ref/贴图出现尖刺。
    const totalTris = mesh.parts.reduce((s, part) => s + part.indices.length / 3, 0)
    if (Array.isArray(charDef.partGroups) && charDef.partGroups.length === totalTris) {
      let tGlobal = 0
      mesh.parts.forEach(part => {
        const offs = part.depthOffsets || []
        for (let t = 0; t < part.indices.length; t += 3) {
          const gi = charDef.partGroups[tGlobal++]
          const a = part.indices[t], b = part.indices[t + 1], c = part.indices[t + 2]
          if (!(gi >= 0 && gi < GROUP_ORDER.length)) throw new Error('partGroups 里有无效分组索引')
          groups[gi].tris.push({ a, b, c, offset: offs[t / 3] || 0 })
        }
      })
      finalizeGroups(groups, mesh)
      return groups.filter(g => g.tris.length > 0)
    }

    mesh.parts.forEach(part => {
      const offs = part.depthOffsets || []
      for (let t = 0; t < part.indices.length; t += 3) {
        const a = part.indices[t], b = part.indices[t + 1], c = part.indices[t + 2]
        const score = new Map()
        for (const v of [a, b, c]) {
          for (let k = 0; k < 4; k++) {
            const w = mesh.skinWeights[v * 4 + k]
            if (w <= 0) continue
            const bi = mesh.skinIndices[v * 4 + k]
            if (bi < 0 || bi >= nBones) continue
            const g = boneGroup[bi]
            score.set(g, (score.get(g) || 0) + w)
          }
        }
        let best = 'torso', bestW = -1
        for (const g of GROUP_ORDER) {
          const w = score.get(g) || 0
          if (w > bestW) { bestW = w; best = g }
        }
        groups[groupIndex.get(best)].tris.push({ a, b, c, offset: offs[t / 3] || 0 })
      }
    })
    finalizeGroups(groups, mesh)
    return groups.filter(g => g.tris.length > 0)
  }

  function rebalanceNeck (groups, charDef) {
    const head = groups.find(g => g.name === 'head')
    const torso = groups.find(g => g.name === 'torso')
    if (!head || !torso) return groups
    const keep = []
    for (const tr of head.tris) {
      const bi = dominantBone(charDef.mesh, tr)
      const name = charDef.bones[bi] ? charDef.bones[bi].name : ''
      if (/neck/i.test(name)) torso.tris.push(tr)
      else keep.push(tr)
    }
    head.tris = keep
    finalizeGroups(groups, charDef.mesh)
    return groups
  }

  function vertsBox (positions, verts) {
    let minX = 1e9, minY = 1e9, maxX = -1e9, maxY = -1e9
    for (const v of verts) {
      const x = positions[v * 2], y = positions[v * 2 + 1]
      if (x < minX) minX = x
      if (x > maxX) maxX = x
      if (y < minY) minY = y
      if (y > maxY) maxY = y
    }
    return [minX, minY, maxX, maxY]
  }

  function planarUvsForBox (mesh, verts, box, frame, positions) {
    const [minX, minY, maxX, maxY] = box
    const w = maxX - minX || 1, h = maxY - minY || 1
    const { u0, v0, u1, v1 } = frame
    const out = new Array(verts.length * 2)
    for (let i = 0; i < verts.length; i++) {
      const v = verts[i]
      const x = (positions[v * 2] - minX) / w
      const y = (positions[v * 2 + 1] - minY) / h
      out[i * 2] = round(u0 + x * (u1 - u0), 5)
      out[i * 2 + 1] = round(v0 + (1 - y) * (v1 - v0), 5)
    }
    return out
  }

  function packAtlas (parts, { cols = 3, rows = 2, cellW = 650, cellH = 980, pad = 10, gap = 16 } = {}) {
    if (parts.length > cols * rows) throw new Error(`图集格子不够：${parts.length} 块 > ${cols}x${rows}`)
    const AW = cols * (cellW + gap) + gap
    const AH = rows * (cellH + gap) + gap
    if (AW > 4096 || AH > 4096) throw new Error(`图集太大 ${AW}x${AH}`)
    const data = new Uint8Array(AW * AH * 4)
    const frames = {}
    parts.forEach((p, i) => {
      const src = new Uint8Array(p.data.length)
      for (let j = 0; j < p.data.length; j += 4) {
        if (p.data[j + 3] === 0) continue
        src[j] = p.data[j]; src[j + 1] = p.data[j + 1]; src[j + 2] = p.data[j + 2]; src[j + 3] = p.data[j + 3]
      }
      const col = i % cols, row = (i / cols) | 0
      const cx = gap + col * (cellW + gap)
      const cy = gap + row * (cellH + gap)
      const availW = cellW - pad * 2, availH = cellH - pad * 2
      const s = Math.min(availW / p.width, availH / p.height)
      const dw = Math.max(1, Math.round(p.width * s))
      const dh = Math.max(1, Math.round(p.height * s))
      const dx = cx + pad + Math.floor((availW - dw) / 2)
      const dy = cy + pad + Math.floor((availH - dh) / 2)
      for (let y = 0; y < dh; y++) {
        const sy = Math.min(p.height - 1, (y + 0.5) / s - 0.5)
        const y0 = Math.max(0, Math.floor(sy)), y1 = Math.min(p.height - 1, y0 + 1)
        const fy = sy - y0
        for (let x = 0; x < dw; x++) {
          const sx = Math.min(p.width - 1, (x + 0.5) / s - 0.5)
          const x0 = Math.max(0, Math.floor(sx)), x1 = Math.min(p.width - 1, x0 + 1)
          const fx = sx - x0
          const di = ((dy + y) * AW + (dx + x)) * 4
          for (let k = 0; k < 4; k++) {
            const v00 = src[(y0 * p.width + x0) * 4 + k]
            const v10 = src[(y0 * p.width + x1) * 4 + k]
            const v01 = src[(y1 * p.width + x0) * 4 + k]
            const v11 = src[(y1 * p.width + x1) * 4 + k]
            const a = v00 + (v10 - v00) * fx
            const b = v01 + (v11 - v01) * fx
            data[di + k] = Math.round(a + (b - a) * fy)
          }
        }
      }
      frames[p.name] = {
        u0: (dx + p.u0 * dw) / AW,
        v0: (dy + p.v0 * dh) / AH,
        u1: (dx + p.u1 * dw) / AW,
        v1: (dy + p.v1 * dh) / AH
      }
    })
    return { width: AW, height: AH, data, frames }
  }

  // ---------------- 骨骼原点（大头缩放枢轴） ----------------
  function affine (x, y, r) {
    const c = Math.cos(r), s = Math.sin(r)
    return [c, s, -s, c, x, y]
  }
  function mul (A, B) {
    return [
      A[0] * B[0] + A[2] * B[1], A[1] * B[0] + A[3] * B[1],
      A[0] * B[2] + A[2] * B[3], A[1] * B[2] + A[3] * B[3],
      A[0] * B[4] + A[2] * B[5] + A[4], A[1] * B[4] + A[3] * B[5] + A[5]
    ]
  }
  function bindBoneOrigin (charDef, boneName) {
    const bones = charDef.bones
    const g = new Array(bones.length)
    for (let i = 0; i < bones.length; i++) {
      const b = bones[i]
      const L = affine(b.x, b.y, b.rot)
      g[i] = b.parent < 0 ? L : mul(g[b.parent], L)
    }
    const i = bones.findIndex(b => b.name === boneName)
    if (i < 0) throw new Error(`没有骨头 ${boneName}`)
    return [g[i][4], g[i][5]]
  }

  /**
   * 构建角色。
   * @param {object} opts
   * @param {object} opts.base        templates/<view>/base-male.json 里的 male 定义
   * @param {'side'|'front'} opts.view
   * @param {Array} opts.parts       6 个 processImage 结果 + name，顺序 GROUP_ORDER
   * @param {string} opts.name
   * @param {number} opts.headScale
   * @param {number[]|null} opts.poseVerts 侧视 Walk 0 的顶点位置（pose-walk0.json .verts）
   * @param {string} [opts.char]
   */
  function buildCharacter ({ base, view, parts, name, headScale = 1, poseVerts = null, char = 'male' }) {
    if (!base || !base.mesh || !base.bones) throw new Error('缺少 base 数据')
    if (!Array.isArray(parts) || parts.length !== 6) throw new Error('需要 6 块部件图')
    if (view === 'side' && !poseVerts) throw new Error('侧视构建需要 pose-walk0.json')

    const groups = splitMeshGroups(base)
    rebalanceNeck(groups, base)
    const atlas = packAtlas(parts, { cols: 3, rows: 2, cellW: 650, cellH: 980, pad: 10, gap: 16 })

    const src = base.mesh
    const newVerts = [], newUvs = [], newSkin = [], newWeights = [], newIdx = [], newOffsets = []
    const groupMeta = []

    for (const g of groups) {
      const part = parts.find(p => p.name === g.name)
      if (!part) throw new Error(`缺少 ${g.name} 的部件`)
      const posed = view === 'side' && (g.name === 'arm_l' || g.name === 'arm_r')
      const uvPositions = posed ? poseVerts : src.verts
      const uvBox = vertsBox(uvPositions, g.verts)
      const uv = planarUvsForBox(src, g.verts, uvBox, atlas.frames[g.name], uvPositions)

      const map = new Map()
      for (let i = 0; i < g.verts.length; i++) {
        const old = g.verts[i]
        map.set(old, newVerts.length / 2)
        newVerts.push(src.verts[old * 2], src.verts[old * 2 + 1])
        newUvs.push(uv[i * 2], uv[i * 2 + 1])
        for (let k = 0; k < 4; k++) {
          newSkin.push(src.skinIndices[old * 4 + k])
          newWeights.push(src.skinWeights[old * 4 + k])
        }
      }
      for (const tr of g.tris) {
        newIdx.push(map.get(tr.a), map.get(tr.b), map.get(tr.c))
        newOffsets.push(tr.offset)
      }
      groupMeta.push({
        name: g.name,
        label: GROUP_LABEL[g.name] || g.name,
        triangles: g.tris.length,
        vertices: g.verts.length,
        box: uvBox.map(v => round(v, 4)),
        pose: posed ? 'Walk:0' : 'bind',
        atlasFrame: atlas.frames[g.name]
      })
    }
    if (newVerts.length / 2 > 65535) throw new Error('合并后顶点超过 65535')

    const def = JSON.parse(JSON.stringify(base))
    def.textures = [`ai/${name}-atlas-${view}.png`]
    def.mesh = {
      verts: newVerts,
      uvs: newUvs,
      skinIndices: newSkin,
      skinWeights: newWeights,
      parts: [{
        base: 0,
        count: newIdx.length / 3,
        indices: newIdx,
        tex: 0,
        color: (src.parts[0] && src.parts[0].color) || [1, 1, 1, 1],
        depthOffsets: newOffsets
      }]
    }

    let chibi = null
    if (headScale !== 1) {
      const headIdx = groupMeta.findIndex(g => g.name === 'head')
      if (headIdx < 0) throw new Error('没有 head 组')
      let headOffset = 0
      for (let i = 0; i < headIdx; i++) headOffset += groupMeta[i].vertices
      const headCount = groupMeta[headIdx].vertices
      const [px, py] = bindBoneOrigin(base, 'head')
      for (let i = 0; i < headCount; i++) {
        const o = (headOffset + i) * 2
        def.mesh.verts[o] = px + (def.mesh.verts[o] - px) * headScale
        def.mesh.verts[o + 1] = py + (def.mesh.verts[o + 1] - py) * headScale
      }
      let minX = 1e9, minY = 1e9, maxX = -1e9, maxY = -1e9
      for (let i = 0; i < headCount; i++) {
        const o = (headOffset + i) * 2
        const x = def.mesh.verts[o], y = def.mesh.verts[o + 1]
        if (x < minX) minX = x
        if (x > maxX) maxX = x
        if (y < minY) minY = y
        if (y > maxY) maxY = y
      }
      groupMeta[headIdx].box = [minX, minY, maxX, maxY].map(v => round(v, 4))
      chibi = { headScale, pivot: [round(px, 4), round(py, 4)] }
    }

    def.ai = {
      kind: 'parts',
      source: char,
      view,
      style: 'offline',
      texture: `ai/${name}-atlas-${view}.png`,
      pose: view === 'side' ? { clip: 'Walk', frame: 0, groups: ['arm_l', 'arm_r'] } : null,
      chibi,
      groups: groupMeta,
      generatedAt: new Date().toISOString()
    }
    return { def, atlas, groupMeta }
  }

  window.OfflineBuild = {
    GROUP_ORDER,
    GROUP_LABEL,
    processImage,
    stripGuide,
    packAtlas,
    buildCharacter
  }
})()
