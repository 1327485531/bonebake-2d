// M2D 运行时：2D 线性混合蒙皮（LBS）+ 逐帧深度排序
// 数据来自 tools/convert.mjs 的输出：
//   characters.json  每个角色的 2D 绑定骨架 / 2D 网格 / UV / 蒙皮权重 / 贴图
//   anim.json        共享动画（每骨每帧：平移比、旋转、深度）
//
// 关键点：动画是按"骨长归一化"存的，所以同一套动画可以驱动任何共用这套骨架的角色；
// 换贴图/换网格 = 换角色，骨架和动画不变。这就是 2D 里"一套动画做很多角色"的做法。

const MAX_BONES = 96

const VERT_SRC = `#version 300 es
precision highp float;
in vec2 aPos;
in vec2 aUV;
in vec4 aSkinIdx;
in vec4 aSkinW;
uniform vec4 uBone[${MAX_BONES * 2}];   // 每根骨头 2 个 vec4: (a,b,c,d) 和 (tx,ty,depth,_)
uniform vec4 uXform;                    // (scaleX, scaleY, offsetX, offsetY)
uniform float uForceBone;               // 调试：>=0 时强制所有顶点用这根骨头
out vec2 vUV;
out vec4 vSkinIdx;
void main () {
  vec2 p = vec2(0.0);
  for (int k = 0; k < 4; k++) {
    float w = aSkinW[k];
    if (w == 0.0) continue;
    int b = uForceBone >= 0.0 ? int(uForceBone) : int(aSkinIdx[k]);
    vec4 m0 = uBone[b * 2];
    vec4 m1 = uBone[b * 2 + 1];
    // 2x3 仿射: [[m0.x, m0.z, m1.x],[m0.y, m0.w, m1.y]]
    p += w * vec2(m0.x * aPos.x + m0.z * aPos.y + m1.x,
                  m0.y * aPos.x + m0.w * aPos.y + m1.y);
  }
  vUV = aUV;
  vSkinIdx = aSkinIdx;
  gl_Position = vec4(p.x * uXform.x + uXform.z, p.y * uXform.y + uXform.w, 0.0, 1.0);
}`

const FRAG_SRC = `#version 300 es
precision mediump float;
in vec2 vUV;
in vec4 vSkinIdx;
uniform sampler2D uTex;
uniform vec4 uColor;
uniform float uUseTex;
uniform float uDebugSkin;   // 调试：1 = 用蒙皮索引当颜色显示
out vec4 outColor;
void main () {
  if (uDebugSkin > 0.5) {
    outColor = vec4(vSkinIdx.x / 64.0, vSkinIdx.y / 64.0, vSkinIdx.z / 64.0, 1.0);
    return;
  }
  vec4 c = uColor;
  if (uUseTex > 0.5) c *= texture(uTex, vUV);
  if (c.a < 0.05) discard;
  outColor = c;
}`

function compile (gl, type, src) {
  const s = gl.createShader(type)
  gl.shaderSource(s, src)
  gl.compileShader(s)
  if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(s) + '\n' + src)
  return s
}

export class M2DRuntime {
  constructor (canvas, overlay) {
    this.canvas = canvas
    this.overlay = overlay
    const gl = canvas.getContext('webgl2', { antialias: true, premultipliedAlpha: false, alpha: true })
    if (!gl) throw new Error('需要 WebGL2')
    this.gl = gl
    const prog = gl.createProgram()
    gl.attachShader(prog, compile(gl, gl.VERTEX_SHADER, VERT_SRC))
    gl.attachShader(prog, compile(gl, gl.FRAGMENT_SHADER, FRAG_SRC))
    gl.linkProgram(prog)
    if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(prog))
    this.prog = prog
    this.loc = {
      aPos: gl.getAttribLocation(prog, 'aPos'),
      aUV: gl.getAttribLocation(prog, 'aUV'),
      aSkinIdx: gl.getAttribLocation(prog, 'aSkinIdx'),
      aSkinW: gl.getAttribLocation(prog, 'aSkinW'),
      uBone: gl.getUniformLocation(prog, 'uBone'),
      uXform: gl.getUniformLocation(prog, 'uXform'),
      uTex: gl.getUniformLocation(prog, 'uTex'),
      uColor: gl.getUniformLocation(prog, 'uColor'),
      uUseTex: gl.getUniformLocation(prog, 'uUseTex'),
      uForceBone: gl.getUniformLocation(prog, 'uForceBone'),
      uDebugSkin: gl.getUniformLocation(prog, 'uDebugSkin')
    }
    this.forceBone = -1
    this.debugSkin = 0
    gl.enable(gl.BLEND)
    gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA)
    this.boneData = new Float32Array(MAX_BONES * 2 * 4)
    this.buffers = null
    this.textureCache = new Map()
    // 逐帧骨头全局变换
    this.globals = null
    this.boneDepths = null
    this.frame = 0
    this.order = null
  }

  /** 载入一个角色（网格 + 权重 + 贴图） */
  async loadCharacter (charDef, texBase, charName) {
    this.charName = charName
    const gl = this.gl
    const bones = charDef.bones
    if (bones.length > MAX_BONES) throw new Error(`骨头 ${bones.length} 根超过上限 ${MAX_BONES}`)
    this.charDef = charDef
    this.nBones = bones.length
    this.parentOf = bones.map(b => b.parent)
    this.boneRest = bones.map(b => ({ x: b.x, y: b.y, rot: b.rot, len: b.len }))

    // 绑定姿态的 2D 全局矩阵 + 逆矩阵
    this.bindGlobals = new Array(this.nBones)
    this.bindInverse = new Array(this.nBones)
    for (let i = 0; i < this.nBones; i++) {
      const p = this.parentOf[i]
      const local = affine(bones[i].x, bones[i].y, bones[i].rot)
      const g = p === -1 ? local : mul(this.bindGlobals[p], local)
      this.bindGlobals[i] = g
      this.bindInverse[i] = inv(g)
    }

    const mesh = charDef.mesh
    const nVert = mesh.verts.length / 2
    this.nVert = nVert

    // 三角形列表（把所有 part 摊平，记录各自归属）
    const tris = []
    const trisByPart = []
    const depthOffsets = []   // 每个三角面相对"骨骼深度"的静止偏移（从 3D 烘焙而来）
    mesh.parts.forEach((part, pi) => {
      const list = []
      const offs = part.depthOffsets || []
      for (let t = 0; t < part.indices.length; t += 3) {
        list.push([part.indices[t], part.indices[t + 1], part.indices[t + 2], pi])
        tris.push(list[list.length - 1])
        depthOffsets.push(offs[t / 3] || 0)
      }
      trisByPart.push(list)
    })
    this.tris = tris
    this.nTri = tris.length
    this.depthOffsets = depthOffsets

    // 每个三角形的"骨骼混合"（哪些骨头、各占多少权重），只在载入时算一次
    const idx = mesh.skinIndices
    const wts = mesh.skinWeights
    const triBones = []
    for (const [a, b, c] of tris) {
      const acc = new Map()
      for (const v of [a, b, c]) {
        for (let k = 0; k < 4; k++) {
          const w = wts[v * 4 + k]
          if (w <= 0) continue
          const bi = idx[v * 4 + k]
          acc.set(bi, (acc.get(bi) || 0) + w)
        }
      }
      // 归一化到 1（三个顶点各有权重和 1）
      let sum = 0
      for (const w of acc.values()) sum += w
      const entries = [...acc.entries()].map(([b2, w]) => [b2, w / sum])
      entries.sort((p, q) => q[1] - p[1])
      triBones.push(entries)
    }
    this.triBones = triBones

    // GPU 缓冲
    if (this.buffers) this.disposeBuffers()
    const mk = (data, ArrayType) => {
      const buf = gl.createBuffer()
      gl.bindBuffer(gl.ARRAY_BUFFER, buf)
      gl.bufferData(gl.ARRAY_BUFFER, new ArrayType(data), gl.STATIC_DRAW)
      return buf
    }
    const bufPos = mk(mesh.verts, Float32Array)
    const bufUV = mk(mesh.uvs, Float32Array)
    const bufIdx = mk(idx, Uint16Array)
    const bufW = mk(wts, Float32Array)
    const bufOrder = gl.createBuffer()
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, bufOrder)
    gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, this.nTri * 3 * 4, gl.DYNAMIC_DRAW)
    this.buffers = { bufPos, bufUV, bufIdx, bufW, bufOrder }
    this.indexOrder = new Uint32Array(this.nTri * 3)
    this.triDepth = new Float32Array(this.nTri)
    this.sortOrder = new Uint32Array(this.nTri)
    for (let i = 0; i < this.nTri; i++) this.sortOrder[i] = i

    // 贴图
    this.textures = []
    for (const rel of charDef.textures) {
      let tex = this.textureCache.get(rel)
      if (!tex) {
        tex = await loadTexture(gl, texBase + rel)
        this.textureCache.set(rel, tex)
      }
      this.textures.push(tex)
    }

    // 视图范围：绑定网格 + 所有动画的骨骼轨迹
    const xs = [], ys = []
    for (let v = 0; v < nVert; v++) { xs.push(mesh.verts[v * 2]); ys.push(mesh.verts[v * 2 + 1]) }
    this.meshBounds = [Math.min(...xs), Math.min(...ys), Math.max(...xs), Math.max(...ys)]
    this.charHeight = this.meshBounds[3] - this.meshBounds[1]
    return this
  }

  /** 设置当前动画 */
  setAnimation (clip) {
    this.clip = clip
    this.nFrames = clip ? clip.frames : 1
    // 轨道来源有两种：
    //   clip.tracks          —— 动画骨架与角色骨架同名同序（最快路径）
    //   clip.charTracks[名]  —— 异构骨架经过语义重映射后的专属轨道
    const tracks = clip && clip.charTracks && clip.charTracks[this.charName]
      ? clip.charTracks[this.charName]
      : (clip ? clip.tracks : null)
    this.trackOfBone = new Array(this.nBones).fill(null)
    this.remapped = !!(clip && clip.charTracks && clip.charTracks[this.charName])
    if (tracks) {
      for (let i = 0; i < this.nBones; i++) {
        const t = tracks[this.charDef.bones[i].name]
        this.trackOfBone[i] = t !== undefined ? t : null
      }
    }
  }

  /** 计算第 f 帧的骨头全局变换（2D 仿射）与深度 */
  pose (f) {
    const n = this.nBones
    const g = new Array(n)
    const dep = new Float32Array(n)
    for (let i = 0; i < n; i++) {
      const tr = this.trackOfBone ? this.trackOfBone[i] : null
      let lx, ly, rot, depth
      if (tr) {
        const o = f * 4
        const len = this.boneRest[i].len
        lx = tr[o] * len
        ly = tr[o + 1] * len
        rot = tr[o + 2]
        depth = tr[o + 3]
      } else {
        lx = this.boneRest[i].x; ly = this.boneRest[i].y
        rot = this.boneRest[i].rot; depth = 0
      }
      const local = affine(lx, ly, rot)
      const p = this.parentOf[i]
      g[i] = p === -1 ? local : mul(g[p], local)
      dep[i] = depth
    }
    this.globals = g
    this.boneDepths = dep
  }

  /** 把骨头全局变换 × 逆绑定 矩阵写进 uniform 数据 */
  updateBoneUniform () {
    const d = this.boneData
    for (let i = 0; i < this.nBones; i++) {
      const m = mul(this.globals[i], this.bindInverse[i])
      const o = i * 8
      d[o] = m[0]; d[o + 1] = m[1]; d[o + 2] = m[2]; d[o + 3] = m[3]
      d[o + 4] = m[4]; d[o + 5] = m[5]; d[o + 6] = this.boneDepths[i]; d[o + 7] = 0
    }
  }

  /** 逐三角形算深度（用骨头的深度加权平均），然后每个 part 单独排序 */
  buildDrawList () {
    const { tris, triBones, triDepth, boneDepths, indexOrder, depthOffsets } = this
    const parts = this.charDef.mesh.parts
    const perPart = parts.map(() => [])
    for (let t = 0; t < this.nTri; t++) {
      const e = triBones[t]
      let d = 0
      for (let k = 0; k < e.length; k++) d += e[k][1] * boneDepths[e[k][0]]
      // 骨骼深度 + 静止偏移：后者区分同一根骨头管辖区域内的正/背面，避免身体里层翻到外面
      triDepth[t] = d + depthOffsets[t]
      perPart[tris[t][3]].push(t)
    }
    const draws = []
    let cursor = 0
    for (let pi = 0; pi < parts.length; pi++) {
      const list = perPart[pi]
      if (list.length === 0) continue
      list.sort((a, b) => triDepth[a] - triDepth[b])
      let sum = 0
      const start = cursor
      for (const t of list) {
        indexOrder[cursor++] = tris[t][0]
        indexOrder[cursor++] = tris[t][1]
        indexOrder[cursor++] = tris[t][2]
        sum += triDepth[t]
      }
      draws.push({ part: pi, start, count: list.length * 3, depth: sum / list.length })
    }
    draws.sort((a, b) => a.depth - b.depth)
    return draws
  }

  setViewport (w, h) {
    const gl = this.gl
    this.canvas.width = w
    this.canvas.height = h
    if (this.overlay) { this.overlay.width = w; this.overlay.height = h }
    gl.viewport(0, 0, w, h)
    const [x0, y0, x1, y1] = this.fitBounds
    const cw = x1 - x0, ch = y1 - y0
    const scale = Math.min(w / (cw * 1.15), h / (ch * 1.15))
    const cx = (x0 + x1) / 2, cy = (y0 + y1) / 2
    this.screenScale = scale
    this.screenCenter = [cx, cy]
    // NDC: x 向右 +1，y 向上 +1（注意 y 的符号，写反了整个角色会上下颠倒）
    this.xform = [
      scale / w * 2,      // x 缩放
      scale / h * 2,      // y 缩放（正数：世界 y 向上 = 屏幕上方）
      -cx * scale / w * 2,
      -cy * scale / h * 2
    ]
  }

  /** 屏幕坐标变换：2D 世界 → CSS 像素 */
  toScreen (x, y) {
    const w = this.canvas.width, h = this.canvas.height
    const s = this.screenScale, c = this.screenCenter
    return [(x - c[0]) * s + w / 2, h / 2 - (y - c[1]) * s]
  }

  render () {
    if (!this.buffers || !this.globals) return   // 正在重建资源，本帧跳过
    const gl = this.gl
    this.updateBoneUniform()
    const draws = this.buildDrawList()
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, this.buffers.bufOrder)
    gl.bufferSubData(gl.ELEMENT_ARRAY_BUFFER, 0, this.indexOrder.subarray(0, this.nTri * 3))
    gl.clearColor(0, 0, 0, 0)
    gl.clear(gl.COLOR_BUFFER_BIT)

    gl.useProgram(this.prog)
    gl.uniform4fv(this.loc.uXform, this.xform)
    gl.uniform4fv(this.loc.uBone, this.boneData)
    gl.uniform1f(this.loc.uForceBone, this.forceBone)
    gl.uniform1f(this.loc.uDebugSkin, this.debugSkin)

    const bindAttr = (buf, loc, size, type) => {
      gl.bindBuffer(gl.ARRAY_BUFFER, buf)
      gl.enableVertexAttribArray(loc)
      gl.vertexAttribPointer(loc, size, type, false, 0, 0)
    }
    bindAttr(this.buffers.bufPos, this.loc.aPos, 2, gl.FLOAT)
    bindAttr(this.buffers.bufUV, this.loc.aUV, 2, gl.FLOAT)
    bindAttr(this.buffers.bufIdx, this.loc.aSkinIdx, 4, gl.UNSIGNED_SHORT)
    bindAttr(this.buffers.bufW, this.loc.aSkinW, 4, gl.FLOAT)

    gl.activeTexture(gl.TEXTURE0)
    gl.uniform1i(this.loc.uTex, 0)
    for (const d of draws) {
      const part = this.charDef.mesh.parts[d.part]
      gl.uniform4fv(this.loc.uColor, part.color)
      if (part.tex !== null && this.textures[part.tex]) {
        gl.bindTexture(gl.TEXTURE_2D, this.textures[part.tex])
        gl.uniform1f(this.loc.uUseTex, 1)
      } else {
        gl.uniform1f(this.loc.uUseTex, 0)
      }
      gl.drawElements(gl.TRIANGLES, d.count, gl.UNSIGNED_INT, d.start * 4)
    }
    this.lastDraws = draws
  }

  disposeBuffers () {
    if (!this.buffers) return
    const gl = this.gl
    for (const k of ['bufPos', 'bufUV', 'bufIdx', 'bufW', 'bufOrder']) gl.deleteBuffer(this.buffers[k])
    this.buffers = null
  }
}

// ---------- 2D 仿射工具 ----------
function affine (x, y, rot) {
  const c = Math.cos(rot), s = Math.sin(rot)
  return [c, s, -s, c, x, y]
}
function mul (A, B) {
  return [
    A[0] * B[0] + A[2] * B[1], A[1] * B[0] + A[3] * B[1],
    A[0] * B[2] + A[2] * B[3], A[1] * B[2] + A[3] * B[3],
    A[0] * B[4] + A[2] * B[5] + A[4], A[1] * B[4] + A[3] * B[5] + A[5]
  ]
}
function inv (M) {
  const det = M[0] * M[3] - M[1] * M[2]
  const id = 1 / (Math.abs(det) < 1e-12 ? 1e-12 : det)
  const a = M[3] * id, b = -M[1] * id, c = -M[2] * id, d = M[0] * id
  return [a, b, c, d, -(a * M[4] + c * M[5]), -(b * M[4] + d * M[5])]
}

function loadTexture (gl, url) {
  return new Promise((resolve, reject) => {
    const img = new Image()
    img.onload = () => {
      const tex = gl.createTexture()
      gl.bindTexture(gl.TEXTURE_2D, tex)
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, img)
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE)
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE)
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR_MIPMAP_LINEAR)
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR)
      gl.generateMipmap(gl.TEXTURE_2D)
      resolve(tex)
    }
    img.onerror = () => reject(new Error('贴图加载失败 ' + url))
    img.src = url
  })
}