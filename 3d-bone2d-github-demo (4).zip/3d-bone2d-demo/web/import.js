// 手绘皮肤导入器前端。
// - 有 tools/import-ui-server.mjs 的 /api 时：服务模式（预览/构建都走后端）
// - 没有 /api 时（任意静态服务器）：离线模式
//   浏览器里完成剥 guide、抠图、图集打包和角色 JSON 生成，最后下载两个文件手动放进 out/。
const GROUPS = ['head', 'torso', 'arm_l', 'arm_r', 'leg_l', 'leg_r']
const LABEL = {
  head: '头 / 脖子',
  torso: '躯干',
  arm_l: '左臂',
  arm_r: '右臂',
  leg_l: '左腿',
  leg_r: '右腿'
}

const $ = (s) => document.querySelector(s)
const FORCE_OFFLINE = new URLSearchParams(location.search).has('standalone')
const state = {
  inputMode: 'sheet',       // sheet | parts
  transport: 'detecting',   // server | offline
  sheet: null,
  parts: {},
  offlineParts: null,
  token: null,
  view: 'side',
  name: 'my_char',
  existingJson: null
}

function setStatus (msg, cls = '') {
  const el = $('#status')
  el.textContent = msg
  el.className = 'status ' + cls
}

function setBusy (busy) {
  $('#previewBtn').disabled = busy
  $('#buildBtn').disabled = busy || !state.token
  $('#previewBtn').textContent = busy ? '处理中…' : '预览 6 块'
}

function invalidate (msg = '内容变了，请重新预览') {
  state.token = null
  state.offlineParts = null
  $('#buildBtn').disabled = true
  $('#downloadRow').hidden = true
  $('#offlineNote').hidden = true
  if (msg) setStatus(msg)
}

function showLog (el, text) {
  if (!text) { el.hidden = true; el.textContent = ''; return }
  el.hidden = false
  el.textContent = text
}

function readFile (file) {
  return new Promise((resolve, reject) => {
    const r = new FileReader()
    r.onload = () => resolve(r.result)
    r.onerror = () => reject(new Error('文件读取失败'))
    r.readAsDataURL(file)
  })
}

function readText (file) {
  return new Promise((resolve, reject) => {
    const r = new FileReader()
    r.onload = () => resolve(r.result)
    r.onerror = () => reject(new Error('文件读取失败'))
    r.readAsText(file)
  })
}

function isPng (file) {
  return file && (file.type === 'image/png' || /\.png$/i.test(file.name || ''))
}

function loadImage (src) {
  return new Promise((resolve, reject) => {
    const img = new Image()
    img.onload = () => resolve(img)
    img.onerror = () => reject(new Error('图片加载失败'))
    img.src = src
  })
}

function imageDataFromImage (img, sx = 0, sy = 0, sw = img.naturalWidth, sh = img.naturalHeight) {
  const c = document.createElement('canvas')
  c.width = sw
  c.height = sh
  const ctx = c.getContext('2d')
  ctx.drawImage(img, sx, sy, sw, sh, 0, 0, sw, sh)
  return ctx.getImageData(0, 0, sw, sh)
}

function partToDataUrl (part) {
  const c = document.createElement('canvas')
  c.width = part.width
  c.height = part.height
  const ctx = c.getContext('2d')
  ctx.putImageData(new ImageData(new Uint8ClampedArray(part.data), part.width, part.height), 0, 0)
  return c.toDataURL('image/png')
}

function atlasToCanvas (atlas) {
  const c = document.createElement('canvas')
  c.width = atlas.width
  c.height = atlas.height
  const ctx = c.getContext('2d')
  ctx.putImageData(new ImageData(new Uint8ClampedArray(atlas.data), atlas.width, atlas.height), 0, 0)
  return c
}

function canvasToBlob (canvas) {
  return new Promise((resolve, reject) => {
    canvas.toBlob(b => b ? resolve(b) : reject(new Error('PNG 编码失败')), 'image/png')
  })
}

async function fetchJson (url, label) {
  const res = await fetch(url, { cache: 'no-store' })
  if (!res.ok) throw new Error(`读不到 ${label}（HTTP ${res.status}）：${url}`)
  return res.json()
}

function buildOverlay () {
  $('#sheetOverlay').innerHTML = GROUPS.map(g => `<div class="cell"><span>${g}</span></div>`).join('')
}

function buildPartCards () {
  const grid = $('#partsGrid')
  grid.innerHTML = ''
  for (const g of GROUPS) {
    const card = document.createElement('label')
    card.className = 'part-card'
    card.dataset.group = g
    card.innerHTML = `
      <span class="name">${g} · ${LABEL[g]}</span>
      <div class="thumb"><img alt="${g}"></div>
      <span class="hint">点击选择 PNG</span>
      <input type="file" accept="image/png" hidden>`
    const input = card.querySelector('input')
    const img = card.querySelector('img')
    input.addEventListener('change', async () => {
      const file = input.files && input.files[0]
      if (!file) return
      if (!isPng(file)) { setStatus('只支持 PNG', 'err'); return }
      try {
        const data = await readFile(file)
        state.parts[g] = data
        img.src = data
        card.classList.add('has')
        card.querySelector('.hint').textContent = file.name
        invalidate()
      } catch (e) { setStatus(e.message, 'err') }
    })
    grid.appendChild(card)
  }
}

async function handleSheet (file) {
  if (!file) return
  if (!isPng(file)) { setStatus('sheet 只支持 PNG', 'err'); return }
  try {
    const data = await readFile(file)
    state.sheet = data
    const stage = $('#sheetPreview')
    const img = $('#sheetImg')
    stage.hidden = false
    img.onload = () => { stage.hidden = false }
    img.src = data
    $('#sheetDrop').querySelector('strong').textContent = '已选择 sheet，点击可更换'
    invalidate()
    setStatus(`已选择 ${file.name}，可以预览`)
  } catch (e) { setStatus(e.message, 'err') }
}

function payloadBase () {
  const name = $('#name').value.trim()
  if (!/^[A-Za-z0-9_-]{1,40}$/.test(name)) throw new Error('角色名只能包含字母/数字/_-，1..40 字符')
  state.name = name
  return {
    view: $('#view').value,
    name,
    keepGuide: $('#keepGuide').checked,
    overwrite: $('#overwrite').checked
  }
}

function renderPreview (parts) {
  const grid = $('#previewGrid')
  grid.innerHTML = ''
  for (const p of parts) {
    const card = document.createElement('div')
    card.className = 'preview-card'
    card.innerHTML = `<div class="name">${p.group} · ${LABEL[p.group] || ''}</div>
      <div class="imgwrap"><img alt="${p.group}"></div>`
    card.querySelector('img').src = p.png
    grid.appendChild(card)
  }
}

function validateSource () {
  if (state.inputMode === 'sheet' && !state.sheet) throw new Error('先选择一张 3×2 sheet')
  if (state.inputMode === 'parts') {
    const missing = GROUPS.filter(g => !state.parts[g])
    if (missing.length) throw new Error('还缺这些块：' + missing.join(', '))
  }
}

// ---------------- 离线：浏览器处理 ----------------
async function processOfflineParts ({ keepGuide }) {
  const raw = []
  if (state.inputMode === 'sheet') {
    const img = await loadImage(state.sheet)
    const cw = Math.floor(img.naturalWidth / 3)
    const ch = Math.floor(img.naturalHeight / 2)
    if (cw < 64 || ch < 64) throw new Error('sheet 太小，或不是 3×2')
    for (let i = 0; i < GROUPS.length; i++) {
      const g = GROUPS[i]
      const col = i % 3, row = (i / 3) | 0
      raw.push({ group: g, img: imageDataFromImage(img, col * cw, row * ch, cw, ch) })
    }
  } else {
    for (const g of GROUPS) {
      const img = await loadImage(state.parts[g])
      raw.push({ group: g, img: imageDataFromImage(img) })
    }
  }

  const out = []
  for (const { group, img } of raw) {
    try {
      OfflineBuild.stripGuide(img, keepGuide)
      const part = OfflineBuild.processImage(img, 0.06)
      part.name = group
      out.push(part)
    } catch (e) {
      throw new Error(`[${group}] ${e.message}（这一格是不是空的？）`)
    }
  }
  return out
}

async function previewOffline (base) {
  validateSource()
  setStatus('离线模式：正在浏览器里拆分/抠图…')
  const parts = await processOfflineParts({ keepGuide: base.keepGuide })
  state.offlineParts = parts
  state.token = 'offline'
  renderPreview(parts.map(p => ({ group: p.name, png: partToDataUrl(p) })))
  $('#previewPanel').hidden = false
  showLog($('#previewLog'), `离线处理完成：${parts.map(p => `${p.name} ${p.width}x${p.height}`).join('，')}`)
  setStatus('6 块处理完成；离线模式会在构建后下载图集和 JSON', 'ok')
  $('#buildBtn').disabled = false
}

// ---------------- 离线：构建 + 下载 ----------------
async function buildOffline (base) {
  const view = base.view
  const name = base.name
  const headScale = Number($('#headScale').value)
  if (!state.offlineParts) throw new Error('先预览 6 块')

  setStatus('离线模式：正在打包图集/生成角色 JSON…')
  const embedded = window.STUDIO_DATA && window.STUDIO_DATA[view]
  const baseDef = embedded && embedded.base
    ? embedded.base
    : await fetchJson(new URL(`../templates/${view}/base-male.json`, location.href).href, `templates/${view}/base-male.json`)
  let poseVerts = null
  if (view === 'side') {
    if (embedded && embedded.pose) poseVerts = embedded.pose.verts
    else {
      const pose = await fetchJson(new URL('../templates/side/pose-walk0.json', location.href).href, 'templates/side/pose-walk0.json')
      poseVerts = pose.verts
    }
  }

  let existing = { characters: {} }
  let mergedOk = false
  if (state.existingJson) {
    existing = state.existingJson
    mergedOk = true
  } else if (location.protocol !== 'file:') {
    try {
      const res = await fetch(new URL(`../out/${view}/characters-ai.json`, location.href).href, { cache: 'no-store' })
      if (res.ok) { existing = await res.json(); mergedOk = true }
    } catch {}
  }
  if (!existing.characters) existing.characters = {}
  if (existing.characters[name] && !confirm(`角色 ${name} 已存在，继续会覆盖它。继续？`)) return

  const result = OfflineBuild.buildCharacter({
    base: baseDef,
    view,
    parts: state.offlineParts,
    name,
    headScale,
    poseVerts,
    char: 'male'
  })

  const atlasCanvas = atlasToCanvas(result.atlas)
  const atlasBlob = await canvasToBlob(atlasCanvas)
  const atlasUrl = URL.createObjectURL(atlasBlob)
  const atlasName = `${name}-atlas-${view}.png`

  existing.characters[name] = result.def
  const jsonBlob = new Blob([JSON.stringify(existing)], { type: 'application/json' })
  const jsonUrl = URL.createObjectURL(jsonBlob)

  const a = $('#downloadAtlas')
  a.href = atlasUrl
  a.download = atlasName
  const b = $('#downloadJson')
  b.href = jsonUrl
  b.download = 'characters-ai.json'
  $('#downloadRow').hidden = false

  const note = $('#offlineNote')
  note.hidden = false
  const existingCount = Math.max(0, Object.keys(existing.characters).length - 1)
  note.innerHTML = `放文件：<br>
    1. 把 <code>${atlasName}</code> 放进 <code>out/${view}/ai/</code><br>
    2. 把 <code>characters-ai.json</code> 覆盖到 <code>out/${view}/</code>（${mergedOk ? `已合并当前 ${existingCount} 个已有角色` : '没读到现有文件，只含新角色；已有 AI 角色请先备份再合并'}）<br>
    3. 刷新演示页；图集 ${result.atlas.width}×${result.atlas.height}，网格 ${result.def.mesh.verts.length / 2} 顶点`
  if (!mergedOk) note.innerHTML += '<br><b style="color:#ffcf9a">⚠ 没读到现有 characters-ai.json；直接覆盖会丢掉已有 AI 角色。</b>'

  $('#atlasImg').src = atlasUrl
  if (location.protocol === 'file:') {
    $('#demoLink').style.display = 'none'
  } else {
    $('#demoLink').style.display = ''
    $('#demoLink').href = `${location.protocol}//${location.hostname}:8899/web/index.html?view=${view}&char=${name}&clip=Walk&frame=0&play=0&bones=0`
  }
  $('#resultMeta').textContent = `${name} · ${view} · headScale ${headScale}× · 离线构建`
  showLog($('#buildLog'), `离线构建：${result.groupMeta.map(g => `${g.name} ${g.vertices}v/${g.triangles}t`).join('，')}\n图集 ${result.atlas.width}x${result.atlas.height}\n下载后按提示放到 out/${view}/。`)
  $('#resultPanel').hidden = false
  $('#downloadRow').scrollIntoView({ behavior: 'smooth', block: 'center' })
  setStatus('离线构建完成：下载两个文件，按提示放进 out/', 'ok')
}

// ---------------- 服务模式 ----------------
async function previewServer (base) {
  const payload = {
    ...base,
    mode: state.inputMode,
    ...(state.inputMode === 'sheet' ? { sheet: state.sheet } : { parts: state.parts })
  }
  const res = await fetch('/api/preview', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  })
  const data = await res.json().catch(() => ({ ok: false, error: '服务器返回不是 JSON' }))
  if (!res.ok || !data.ok) {
    setStatus(data.error || `处理失败（HTTP ${res.status}）`, 'err')
    if (data.log) { showLog($('#previewLog'), data.log); $('#previewPanel').hidden = false }
    return
  }
  state.token = data.token
  renderPreview(data.parts)
  $('#previewPanel').hidden = false
  showLog($('#previewLog'), data.log)
  setStatus('6 块处理完成，确认没问题后构建', 'ok')
  $('#buildBtn').disabled = false
}

async function buildServer (base) {
  const res = await fetch('/api/build', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      token: state.token,
      view: base.view,
      name: base.name,
      overwrite: base.overwrite,
      headScale: Number($('#headScale').value)
    })
  })
  const data = await res.json().catch(() => ({ ok: false, error: '服务器返回不是 JSON' }))
  if (!res.ok || !data.ok) {
    setStatus(data.error || `构建失败（HTTP ${res.status}）`, 'err')
    if (data.log) { showLog($('#buildLog'), data.log); $('#resultPanel').hidden = false }
    return
  }
  $('#downloadRow').hidden = true
  $('#offlineNote').hidden = true
  $('#atlasImg').src = data.atlas
  $('#demoLink').href = data.demo
  $('#resultMeta').textContent = `${base.name} · ${base.view} · headScale ${$('#headScale').value}×`
  showLog($('#buildLog'), data.log)
  $('#resultPanel').hidden = false
  setStatus('构建完成', 'ok')
}

// ---------------- 事件 ----------------
const drop = $('#sheetDrop')
const sheetFile = $('#sheetFile')
drop.addEventListener('click', () => sheetFile.click())
sheetFile.addEventListener('change', () => handleSheet(sheetFile.files && sheetFile.files[0]))
drop.addEventListener('dragover', e => { e.preventDefault(); drop.classList.add('over') })
drop.addEventListener('dragleave', () => drop.classList.remove('over'))
drop.addEventListener('drop', e => {
  e.preventDefault(); drop.classList.remove('over')
  handleSheet(e.dataTransfer.files && e.dataTransfer.files[0])
})

document.querySelectorAll('.tab').forEach(btn => {
  btn.addEventListener('click', () => {
    state.inputMode = btn.dataset.mode
    document.querySelectorAll('.tab').forEach(b => b.classList.toggle('active', b === btn))
    $('#sheetPane').hidden = state.inputMode !== 'sheet'
    $('#partsPane').hidden = state.inputMode !== 'parts'
    invalidate('切换了输入方式，请重新预览')
  })
})

$('#existingJson').addEventListener('change', async e => {
  const file = e.target.files && e.target.files[0]
  if (!file) { state.existingJson = null; setStatus('已取消合并现有 characters-ai.json'); return }
  try {
    const j = JSON.parse(await readText(file))
    if (!j.characters || typeof j.characters !== 'object') throw new Error('不是 characters-ai.json（缺 characters）')
    state.existingJson = j
    setStatus(`已载入现有 ${Object.keys(j.characters).length} 个角色，构建时会合并`, 'ok')
  } catch (err) {
    state.existingJson = null
    setStatus('JSON 读取失败：' + err.message, 'err')
  }
})

$('#name').addEventListener('input', e => {
  state.name = e.target.value.trim()
  invalidate()
})
$('#view').addEventListener('change', e => {
  state.view = e.target.value
  invalidate('切换了视角，请重新预览')
})
$('#keepGuide').addEventListener('change', () => invalidate('剥色设置变了，请重新预览'))
$('#headScale').addEventListener('change', () => {
  if (state.token) setStatus('头放大已改，可以直接构建')
})

$('#previewBtn').addEventListener('click', async () => {
  let base
  try { base = payloadBase(); validateSource() } catch (e) { setStatus(e.message, 'err'); return }
  setBusy(true)
  $('#previewPanel').hidden = true
  $('#resultPanel').hidden = true
  $('#downloadRow').hidden = true
  $('#offlineNote').hidden = true
  try {
    if (state.transport === 'server') await previewServer(base)
    else await previewOffline(base)
  } catch (e) {
    setStatus((state.transport === 'server' ? '请求失败：' : '离线处理失败：') + e.message, 'err')
  } finally {
    setBusy(false)
    $('#buildBtn').disabled = !state.token
  }
})

$('#buildBtn').addEventListener('click', async () => {
  if (!state.token) { setStatus('先预览 6 块', 'err'); return }
  let base
  try { base = payloadBase() } catch (e) { setStatus(e.message, 'err'); return }
  setBusy(true)
  setStatus(state.transport === 'server' ? '正在构建角色和图集…' : '离线模式：正在生成下载文件…')
  try {
    if (state.transport === 'server') await buildServer(base)
    else await buildOffline(base)
  } catch (e) {
    setStatus((state.transport === 'server' ? '构建失败：' : '离线构建失败：') + e.message, 'err')
  } finally {
    setBusy(false)
    $('#buildBtn').disabled = !state.token
  }
})

// ---------------- 启动：检测服务模式 / 离线模式 ----------------
async function detectTransport () {
  // studio 的 iframe 用 ?standalone=1 强制离线，避免在 Node 服务页里走 /api。
  if (FORCE_OFFLINE) return 'offline'
  // 服务模式：import-ui-server 会在页面 <head> 注入 __IMPORT_UI_SERVER__。
  // 静态模式没有这个标记，直接走离线，不会去探测 /api/health（避免 404）。
  return window.__IMPORT_UI_SERVER__ ? 'server' : 'offline'
}

async function boot () {
  if (new URLSearchParams(location.search).has('embed')) {
    const h = document.querySelector('header'); if (h) h.style.display = 'none'
  }
  buildOverlay()
  buildPartCards()
  state.transport = await detectTransport()
  const badge = $('#modeBadge')
  if (state.transport === 'server') {
    badge.textContent = '服务模式'
    badge.className = 'badge online'
    $('#modeHint').innerHTML = '服务模式：预览/构建都走后端，图集和角色直接写入 <code>out/</code>。'
    $('#buildBtn').textContent = '构建角色'
    $('#overwrite').parentElement.style.display = ''
  } else {
    badge.textContent = '离线模式'
    badge.className = 'badge offline'
    $('#modeHint').innerHTML = '离线模式：<b>不用启动任何服务</b>；base/pose/参考图已内置。在浏览器里抠图/打包，构建后下载 <code>atlas.png</code> 和 <code>characters-ai.json</code>。要合并已有角色，选上面的 <code>characters-ai.json</code>（可选）。'
    $('#buildBtn').textContent = '构建并下载'
    $('#overwrite').parentElement.style.display = 'none'
    setStatus(location.protocol === 'file:' ? '单文件模式：无需服务，先选图再预览' : '离线模式：不连服务；先选图，再预览')
  }
}

// 从生成页/studio 接收 6 块 AI 生成图，直接填进 6 张部件图槽
window.addEventListener('message', e => {
  const d = e.data
  if (!d || d.type !== 'studio-parts' || !Array.isArray(d.parts)) return
  const by = Object.fromEntries(d.parts.map(p => [p.group, p.png]))
  if (GROUPS.some(g => !by[g])) { setStatus('收到的部件不完整，需要 6 块', 'err'); return }
  state.inputMode = 'parts'
  state.parts = { ...by }
  document.querySelectorAll('.tab').forEach(b => b.classList.toggle('active', b.dataset.mode === 'parts'))
  $('#sheetPane').hidden = true
  $('#partsPane').hidden = false
  for (const g of GROUPS) {
    const card = document.querySelector(`.part-card[data-group="${g}"]`)
    if (!card) continue
    const img = card.querySelector('img')
    img.src = by[g]
    card.classList.add('has')
    card.querySelector('.hint').textContent = '来自 AI 生成'
  }
  if (d.view) { $('#view').value = d.view; state.view = d.view }
  if (d.headScale) $('#headScale').value = String(d.headScale)
  if ($('#name').value === 'my_char' || !$('#name').value.trim()) { $('#name').value = 'ai_generated'; state.name = 'ai_generated' }
  invalidate('已收到 AI 生成的 6 块；确认后点“预览 6 块”')
  setStatus('已收到 AI 生成的 6 块，可以直接预览/构建', 'ok')
})

boot()
