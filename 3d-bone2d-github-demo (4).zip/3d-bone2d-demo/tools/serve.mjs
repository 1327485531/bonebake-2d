// 零依赖本地静态服务器：node tools/serve.mjs
// 浏览器不允许 file:// 加载 ES module / fetch out 数据，所以演示必须走 HTTP。
import http from 'node:http'
import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
let port = Number(process.env.PORT || 8899)
const host = process.env.HOST || '127.0.0.1'

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.svg': 'image/svg+xml',
  '.woff2': 'font/woff2',
  '.woff': 'font/woff',
  '.ico': 'image/x-icon'
}

const server = http.createServer((req, res) => {
  let pathname
  try {
    pathname = decodeURIComponent(new URL(req.url, `http://${req.headers.host || 'localhost'}`).pathname)
  } catch {
    res.writeHead(400); res.end('Bad request'); return
  }
  if (pathname === '/__server') {
    res.writeHead(200, {
      'Content-Type': 'application/json; charset=utf-8',
      'Cache-Control': 'no-store',
      'X-3D-Bone2D-Server': 'node'
    })
    res.end(JSON.stringify({ server: 'node', node: process.version, jsMime: MIME['.js'] }))
    return
  }
  if (pathname.endsWith('/')) pathname += 'index.html'
  const abs = path.resolve(root, '.' + pathname)
  if (abs !== root && !abs.startsWith(root + path.sep)) {
    res.writeHead(403); res.end('Forbidden'); return
  }
  fs.stat(abs, (err, st) => {
    if (err || !st.isFile()) {
      res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' })
      res.end(`404 Not found: ${pathname}`)
      return
    }
    res.writeHead(200, {
      'Content-Type': MIME[path.extname(abs).toLowerCase()] || 'application/octet-stream',
      'Content-Length': st.size,
      'Cache-Control': 'no-store',
      'X-3D-Bone2D-Server': 'node'
    })
    fs.createReadStream(abs).pipe(res)
  })
})

function start (tryPort, left = 10) {
  server.removeAllListeners('listening')
  const onError = (err) => {
    if (err.code === 'EADDRINUSE' && left > 0) {
      console.warn(`端口 ${tryPort} 被占用，试 ${tryPort + 1}...`)
      start(tryPort + 1, left - 1)
      return
    }
    console.error(err)
    process.exit(1)
  }
  const onListening = () => {
    server.removeListener('error', onError)
    port = server.address().port
    console.log(`3d-bone2d demo: http://${host}:${port}/web/index.html`)
    console.log(`服务器标识: http://${host}:${port}/__server`)
    console.log('Ctrl+C 停止')
  }
  server.once('error', onError)
  server.listen(tryPort, host, onListening)
}

start(port)
