// 把脚从腿部拆成独立 part + 独立贴图。
//
// 背景：6 块分块版里脚和大腿/小腿共用一个 leg 贴图，脚趾在绑定姿态下被压缩，
// 摆姿势时容易"碎裂"或采到大腿的纹理。这里把 foot/ball/toe 主导的三角形拆出来，
// 复制脚的顶点，用独立的靴子贴图（AI 生成的 isolated boot）做平面 UV，再挂成一个 part。
//
// 用法：
//   node tools/split-feet.mjs --data out/front --char ai_ronin_v2 \
//     --boot-l out/front/ai/assets/boot_l_front.png \
//     --boot-r out/front/ai/assets/boot_r_front.png
//
// 注意：对 male 高模，脚部网格本身在部分帧有自交/破洞（纯色测试可复现），
// 拆脚+独立靴贴图并不能补几何洞；这个工具保留给脚部闭合的底模/后续补面用。
// 详见 docs/AI皮肤接入.md 7.5。
//
// 脚 part 会单独 draw，每个 part 内部按三角形深度排序；脚与腿之间是独立 part 排序。
// 对脚这种小部件通常没问题，换来的是脚趾纹理终于对得上。

import fs from 'node:fs'
import path from 'node:path'
import { decodePng, encodePng, processImage, planarUvsForBox } from './ai-image.mjs'
import { dominantBone } from './ai-image.mjs'

const argv = process.argv.slice(2)
const opt = (n, d) => { const i = argv.indexOf('--' + n); return i === -1 ? d : argv[i + 1] }
const dataDir = path.resolve(opt('data', 'out/front'))
const CHAR = opt('char', 'ai_ronin_v2')
const BOOT_L = opt('boot-l', 'out/front/ai/assets/boot_l_front.png')
const BOOT_R = opt('boot-r', 'out/front/ai/assets/boot_r_front.png')
const view = path.basename(dataDir)

const aiJsonPath = path.join(dataDir, 'characters-ai.json')
const aiJson = JSON.parse(fs.readFileSync(aiJsonPath, 'utf8'))
const def = aiJson.characters[CHAR]
if (!def) throw new Error(`characters-ai.json 里没有 ${CHAR}`)
if (def.mesh.parts.length !== 1) throw new Error('只支持单 part 角色（先跑 ai-skin-parts 生成分块版）')

const mesh = def.mesh
const part = mesh.parts[0]
const offs = part.depthOffsets || []

function loadBoot (p) {
  if (!fs.existsSync(p)) throw new Error('找不到靴子图: ' + p)
  const img = decodePng(fs.readFileSync(p))
  return processImage(img, 0.06)
}
const bootL = loadBoot(BOOT_L)
const bootR = loadBoot(BOOT_R)
const bootLName = `${CHAR}-boot_l-${view}.png`
const bootRName = `${CHAR}-boot_r-${view}.png`
fs.writeFileSync(path.join(dataDir, 'ai', bootLName), encodePng(bootL.width, bootL.height, bootL.data))
fs.writeFileSync(path.join(dataDir, 'ai', bootRName), encodePng(bootR.width, bootR.height, bootR.data))

const bodyIdx = [], bodyOffs = []
const footTris = { l: [], r: [] }
for (let t = 0; t < part.indices.length; t += 3) {
  const tr = { a: part.indices[t], b: part.indices[t + 1], c: part.indices[t + 2], offset: offs[t / 3] || 0 }
  const bi = dominantBone(mesh, tr)
  const name = def.bones[bi] ? def.bones[bi].name : ''
  if (/foot|ball|toe/i.test(name)) {
    const side = /(^|_)l($|_)/.test(name) || name.endsWith('_l') ? 'l' : 'r'
    footTris[side].push(tr)
  } else {
    bodyIdx.push(tr.a, tr.b, tr.c)
    bodyOffs.push(tr.offset)
  }
}
if (footTris.l.length === 0 || footTris.r.length === 0) throw new Error('没有找到左右脚的三角形')

const newVerts = [...mesh.verts]
const newUvs = [...mesh.uvs]
const newSkin = [...mesh.skinIndices]
const newWeights = [...mesh.skinWeights]
const parts = [{
  ...part,
  base: 0,
  count: bodyIdx.length / 3,
  indices: bodyIdx,
  tex: 0,
  depthOffsets: bodyOffs
}]
const textures = [...def.textures, `ai/${bootLName}`, `ai/${bootRName}`]

function addFoot (side, tris, boot) {
  const oldVerts = [...new Set(tris.flatMap(t => [t.a, t.b, t.c]))].sort((a, b) => a - b)
  let x0 = 1e9, y0 = 1e9, x1 = -1e9, y1 = -1e9
  for (const v of oldVerts) {
    x0 = Math.min(x0, mesh.verts[v * 2]); x1 = Math.max(x1, mesh.verts[v * 2])
    y0 = Math.min(y0, mesh.verts[v * 2 + 1]); y1 = Math.max(y1, mesh.verts[v * 2 + 1])
  }
  const uv = planarUvsForBox(mesh, oldVerts, [x0, y0, x1, y1], boot)
  const map = new Map()
  for (let i = 0; i < oldVerts.length; i++) {
    const old = oldVerts[i]
    map.set(old, newVerts.length / 2)
    newVerts.push(mesh.verts[old * 2], mesh.verts[old * 2 + 1])
    newUvs.push(uv[i * 2], uv[i * 2 + 1])
    for (let k = 0; k < 4; k++) {
      newSkin.push(mesh.skinIndices[old * 4 + k])
      newWeights.push(mesh.skinWeights[old * 4 + k])
    }
  }
  const idx = [], off = []
  for (const t of tris) {
    idx.push(map.get(t.a), map.get(t.b), map.get(t.c))
    off.push(t.offset)
  }
  parts.push({
    base: 0,
    count: idx.length / 3,
    indices: idx,
    tex: textures.length - (side === 'l' ? 2 : 1),
    color: (part.color || [1, 1, 1, 1]),
    depthOffsets: off
  })
  return { verts: oldVerts.length, tris: tris.length }
}
const statL = addFoot('l', footTris.l, bootL)
const statR = addFoot('r', footTris.r, bootR)

const outDef = JSON.parse(JSON.stringify(def))
outDef.textures = textures
outDef.mesh = {
  verts: newVerts,
  uvs: newUvs,
  skinIndices: newSkin,
  skinWeights: newWeights,
  parts
}
outDef.ai = {
  ...(def.ai || {}),
  feetSplit: true,
  boots: [textures[1], textures[2]],
  footStats: { l: statL, r: statR }
}
aiJson.characters[CHAR] = outDef
fs.writeFileSync(aiJsonPath, JSON.stringify(aiJson))

fs.writeFileSync(path.join(dataDir, 'ai', `${CHAR}-${view}.json`), JSON.stringify({
  name: CHAR, view, textures, parts: parts.map(p => ({ tex: p.tex, tris: p.indices.length / 3 })),
  vertices: newVerts.length / 2, feet: { l: statL, r: statR }, generatedAt: new Date().toISOString()
}, null, 2))

console.log(`拆分脚：左脚 ${statL.tris} 三角 / 右脚 ${statR.tris} 三角`)
console.log(`  新网格 ${newVerts.length / 2} 顶点 / ${(bodyIdx.length + footTris.l.length * 3 + footTris.r.length * 3) / 3} 三角 / ${parts.length} 个 part`)
console.log('  贴图:', textures.map(t => path.basename(t)).join(', '))
