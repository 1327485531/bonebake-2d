// AruHub 图片接口的最小封装（gpt-image-2 系列）。密钥只从环境变量读。
import fs from 'node:fs'
import path from 'node:path'

export const API_BASE = (process.env.ARUHUB_BASE_URL || 'https://api.aruhub.com/v1').replace(/\/+$/, '')

async function saveImageResponse (res, text, rawPath) {
  if (!res.ok) throw new Error(`图片接口 ${res.status}: ${text.slice(0, 600)}`)
  let json
  try { json = JSON.parse(text) } catch { throw new Error('返回不是 JSON: ' + text.slice(0, 300)) }
  const item = json.data && json.data[0]
  if (!item) throw new Error('返回里没有 data[0]: ' + text.slice(0, 300))
  let buf
  if (item.b64_json) buf = Buffer.from(item.b64_json, 'base64')
  else if (item.url) {
    const r = await fetch(item.url, { signal: AbortSignal.timeout(120000) })
    if (!r.ok) throw new Error('下载生成图失败 ' + r.status)
    buf = Buffer.from(await r.arrayBuffer())
  } else throw new Error('返回里没有 b64_json/url')
  fs.writeFileSync(rawPath, buf)
  return buf
}

export async function generateEdit ({ refPath, prompt, model = 'gpt-image-2', size = '1024x1024', quality = 'medium', rawPath }) {
  const key = process.env.ARUHUB_API_KEY || ''
  if (!key) throw new Error('没有 ARUHUB_API_KEY 环境变量')
  const form = new FormData()
  form.set('model', model)
  form.set('image', new Blob([fs.readFileSync(refPath)], { type: 'image/png' }), path.basename(refPath))
  form.set('prompt', prompt)
  form.set('size', size)
  form.set('quality', quality)
  form.set('n', '1')

  const t0 = Date.now()
  const res = await fetch(`${API_BASE}/images/edits`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${key}` },
    body: form,
    signal: AbortSignal.timeout(10 * 60 * 1000)
  })
  const text = await res.text()
  const buf = await saveImageResponse(res, text, rawPath)
  console.log(`   API 生成完成：${((Date.now() - t0) / 1000).toFixed(0)}s，${(buf.length / 1024).toFixed(0)}KB → ${path.relative(process.cwd(), rawPath)}`)
  return buf
}

export async function generateImage ({ prompt, model = 'gpt-image-2', size = '1024x1024', quality = 'medium', rawPath }) {
  const key = process.env.ARUHUB_API_KEY || ''
  if (!key) throw new Error('没有 ARUHUB_API_KEY 环境变量')
  const t0 = Date.now()
  const res = await fetch(`${API_BASE}/images/generations`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${key}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ model, prompt, size, quality, n: 1 }),
    signal: AbortSignal.timeout(10 * 60 * 1000)
  })
  const text = await res.text()
  const buf = await saveImageResponse(res, text, rawPath)
  console.log(`   API 文生图完成：${((Date.now() - t0) / 1000).toFixed(0)}s，${(buf.length / 1024).toFixed(0)}KB → ${path.relative(process.cwd(), rawPath)}`)
  return buf
}
