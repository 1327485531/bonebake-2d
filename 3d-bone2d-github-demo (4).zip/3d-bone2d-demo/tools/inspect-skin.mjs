// 看一个角色的"贴图"到底是什么：语义皮肤，还是 Mesh2Motion 的调色板图？
// 统计 UV 实际用到的矩形/像素比例/颜色数量。做 AI 皮肤前先跑这个，能避免走错方向。
//
// 用法:
//   node tools/inspect-skin.mjs --data out/side --char male
//   node tools/inspect-skin.mjs --data out/side --all
import fs from 'node:fs'
import path from 'node:path'
import { decodePng } from './ai-image.mjs'

const argv = process.argv.slice(2)
const opt = (n, d) => { const i = argv.indexOf('--' + n); return i === -1 ? d : argv[i + 1] }
const dataDir = path.resolve(opt('data', 'out/side'))
const chars = JSON.parse(fs.readFileSync(path.join(dataDir, 'characters.json'), 'utf8'))
const names = argv.includes('--all') ? Object.keys(chars.characters) : [opt('char', 'male')]

function inspect (name) {
  const def = chars.characters[name]
  if (!def) { console.log(`没有角色 ${name}`); return }
  const mesh = def.mesh
  let minU = 1e9, maxU = -1e9, minV = 1e9, maxV = -1e9
  for (let i = 0; i < mesh.uvs.length; i += 2) {
    minU = Math.min(minU, mesh.uvs[i]); maxU = Math.max(maxU, mesh.uvs[i])
    minV = Math.min(minV, mesh.uvs[i + 1]); maxV = Math.max(maxV, mesh.uvs[i + 1])
  }
  const colors = new Map()
  const pixels = new Set()
  let nTri = 0
  let texInfo = null
  for (const part of mesh.parts) {
    const rel = def.textures[part.tex]
    if (!rel) continue
    const tex = decodePng(fs.readFileSync(path.join(dataDir, rel)))
    texInfo = { rel, width: tex.width, height: tex.height }
    for (let t = 0; t < part.indices.length; t += 3) {
      let u = 0, v = 0
      for (let k = 0; k < 3; k++) {
        const vi = part.indices[t + k]
        u += mesh.uvs[vi * 2] / 3
        v += mesh.uvs[vi * 2 + 1] / 3
      }
      const x = Math.min(tex.width - 1, Math.max(0, Math.floor(u * tex.width)))
      const y = Math.min(tex.height - 1, Math.max(0, Math.floor(v * tex.height)))
      const o = (y * tex.width + x) * 4
      const col = `${tex.data[o]},${tex.data[o + 1]},${tex.data[o + 2]}`
      colors.set(col, (colors.get(col) || 0) + 1)
      pixels.add(y * tex.width + x)
      nTri++
    }
  }
  const top = [...colors.entries()].sort((a, b) => b[1] - a[1]).slice(0, 8)
  const usedPx = pixels.size
  const totalPx = texInfo.width * texInfo.height
  const uvW = maxU - minU, uvH = maxV - minV
  console.log(`\n${name}: ${texInfo.rel} ${texInfo.width}x${texInfo.height}`)
  console.log(`  UV 使用范围 u ${minU.toFixed(4)}..${maxU.toFixed(4)}  v ${minV.toFixed(4)}..${maxV.toFixed(4)}`)
  console.log(`  UV 占用贴图比例 ${(uvW * uvH * 100).toFixed(2)}%  (${Math.round(uvW * texInfo.width)}x${Math.round(uvH * texInfo.height)} px)`)
  console.log(`  三角面采样到的不同像素 ${usedPx} / ${totalPx}（${(usedPx / totalPx * 100).toFixed(2)}%）`)
  console.log(`  三角面采样到的不同颜色 ${colors.size} 个；${nTri} 个三角面`)
  console.log('  颜色 Top: ' + top.map(([c, n]) => `rgb(${c})×${n}`).join('  '))
  if (colors.size <= 4 && uvW * uvH < 0.2) {
    console.log('  → 这是**调色板/纯色贴图**，不是语义皮肤。直接在这个 UV 布局里画细节，网格采不到。')
  }
}

for (const n of names) inspect(n)
