// 手绘皮肤模板包：把 6 个身体块的几何参考图变成可描线的 1024x1024 模板。
//
// 每个部位输出两张：
//   template-<group>.png  品红半透明轮廓（可直接当参考层；导入工具会剥掉品红）
//   canvas-<group>.png    全透明画布（尺寸/位置一致，适合把 guide 放在另一个窗口描）
// 另外拼一张 3x2 的 sheet.png，导入工具可以直接吃这张。
//
// 侧视的 arm_l / arm_r 用 Walk 0 的纹理姿态（和 ai-skin-parts --pose 一致），
// 其他块用 bind；正视图全部 bind。
//
// 用法：
//   node tools/make-templates.mjs --views side,front --out templates
//   node tools/make-templates.mjs --views side --size 1024
import fs from 'node:fs'
import path from 'node:path'
import { execFileSync } from 'node:child_process'
import { decodePng, encodePng, GROUP_ORDER } from './ai-image.mjs'
import { loadClip, computePosedVerts } from './pose2d.mjs'

const argv = process.argv.slice(2)
const opt = (n, d) => { const i = argv.indexOf('--' + n); return i === -1 ? d : argv[i + 1] }
const has = (n) => argv.includes('--' + n)

const BASE = opt('base', 'out')
const CHAR = opt('char', 'male')
const OUT = opt('out', 'templates')
const SIZE = Number(opt('size', '1024'))
const VIEWS = (() => {
  const v = (opt('views', 'side,front')).split(',').map(s => s.trim()).filter(Boolean)
  return v.includes('both') ? ['side', 'front'] : v
})()
const SIDE_POSE = opt('side-pose', 'Walk')
const SIDE_FRAME = Number(opt('side-frame', '0'))
const ARM_GROUPS = new Set(['arm_l', 'arm_r'])

if (!Number.isInteger(SIZE) || SIZE < 512 || SIZE > 2048) {
  throw new Error('--size 必须是 512..2048 的整数')
}
if (!Number.isInteger(SIDE_FRAME) || SIDE_FRAME < 0) throw new Error('--side-frame 必须是非负整数')

const GROUP_INDEX = new Map(GROUP_ORDER.map((g, i) => [g, i]))
const CELL_W = SIZE, CELL_H = SIZE, COLS = 3, ROWS = 2

/** 双线性缩放 RGBA */
function resizeRGBA (src, sw, sh, dw, dh) {
  const out = new Uint8Array(dw * dh * 4)
  for (let y = 0; y < dh; y++) {
    const sy = (y + 0.5) * sh / dh - 0.5
    const y0 = Math.max(0, Math.min(sh - 1, Math.floor(sy)))
    const y1 = Math.min(sh - 1, y0 + 1)
    const fy = Math.max(0, Math.min(1, sy - y0))
    for (let x = 0; x < dw; x++) {
      const sx = (x + 0.5) * sw / dw - 0.5
      const x0 = Math.max(0, Math.min(sw - 1, Math.floor(sx)))
      const x1 = Math.min(sw - 1, x0 + 1)
      const fx = Math.max(0, Math.min(1, sx - x0))
      const o = (y * dw + x) * 4
      for (let k = 0; k < 4; k++) {
        const v00 = src[(y0 * sw + x0) * 4 + k]
        const v10 = src[(y0 * sw + x1) * 4 + k]
        const v01 = src[(y1 * sw + x0) * 4 + k]
        const v11 = src[(y1 * sw + x1) * 4 + k]
        const a = v00 + (v10 - v00) * fx
        const b = v01 + (v11 - v01) * fx
        out[o + k] = Math.round(a + (b - a) * fy)
      }
    }
  }
  return out
}

function cornerBg (img) {
  const { width: w, height: h, data } = img
  const pts = [[2, 2], [w - 3, 2], [2, h - 3], [w - 3, h - 3]]
  const rgb = [0, 0, 0]
  for (const [x, y] of pts) {
    const i = (y * w + x) * 4
    rgb[0] += data[i]; rgb[1] += data[i + 1]; rgb[2] += data[i + 2]
  }
  return rgb.map(v => Math.round(v / pts.length))
}

function silhouette (img) {
  const { width: w, height: h, data } = img
  const bg = cornerBg(img)
  const mask = new Uint8Array(w * h)
  const tol = 30 * 30
  for (let i = 0; i < w * h; i++) {
    const r = data[i * 4], g = data[i * 4 + 1], b = data[i * 4 + 2], a = data[i * 4 + 3]
    if (a === 0) continue
    const dr = r - bg[0], dg = g - bg[1], db = b - bg[2]
    if (dr * dr + dg * dg + db * db > tol) mask[i] = 1
  }
  return mask
}

function erode (mask, w, h, r) {
  const out = new Uint8Array(w * h)
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      let keep = 1
      for (let dy = -r; dy <= r && keep; dy++) {
        for (let dx = -r; dx <= r; dx++) {
          const nx = x + dx, ny = y + dy
          if (nx < 0 || ny < 0 || nx >= w || ny >= h || !mask[ny * w + nx]) { keep = 0; break }
        }
      }
      out[y * w + x] = keep
    }
  }
  return out
}

/** 768 参考图 → 品红 guide（透明底） */
function makeGuide (ref) {
  const { width: w, height: h } = ref
  const mask = silhouette(ref)
  const inner = erode(mask, w, h, 2)
  const out = new Uint8Array(w * h * 4)
  let minX = w, minY = h, maxX = -1, maxY = -1
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const i = y * w + x
      if (!mask[i]) continue
      if (x < minX) minX = x
      if (x > maxX) maxX = x
      if (y < minY) minY = y
      if (y > maxY) maxY = y
      const o = i * 4
      const edge = !inner[i]
      // 品红 guide：填充很淡，边缘清楚一点；导入工具按品红剥掉
      out[o] = 255; out[o + 1] = 0; out[o + 2] = 255
      out[o + 3] = edge ? 210 : 32
    }
  }
  if (maxX < 0) throw new Error('参考图里没有抠出部件')
  // 很淡的取景框 + 中心十字（也是品红，导入时会被剥掉）
  const pad = Math.max(4, Math.round(Math.min(w, h) * 0.01))
  const bx0 = Math.max(0, minX - pad), by0 = Math.max(0, minY - pad)
  const bx1 = Math.min(w - 1, maxX + pad), by1 = Math.min(h - 1, maxY + pad)
  const put = (x, y, a) => {
    if (x < 0 || y < 0 || x >= w || y >= h) return
    const o = (y * w + x) * 4
    if (out[o + 3] > a) return
    out[o] = 255; out[o + 1] = 0; out[o + 2] = 255; out[o + 3] = a
  }
  for (let x = bx0; x <= bx1; x++) { put(x, by0, 70); put(x, by1, 70) }
  for (let y = by0; y <= by1; y++) { put(bx0, y, 70); put(bx1, y, 70) }
  const cx = Math.round((minX + maxX) / 2), cy = Math.round((minY + maxY) / 2)
  for (let d = -18; d <= 18; d++) { put(cx + d, cy, 55); put(cx, cy + d, 55) }
  return { data: out, width: w, height: h, bbox: [minX, minY, maxX, maxY] }
}

function readmeFor (view) {
  const side = view === 'side'
  const cell = `每个格子 ${SIZE}x${SIZE}，顺序（从左到右、从上到下）：
\`head / torso / arm_l / arm_r / leg_l / leg_r\``
  return `# 手绘模板包（${view}）

${cell}

## 文件

| 文件 | 用途 |
|---|---|
| \`template-<group>.png\` | ${SIZE}x${SIZE}，透明底 + 品红轮廓；直接当参考层描线 |
| \`canvas-<group>.png\` | ${SIZE}x${SIZE}，全透明画布；把 guide 放另一个窗口/图层对照 |
| \`sheet.png\` | ${COLS * SIZE}x${ROWS * SIZE}，3x2，可整张画完直接导入 |
| \`ref-<group>.png\` | 768x768 几何参考图；AI 生成器的图生图输入 |
| \`base-male.json\` | 离线导入器用的 male 骨骼/网格 |
| \`pose-walk0.json\` | 侧视 Walk 0 顶点位置（离线构建手臂 UV 用；front 没有） |

品红（#FF00FF）只是 guide，导入工具会自动剥掉；如果不想保留 guide，在导出前隐藏/删除它。
${side
  ? `侧视手臂用的是 **${SIDE_POSE} 第 ${SIDE_FRAME} 帧**（手臂伸开），不是 T-pose。`
  : '正视图全部是 T-pose；侧视手臂模板见 `templates/side`。'}

## 画法

1. 打开 \`template-<group>.png\`，新建一个图层在上层描线/上色；
2. 尽量画在品红轮廓内，保持同样的姿势和取景；
3. 导出透明 PNG（或纯色背景也可以，导入工具会抠）；
4. 整张 sheet 画完就存 \`sheet.png\`；分块画就存 6 张 \`<myname>-<group>-${view}.png\`。

## 导入 / 构建

\`\`\`bash
# 整张 3x2 sheet
node tools/import-part-drawing.mjs --view ${view} --sheet templates/${view}/sheet.png --name mychar

# 或 6 张部件图
node tools/import-part-drawing.mjs --view ${view} --dir templates/${view} --prefix template --name mychar
\`\`\`

${side
  ? `侧视默认会用 \`--pose ${SIDE_POSE} --pose-frame ${SIDE_FRAME} --pose-groups arm_l,arm_r\`；`
  : '正视图是 T-pose，不需要 `--pose`；侧视导入时才需要 Walk 0 的 pose。'}
要 Q 版大头追加 \`--head-scale 2\`。**不要加披风/武器/大帽子改变轮廓**，否则内容包围盒会变，
平面 UV 会把新图拉伸。换身体比例需要重做网格/权重，不是换贴图能解决的。

## 可视化导入

- **服务模式**：\`node tools/import-ui-server.mjs\` → \`http://127.0.0.1:8898/\`，构建直接写 \`out/\`。
- **离线模式**：用任意静态服务器打开 \`web/import.html\`（例如 \`python3 -m http.server 8898\`），
  页面会在浏览器里抠图/打包，构建后下载 \`atlas.png\` + \`characters-ai.json\`，手动放进 \`out/<view>/\`。
- 离线构建靠本目录的 \`base-male.json\`${side ? ' 和 \`pose-walk0.json\`' : '（front 不需要 pose-walk0.json）'}；由 \`make-templates\` 生成。
`
}

function buildView (view) {
  const dataDir = path.join(BASE, view)
  const outDir = path.join(OUT, view)
  fs.mkdirSync(outDir, { recursive: true })
  const sheet = new Uint8Array(COLS * CELL_W * ROWS * CELL_H * 4)
  const sheetW = COLS * CELL_W, sheetH = ROWS * CELL_H

  console.log(`\n===== ${view} / 模板包 =====`)
  for (const group of GROUP_ORDER) {
    const idx = GROUP_INDEX.get(group)
    const posed = view === 'side' && ARM_GROUPS.has(group)
    const clip = posed ? SIDE_POSE : 'bind'
    const frame = posed ? SIDE_FRAME : 0
    const refPath = path.join(outDir, `ref-${group}.png`)
    console.log(`  [${group}] 渲染参考 ${clip}:${frame}…`)
    execFileSync(process.execPath, [
      'tools/render-ref.mjs', dataDir, CHAR, clip, String(frame), refPath,
      '--group', group, '--bg', 'f2f2f2'
    ], { stdio: 'inherit' })

    const ref = decodePng(fs.readFileSync(refPath))
    const guide = makeGuide(ref)
    const guide1024 = resizeRGBA(guide.data, guide.width, guide.height, SIZE, SIZE)
    fs.writeFileSync(path.join(outDir, `template-${group}.png`), encodePng(SIZE, SIZE, guide1024))
    fs.writeFileSync(path.join(outDir, `canvas-${group}.png`), encodePng(SIZE, SIZE, new Uint8Array(SIZE * SIZE * 4)))

    const col = idx % COLS, row = (idx / COLS) | 0
    const ox = col * CELL_W, oy = row * CELL_H
    for (let y = 0; y < SIZE; y++) {
      const src = y * SIZE * 4
      const dst = ((oy + y) * sheetW + ox) * 4
      sheet.set(guide1024.subarray(src, src + SIZE * 4), dst)
    }
  }
  fs.writeFileSync(path.join(outDir, 'sheet.png'), encodePng(sheetW, sheetH, sheet))
  fs.writeFileSync(path.join(outDir, 'README.md'), readmeFor(view))

  // 离线导入器（纯浏览器构建）需要的基础数据：male 的骨骼/网格 + 侧视 Walk 0 的顶点位置
  const chars = JSON.parse(fs.readFileSync(path.join(dataDir, 'characters.json'), 'utf8'))
  const baseMale = chars.characters[CHAR]
  if (!baseMale) throw new Error(`characters.json 里没有 ${CHAR}`)
  fs.writeFileSync(path.join(outDir, 'base-male.json'), JSON.stringify(baseMale))
  if (view === 'side') {
    const posed = computePosedVerts(baseMale, loadClip(dataDir, SIDE_POSE), SIDE_FRAME)
    const verts = new Array(posed.length)
    for (let i = 0; i < posed.length; i++) verts[i] = Math.round(posed[i] * 1e4) / 1e4
    fs.writeFileSync(path.join(outDir, 'pose-walk0.json'), JSON.stringify({
      char: CHAR, clip: SIDE_POSE, frame: SIDE_FRAME, verts
    }))
    console.log(`  ✔ ${path.join(outDir, 'pose-walk0.json')} (${verts.length / 2} 顶点)`)
  }
  console.log(`  ✔ ${path.join(outDir, 'base-male.json')}`)
  console.log(`  ✔ ${outDir}/template-*.png, canvas-*.png, sheet.png`)
  console.log(`  ✔ sheet ${sheetW}x${sheetH}，格 ${SIZE}x${SIZE}，顺序 ${GROUP_ORDER.join(', ')}`)
}

for (const view of VIEWS) {
  if (!['side', 'front'].includes(view)) throw new Error('view 只能是 side / front')
  buildView(view)
}
console.log('\n完成。把模板发出去画，或用 tools/import-part-drawing.mjs 导入。')
