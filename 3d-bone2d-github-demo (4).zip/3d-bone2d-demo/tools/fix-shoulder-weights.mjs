// 修肩膀被右臂扯动：把 torso 块里“离肩关节太远”的 upperarm 权重按距离衰减，
// 削掉的部分转给 spine_03（胸/脊椎），这样手臂姿势不变、胸口不再跟着大臂走。
//
// 背景：3D 源模型的上臂权重覆盖到了肩/胸；2D 侧视里上臂/锁骨又高度重叠，
// 大臂一摆，torso 块的胸口就被拉成三角形。直接在躯干块上做距离衰减，不动骨骼/动画。
//
// 用法：
//   node tools/fix-shoulder-weights.mjs --views side,front
//   node tools/fix-shoulder-weights.mjs --views side --r0 0.03 --r1 0.09
//   node tools/fix-shoulder-weights.mjs --views side --force   # 已修过也重跑（不推荐）
//
// 处理 out/<view>/characters.json 和 characters-ai.json 里的所有角色；
// 每个角色写入 shoulderFix 标记，重复运行会跳过。
import fs from 'node:fs'
import path from 'node:path'
import { splitMeshGroups, rebalanceNeck } from './ai-image.mjs'
import { bindBoneOrigin } from './pose2d.mjs'

const argv = process.argv.slice(2)
const opt = (n, d) => { const i = argv.indexOf('--' + n); return i === -1 ? d : argv[i + 1] }
const has = (n) => argv.includes('--' + n)

const BASE = opt('base', 'out')
const VIEWS = (opt('views', 'side,front')).split(',').map(s => s.trim()).filter(Boolean)
const R0 = Number(opt('r0', '0.03'))
const R1 = Number(opt('r1', '0.09'))
const FORCE = has('force')

if (!(R0 >= 0 && R1 > R0)) throw new Error('需要 0 <= r0 < r1')
for (const v of VIEWS) if (!['side', 'front'].includes(v)) throw new Error('view 只能是 side / front')

function armBoneNames (name) {
  return /(upperarm|lowerarm|forearm|hand|finger|thumb|index|middle|ring|pinky)/i.test(name)
}

function pickTransferBone (char) {
  const names = char.bones.map(b => b.name)
  for (const n of ['spine_03', 'spine_02', 'spine_01', 'chest', 'torso']) {
    const i = names.indexOf(n)
    if (i >= 0) return i
  }
  // 兜底：取 torso 权重里出现最多的非手臂骨
  const counts = new Map()
  const mesh = char.mesh
  const nv = mesh.verts.length / 2
  for (let v = 0; v < nv; v++) {
    for (let k = 0; k < 4; k++) {
      const b = mesh.skinIndices[v * 4 + k], w = mesh.skinWeights[v * 4 + k]
      if (w <= 0) continue
      if (armBoneNames(names[b] || '')) continue
      counts.set(b, (counts.get(b) || 0) + w)
    }
  }
  let best = -1, bw = -1
  for (const [b, w] of counts) if (w > bw) { bw = w; best = b }
  return best
}

function torsoVerts (char) {
  if (char.ai && Array.isArray(char.ai.groups)) {
    let off = 0
    for (const g of char.ai.groups) {
      if (g.name === 'torso') return Array.from({ length: g.vertices }, (_, i) => off + i)
      off += g.vertices
    }
  }
  const { groups } = splitMeshGroups(char)
  rebalanceNeck(groups, char)
  const t = groups.find(g => g.name === 'torso')
  return t ? t.verts : []
}

function fixChar (char) {
  if (char.shoulderFix && char.shoulderFix.version === 1 && !FORCE) return { skipped: true, touched: 0 }
  const names = char.bones.map(b => b.name)
  const ul = names.indexOf('upperarm_l')
  const ur = names.indexOf('upperarm_r')
  if (ul < 0 && ur < 0) return { skipped: true, touched: 0 }
  const transfer = pickTransferBone(char)
  if (transfer < 0) return { skipped: true, touched: 0 }

  const orgL = ul >= 0 ? bindBoneOrigin(char, 'upperarm_l') : null
  const orgR = ur >= 0 ? bindBoneOrigin(char, 'upperarm_r') : null

  // 权重会改变“主导骨”；在修之前把三角分组固化下来，避免模板/ref/贴图边界跟着漂。
  // AI 角色的分组已经写在 ai.groups/图集里，不再改。
  if (!char.ai) {
    const { triRecords } = splitMeshGroups(char)
    char.partGroups = triRecords.map(r => r.gi)
  }
  const torso = torsoVerts(char)
  const mesh = char.mesh
  let touched = 0

  for (const v of torso) {
    const m = new Map()
    for (let k = 0; k < 4; k++) {
      const b = mesh.skinIndices[v * 4 + k], w = mesh.skinWeights[v * 4 + k]
      if (w > 0) m.set(b, (m.get(b) || 0) + w)
    }
    let changed = false
    for (const [bone, org] of [[ul, orgL], [ur, orgR]]) {
      if (bone < 0 || !org) continue
      const w = m.get(bone) || 0
      if (w <= 0) continue
      const dx = mesh.verts[v * 2] - org[0]
      const dy = mesh.verts[v * 2 + 1] - org[1]
      const d = Math.hypot(dx, dy)
      const keep = Math.max(0, Math.min(1, (R1 - d) / (R1 - R0)))
      const nw = w * keep
      const cut = w - nw
      if (cut > 1e-5) {
        m.set(bone, nw)
        m.set(transfer, (m.get(transfer) || 0) + cut)
        changed = true
      }
    }
    if (!changed) continue
    touched++
    const arr = [...m.entries()].filter(([, w]) => w > 1e-6).sort((a, b) => b[1] - a[1]).slice(0, 4)
    const sum = arr.reduce((s, x) => s + x[1], 0) || 1
    for (let k = 0; k < 4; k++) {
      const e = arr[k]
      mesh.skinIndices[v * 4 + k] = e ? e[0] : 0
      mesh.skinWeights[v * 4 + k] = e ? e[1] / sum : 0
    }
  }

  char.shoulderFix = {
    version: 1,
    r0: R0,
    r1: R1,
    transfer: names[transfer],
    touched,
    at: new Date().toISOString()
  }
  return { skipped: false, touched, total: torso.length }
}

for (const view of VIEWS) {
  for (const file of ['characters.json', 'characters-ai.json']) {
    const p = path.join(BASE, view, file)
    if (!fs.existsSync(p)) continue
    const j = JSON.parse(fs.readFileSync(p, 'utf8'))
    if (!j.characters) continue
    const before = JSON.stringify(j)
    let changed = false
    console.log(`\n=== ${view}/${file} ===`)
    for (const [name, char] of Object.entries(j.characters)) {
      const r = fixChar(char)
      if (r.skipped) continue
      changed = true
      console.log(`  ${name}: 肩部权重 ${r.touched}/${r.total} 个顶点 → ${char.shoulderFix.transfer}`)
    }
    if (changed && JSON.stringify(j) !== before) {
      const bak = p + '.bak'
      if (!fs.existsSync(bak)) fs.copyFileSync(p, bak)
      fs.writeFileSync(p, JSON.stringify(j))
      console.log(`  ✔ 写出 ${p}（原文件备份 ${path.basename(bak)}）`)
    } else {
      console.log('  无需修改')
    }
  }
}
console.log('\n完成。重新导出龙骨后，官方运行时也会用新的权重。')
