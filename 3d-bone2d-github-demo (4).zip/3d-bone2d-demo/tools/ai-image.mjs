// AI 皮肤共用的图片/UV 工具：PNG 编解码、抠图裁边、平面投影 UV、身体分块。
// 故意保持零依赖，生成流程在 ai-skin.mjs / ai-skin-parts.mjs 里。

import zlib from 'node:zlib'

// ---------------- PNG 读写 ----------------
export function decodePng (buf) {
  if (buf.length < 8 || buf.readUInt32BE(0) !== 0x89504e47) throw new Error('不是 PNG')
  let pos = 8
  let width = 0, height = 0, bitDepth = 0, colorType = 0, interlace = 0
  let palette = null
  let paletteAlpha = null
  const idat = []
  while (pos + 8 <= buf.length) {
    const len = buf.readUInt32BE(pos)
    const type = buf.toString('ascii', pos + 4, pos + 8)
    const data = buf.subarray(pos + 8, pos + 8 + len)
    if (type === 'IHDR') {
      width = data.readUInt32BE(0)
      height = data.readUInt32BE(4)
      bitDepth = data[8]
      colorType = data[9]
      interlace = data[12]
    } else if (type === 'PLTE') {
      palette = []
      for (let i = 0; i + 2 < data.length; i += 3) palette.push([data[i], data[i + 1], data[i + 2]])
    } else if (type === 'tRNS' && colorType === 3) {
      paletteAlpha = Array.from(data)
    } else if (type === 'IDAT') idat.push(data)
    else if (type === 'IEND') break
    pos += 12 + len
  }
  if (bitDepth !== 8) throw new Error(`只支持 8bit PNG（当前 ${bitDepth}bit）`)
  if (interlace !== 0) throw new Error('不支持隔行 PNG')
  const isPalette = colorType === 3
  if (isPalette && !palette) throw new Error('调色板 PNG 缺少 PLTE')
  const channels = isPalette ? 1 : colorType === 6 ? 4 : colorType === 2 ? 3 : colorType === 0 ? 1 : colorType === 4 ? 2 : 0
  if (!channels) throw new Error(`不支持的 PNG colorType=${colorType}`)
  const raw = zlib.inflateSync(Buffer.concat(idat))
  const stride = width * channels
  const rgba = new Uint8Array(width * height * 4)
  let prev = new Uint8Array(stride)
  let p = 0
  for (let y = 0; y < height; y++) {
    const filter = raw[p++]
    const line = raw.subarray(p, p + stride)
    p += stride
    const recon = new Uint8Array(stride)
    for (let x = 0; x < stride; x++) {
      const a = x >= channels ? recon[x - channels] : 0
      const b = prev[x]
      const c = x >= channels ? prev[x - channels] : 0
      let v = line[x]
      if (filter === 1) v += a
      else if (filter === 2) v += b
      else if (filter === 3) v += (a + b) >> 1
      else if (filter === 4) {
        const pp = a + b - c
        const pa = Math.abs(pp - a), pb = Math.abs(pp - b), pc = Math.abs(pp - c)
        v += pa <= pb && pa <= pc ? a : pb <= pc ? b : c
      } else if (filter !== 0) throw new Error('未知 PNG filter ' + filter)
      recon[x] = v & 255
    }
    for (let x = 0; x < width; x++) {
      const si = x * channels, di = (y * width + x) * 4
      if (isPalette) {
        const p = palette[recon[si]] || [0, 0, 0]
        rgba[di] = p[0]; rgba[di + 1] = p[1]; rgba[di + 2] = p[2]
        rgba[di + 3] = paletteAlpha && paletteAlpha[recon[si]] !== undefined ? paletteAlpha[recon[si]] : 255
      } else if (channels === 1) { rgba[di] = rgba[di + 1] = rgba[di + 2] = recon[si]; rgba[di + 3] = 255 }
      else if (channels === 2) { rgba[di] = rgba[di + 1] = rgba[di + 2] = recon[si]; rgba[di + 3] = recon[si + 1] }
      else if (channels === 3) { rgba[di] = recon[si]; rgba[di + 1] = recon[si + 1]; rgba[di + 2] = recon[si + 2]; rgba[di + 3] = 255 }
      else { rgba[di] = recon[si]; rgba[di + 1] = recon[si + 1]; rgba[di + 2] = recon[si + 2]; rgba[di + 3] = recon[si + 3] }
    }
    prev = recon
  }
  return { width, height, data: rgba }
}

function crc32 (buf) {
  let c, crc = 0xffffffff
  for (let i = 0; i < buf.length; i++) {
    c = (crc ^ buf[i]) & 0xff
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1
    crc = (crc >>> 8) ^ c
  }
  return (crc ^ 0xffffffff) >>> 0
}
function chunk (type, data) {
  const len = Buffer.alloc(4); len.writeUInt32BE(data.length)
  const td = Buffer.concat([Buffer.from(type, 'ascii'), data])
  const crc = Buffer.alloc(4); crc.writeUInt32BE(crc32(td))
  return Buffer.concat([len, td, crc])
}
export function encodePng (width, height, rgba) {
  const stride = width * 4
  const raw = Buffer.alloc((stride + 1) * height)
  for (let y = 0; y < height; y++) {
    raw[y * (stride + 1)] = 0
    Buffer.from(rgba.buffer, rgba.byteOffset + y * stride, stride).copy(raw, y * (stride + 1) + 1)
  }
  const ihdr = Buffer.alloc(13)
  ihdr.writeUInt32BE(width, 0); ihdr.writeUInt32BE(height, 4)
  ihdr[8] = 8; ihdr[9] = 6; ihdr[10] = 0; ihdr[11] = 0; ihdr[12] = 0
  return Buffer.concat([
    Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]),
    chunk('IHDR', ihdr), chunk('IDAT', zlib.deflateSync(raw)), chunk('IEND', Buffer.alloc(0))
  ])
}

// ---------------- 抠图 / 裁边 ----------------
const dist2 = (d, i, r, g, b) => {
  const dr = d[i] - r, dg = d[i + 1] - g, db = d[i + 2] - b
  return dr * dr + dg * dg + db * db
}
function pickBackground (img) {
  const { width, height, data } = img
  const pts = [[2, 2], [width - 3, 2], [2, height - 3], [width - 3, height - 3]]
  const rgb = [0, 0, 0]
  for (const [x, y] of pts) { const i = (y * width + x) * 4; rgb[0] += data[i]; rgb[1] += data[i + 1]; rgb[2] += data[i + 2] }
  return rgb.map(v => Math.round(v / pts.length))
}

/**
 * 去背景 + 裁到内容包围盒 + 向外补 2px 色边。
 * 返回的 u0/v0/u1/v1 是"内容包围盒"在当前图片里的归一化位置。
 */
export function processImage (img, padRatio = 0.012) {
  const { width: w, height: h, data } = img
  let hasAlpha = false
  for (let i = 3; i < data.length; i += 4) if (data[i] < 240) { hasAlpha = true; break }
  const opaque = new Uint8Array(w * h).fill(1)
  if (hasAlpha) {
    for (let i = 0; i < w * h; i++) opaque[i] = data[i * 4 + 3] > 32 ? 1 : 0
    for (let i = 0; i < w * h; i++) if (opaque[i]) data[i * 4 + 3] = 255
  } else {
    const [r, g, b] = pickBackground(img)
    const tol = 105 * 105
    const stack = []
    const seen = new Uint8Array(w * h)
    const push = (x, y) => {
      if (x < 0 || y < 0 || x >= w || y >= h) return
      const i = y * w + x
      if (seen[i] || !opaque[i]) return
      if (dist2(data, i * 4, r, g, b) > tol) return
      seen[i] = 1; stack.push(i)
    }
    for (let x = 0; x < w; x++) { push(x, 0); push(x, h - 1) }
    for (let y = 0; y < h; y++) { push(0, y); push(w - 1, y) }
    while (stack.length) {
      const i = stack.pop()
      opaque[i] = 0
      const x = i % w, y = (i / w) | 0
      push(x - 1, y); push(x + 1, y); push(x, y - 1); push(x, y + 1)
    }
    // 清品红描边：从边缘往里削 4 圈，再用 2px 色边补回来
    for (let pass = 0; pass < 4; pass++) {
      const kill = []
      for (let y = 1; y < h - 1; y++) {
        for (let x = 1; x < w - 1; x++) {
          const i = y * w + x
          if (!opaque[i]) continue
          if (!opaque[i - 1] || !opaque[i + 1] || !opaque[i - w] || !opaque[i + w]) kill.push(i)
        }
      }
      if (kill.length === 0) break
      for (const i of kill) { opaque[i] = 0; data[i * 4 + 3] = 0 }
    }
  }
  for (let i = 0; i < w * h; i++) if (!opaque[i]) data[i * 4 + 3] = 0
  // 全局清高饱和品红残留（角色本身没有品红）
  for (let i = 0; i < w * h; i++) {
    if (!opaque[i]) continue
    const R = data[i * 4], G = data[i * 4 + 1], B = data[i * 4 + 2]
    if (R > 70 && B > 70 && G < Math.min(R, B) * 0.7) { opaque[i] = 0; data[i * 4 + 3] = 0 }
  }
  // 剩下的紫色描边做 despill：把 R/B 往 G 拉，避免边缘一圈紫
  for (let i = 0; i < w * h; i++) {
    if (!opaque[i]) continue
    const R = data[i * 4], G = data[i * 4 + 1], B = data[i * 4 + 2]
    const m = Math.min(R, B) - G
    if (m > 8) {
      data[i * 4] = Math.max(0, Math.round(R - m * 0.85))
      data[i * 4 + 2] = Math.max(0, Math.round(B - m * 0.85))
    }
  }
  for (let i = 0; i < w * h; i++) if (!opaque[i]) data[i * 4 + 3] = 0

  let x0 = w, y0 = h, x1 = -1, y1 = -1
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      if (!opaque[y * w + x]) continue
      if (x < x0) x0 = x
      if (x > x1) x1 = x
      if (y < y0) y0 = y
      if (y > y1) y1 = y
    }
  }
  if (x1 < 0) throw new Error('抠图后没有任何不透明像素')
  const pad = Math.max(2, Math.round(Math.min(w, h) * padRatio * 0.2))

  // 从内容向外 BFS 补颜色，避免 UV 采样到边缘时透明/发黑
  const dist = new Int32Array(w * h).fill(-1)
  const queue = []
  for (let i = 0; i < w * h; i++) if (opaque[i]) { dist[i] = 0; queue.push(i) }
  let head = 0
  while (head < queue.length) {
    const i = queue[head++]
    const d0 = dist[i]
    if (d0 >= pad) continue
    const x = i % w, y = (i / w) | 0
    for (const [nx, ny] of [[x - 1, y], [x + 1, y], [x, y - 1], [x, y + 1]]) {
      if (nx < 0 || ny < 0 || nx >= w || ny >= h) continue
      const ni = ny * w + nx
      if (dist[ni] >= 0) continue
      dist[ni] = d0 + 1
      for (let k = 0; k < 3; k++) data[ni * 4 + k] = data[i * 4 + k]
      data[ni * 4 + 3] = 255
      queue.push(ni)
    }
  }

  const cx0 = Math.max(0, x0 - pad), cy0 = Math.max(0, y0 - pad)
  const cx1 = Math.min(w - 1, x1 + pad), cy1 = Math.min(h - 1, y1 + pad)
  const cw = cx1 - cx0 + 1, ch = cy1 - cy0 + 1
  const out = new Uint8Array(cw * ch * 4)
  for (let y = 0; y < ch; y++) {
    const src = ((y + cy0) * w + cx0) * 4
    out.set(data.subarray(src, src + cw * 4), y * cw * 4)
  }
  return {
    width: cw,
    height: ch,
    data: out,
    u0: (x0 - cx0) / cw,
    v0: (y0 - cy0) / ch,
    u1: (x1 + 1 - cx0) / cw,
    v1: (y1 + 1 - cy0) / ch
  }
}

// ---------------- 平面投影 UV ----------------
export function planarUvs (mesh, frame) {
  const { u0, v0, u1, v1 } = frame
  const nv = mesh.verts.length / 2
  let minX = 1e9, minY = 1e9, maxX = -1e9, maxY = -1e9
  for (let v = 0; v < nv; v++) {
    const x = mesh.verts[v * 2], y = mesh.verts[v * 2 + 1]
    if (x < minX) minX = x
    if (x > maxX) maxX = x
    if (y < minY) minY = y
    if (y > maxY) maxY = y
  }
  return {
    uvs: planarUvsForBox(mesh, [...Array(nv).keys()], [minX, minY, maxX, maxY], { u0, v0, u1, v1 }),
    meshBounds: [minX, minY, maxX, maxY]
  }
}

/**
 * 只给指定顶点集合算 UV，映射到给定包围盒 → 图片内容框。
 * positions 可传"另一姿态下的顶点位置"（纹理姿态），默认用绑定姿态 mesh.verts。
 */
export function planarUvsForBox (mesh, verts, box, frame, positions = mesh.verts) {
  const [minX, minY, maxX, maxY] = box
  const w = maxX - minX || 1, h = maxY - minY || 1
  const { u0, v0, u1, v1 } = frame
  const out = new Array(verts.length * 2)
  for (let i = 0; i < verts.length; i++) {
    const v = verts[i]
    const x = (positions[v * 2] - minX) / w
    const y = (positions[v * 2 + 1] - minY) / h
    out[i * 2] = round(u0 + x * (u1 - u0), 5)
    out[i * 2 + 1] = round(v0 + (1 - y) * (v1 - v0), 5)
  }
  return out
}

export function round (v, d) { const f = 10 ** d; return Math.round(v * f) / f }

// ---------------- 身体分块 ----------------
export const GROUP_ORDER = ['head', 'torso', 'arm_l', 'arm_r', 'leg_l', 'leg_r']
export const GROUP_LABEL = {
  head: '头 / 脖子',
  torso: '躯干 / 夹克',
  arm_l: '左臂 + 手',
  arm_r: '右臂 + 手（机械臂）',
  leg_l: '左腿 + 靴',
  leg_r: '右腿 + 靴'
}

/** 骨名 → 身体分块。与具体骨架无关，只看语义命名。 */
export function groupOfBone (name) {
  const n = String(name).toLowerCase()
  const side = /(^|_)l($|_)/.test(n) || n.endsWith('_l') ? 'l' : /(^|_)r($|_)/.test(n) || n.endsWith('_r') ? 'r' : ''
  if (/(head|neck|eye|jaw|face|hair)/.test(n)) return 'head'
  if (/(upperarm|lowerarm|forearm|hand|finger|thumb|index|middle|ring|pinky)/.test(n)) return 'arm_' + side
  if (/(thigh|calf|shin|foot|ball|toe)/.test(n)) return 'leg_' + side
  return 'torso'
}

/**
 * 把 mesh 的三角形按主导骨骼分到身体块。
 * 返回 { groups: [{name, tris:[{a,b,c,offset}], verts:[...], box}], triGroup:Int8Array }
 * tris 里保留原顶点索引和该三角的 depthOffset。
 */
export function splitMeshGroups (charDef) {
  const mesh = charDef.mesh
  const nBones = charDef.bones.length
  const boneGroup = charDef.bones.map(b => groupOfBone(b.name))
  const groupIndex = new Map(GROUP_ORDER.map((g, i) => [g, i]))
  const groups = GROUP_ORDER.map(name => ({ name, tris: [], verts: new Set() }))
  const triGroup = new Uint8Array(0) // 占位（按 part 遍历后重建）

  // 权重修复会改变“主导骨”，但分组/贴图边界要保持在修复前；
  // 修复工具会把修复前的三角组索引写进 partGroups，这里优先用它。
  const totalTris = mesh.parts.reduce((s, part) => s + part.indices.length / 3, 0)
  if (Array.isArray(charDef.partGroups) && charDef.partGroups.length === totalTris) {
    const triRecords = []
    let tGlobal = 0
    mesh.parts.forEach((part) => {
      const offs = part.depthOffsets || []
      for (let t = 0; t < part.indices.length; t += 3) {
        const gi = charDef.partGroups[tGlobal++]
        const a = part.indices[t], b = part.indices[t + 1], c = part.indices[t + 2]
        if (!(gi >= 0 && gi < GROUP_ORDER.length)) throw new Error('partGroups 里有无效分组索引')
        const rec = { a, b, c, offset: offs[t / 3] || 0 }
        groups[gi].tris.push(rec)
        triRecords.push({ gi, rec })
      }
    })
    finalizeGroups(groups, mesh)
    return { groups: groups.filter(g => g.tris.length > 0), triRecords }
  }

  const triRecords = []
  mesh.parts.forEach((part) => {
    const offs = part.depthOffsets || []
    for (let t = 0; t < part.indices.length; t += 3) {
      const a = part.indices[t], b = part.indices[t + 1], c = part.indices[t + 2]
      const score = new Map()
      for (const v of [a, b, c]) {
        for (let k = 0; k < 4; k++) {
          const w = mesh.skinWeights[v * 4 + k]
          if (w <= 0) continue
          const bi = mesh.skinIndices[v * 4 + k]
          if (bi < 0 || bi >= nBones) continue
          const g = boneGroup[bi]
          score.set(g, (score.get(g) || 0) + w)
        }
      }
      let best = 'torso', bestW = -1
      for (const g of GROUP_ORDER) {
        const w = score.get(g) || 0
        if (w > bestW) { bestW = w; best = g }
      }
      const gi = groupIndex.get(best)
      const rec = { a, b, c, offset: offs[t / 3] || 0 }
      groups[gi].tris.push(rec)
      triRecords.push({ gi, rec })
    }
  })

  finalizeGroups(groups, mesh)
  return { groups: groups.filter(g => g.tris.length > 0), triRecords }
}

/** 三角形的主导骨索引（按三顶点权重累加） */
export function dominantBone (mesh, tr) {
  const acc = new Map()
  for (const v of [tr.a, tr.b, tr.c]) {
    for (let k = 0; k < 4; k++) {
      const w = mesh.skinWeights[v * 4 + k]
      if (w <= 0) continue
      const bi = mesh.skinIndices[v * 4 + k]
      acc.set(bi, (acc.get(bi) || 0) + w)
    }
  }
  let best = 0, bestW = -1
  for (const [bi, w] of acc) if (w > bestW) { bestW = w; best = bi }
  return best
}

export function finalizeGroups (groups, mesh) {
  for (const g of groups) {
    g.verts = [...new Set(g.tris.flatMap(tr => [tr.a, tr.b, tr.c]))].sort((a, b) => a - b)
    let minX = 1e9, minY = 1e9, maxX = -1e9, maxY = -1e9
    for (const v of g.verts) {
      const x = mesh.verts[v * 2], y = mesh.verts[v * 2 + 1]
      if (x < minX) minX = x
      if (x > maxX) maxX = x
      if (y < minY) minY = y
      if (y > maxY) maxY = y
    }
    g.box = [minX, minY, maxX, maxY]
  }
}

/**
 * 头/颈分界：脖子根部的三角形归躯干，避免脸被一块"头+颈+肩"的贴图拉长。
 * 只对 head 组里主导骨含 neck 的三角形生效。
 */
export function rebalanceNeck (groups, charDef) {
  const head = groups.find(g => g.name === 'head')
  const torso = groups.find(g => g.name === 'torso')
  if (!head || !torso) return groups
  const keep = []
  for (const tr of head.tris) {
    const bi = dominantBone(charDef.mesh, tr)
    const name = charDef.bones[bi] ? charDef.bones[bi].name : ''
    if (/neck/i.test(name)) torso.tris.push(tr)
    else keep.push(tr)
  }
  head.tris = keep
  finalizeGroups(groups, charDef.mesh)
  return groups
}

/** 从整张人物图里裁出某个身体块（给"结构验证"或兜底用） */
export function cropImage (img, x0, y0, x1, y1) {
  const xa = Math.max(0, Math.floor(x0)), ya = Math.max(0, Math.floor(y0))
  const xb = Math.min(img.width - 1, Math.ceil(x1)), yb = Math.min(img.height - 1, Math.ceil(y1))
  const w = xb - xa + 1, h = yb - ya + 1
  const data = new Uint8Array(w * h * 4)
  for (let y = 0; y < h; y++) {
    const src = ((y + ya) * img.width + xa) * 4
    data.set(img.data.subarray(src, src + w * 4), y * w * 4)
  }
  return { width: w, height: h, data }
}

// ---------------- 图集打包 ----------------
/**
 * 把若干 part（{width,height,data,u0,v0,u1,v1}）按网格摆进一张 RGBA 图集。
 * 返回 { width,height,data, frames:{group:{u0,v0,u1,v1}} }，frames 是内容包围盒在图集里的归一化坐标。
 */
export function packAtlas (parts, {
  cols = 3, rows = 2, cellW = 660, cellH = 980, pad = 10, gap = 20
} = {}) {
  if (parts.length > cols * rows) throw new Error(`图集格子不够：${parts.length} 块 > ${cols}x${rows}`)
  const AW = cols * (cellW + gap) + gap
  const AH = rows * (cellH + gap) + gap
  if (AW > 4096 || AH > 4096) throw new Error(`图集太大 ${AW}x${AH}`)
  const data = new Uint8Array(AW * AH * 4)
  const frames = {}
  parts.forEach((p, i) => {
    // 透明像素的 RGB 可能是品红/白；图集里先清成黑色，避免双线性采样把品红带到边缘
    const src = new Uint8Array(p.data.length)
    for (let j = 0; j < p.data.length; j += 4) {
      if (p.data[j + 3] === 0) continue
      src[j] = p.data[j]; src[j + 1] = p.data[j + 1]; src[j + 2] = p.data[j + 2]; src[j + 3] = p.data[j + 3]
    }
    const col = i % cols, row = (i / cols) | 0
    const cx = gap + col * (cellW + gap)
    const cy = gap + row * (cellH + gap)
    const availW = cellW - pad * 2, availH = cellH - pad * 2
    const s = Math.min(availW / p.width, availH / p.height)
    const dw = Math.max(1, Math.round(p.width * s))
    const dh = Math.max(1, Math.round(p.height * s))
    const dx = cx + pad + Math.floor((availW - dw) / 2)
    const dy = cy + pad + Math.floor((availH - dh) / 2)
    // 双线性缩放写入图集
    for (let y = 0; y < dh; y++) {
      const sy = Math.min(p.height - 1, (y + 0.5) / s - 0.5)
      const y0 = Math.max(0, Math.floor(sy)), y1 = Math.min(p.height - 1, y0 + 1)
      const fy = sy - y0
      for (let x = 0; x < dw; x++) {
        const sx = Math.min(p.width - 1, (x + 0.5) / s - 0.5)
        const x0 = Math.max(0, Math.floor(sx)), x1 = Math.min(p.width - 1, x0 + 1)
        const fx = sx - x0
        const di = ((dy + y) * AW + (dx + x)) * 4
        for (let k = 0; k < 4; k++) {
          const v00 = src[(y0 * p.width + x0) * 4 + k]
          const v10 = src[(y0 * p.width + x1) * 4 + k]
          const v01 = src[(y1 * p.width + x0) * 4 + k]
          const v11 = src[(y1 * p.width + x1) * 4 + k]
          const a = v00 + (v10 - v00) * fx
          const b = v01 + (v11 - v01) * fx
          data[di + k] = Math.round(a + (b - a) * fy)
        }
      }
    }
    frames[p.name] = {
      u0: (dx + p.u0 * dw) / AW,
      v0: (dy + p.v0 * dh) / AH,
      u1: (dx + p.u1 * dw) / AW,
      v1: (dy + p.v1 * dh) / AH
    }
  })
  return { width: AW, height: AH, data, frames }
}
