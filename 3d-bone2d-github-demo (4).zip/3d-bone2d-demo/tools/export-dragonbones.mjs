// M2D → DragonBones 5.5 导出（CLI）
//
// 纯导出逻辑只有一份：web/dragonbones-export.js，浏览器端和这里共用。
// 这里只负责读 characters.json / anim.json、找 PNG、按角色写文件。
//
// 关键约定（详见 web/dragonbones-export.js 顶部注释）：
//   · M2D 是米/y 向上，龙骨是像素/y 向下 → 乘 300、y 取反、旋转取反
//   · 按网格包围盒把角色居中，否则 Pro 打开时角色在负 y 区域外，看起来"没有角色"
//   · Pro 按 slot/display/SubTexture 同名匹配贴图；三者统一，mesh 不写 path、保留 edges；width/height 用网格包围盒
//   · 动画在 0.25px / 0.05° 容差内抽关键帧，时间轴不再是每帧全满
//   · vertices 存绑定姿态的骨架空间坐标，slotPose=单位阵，bonePose=绑定姿态世界矩阵
//
// 用法:
//   node tools/export-dragonbones.mjs --data out/side --out out/side/dragonbones
//   node tools/export-dragonbones.mjs --data out/side --out out/side/dragonbones \
//     --extra out/side/characters-ai.json --chars ai_ronin
//   node tools/export-dragonbones.mjs --data out/side --out out/side/dragonbones --scale 300 --no-center

import fs from 'node:fs'
import path from 'node:path'
import { exportDragonBones, M2D_SCALE } from '../web/dragonbones-export.js'

/** 读 PNG 的 IHDR，拿宽高（零依赖） */
export function pngSize (buf) {
  const sig = [0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]
  for (let i = 0; i < sig.length; i++) if (buf[i] !== sig[i]) throw new Error('不是 PNG')
  return { width: buf.readUInt32BE(16), height: buf.readUInt32BE(20) }
}

/** 贴图文件名 → SubTexture 名：去掉扩展名，只保留可安全放进 JSON 的字符 */
function subTextureName (rel) {
  return path.basename(rel).replace(/\.[^.]+$/, '').replace(/[^\w.-]/g, '_')
}

// ---------------- CLI ----------------
import { fileURLToPath } from 'node:url'
const isMain = process.argv[1] && path.resolve(fileURLToPath(import.meta.url)) === path.resolve(process.argv[1])
if (isMain) {
  const argv = process.argv.slice(2)
  const opt = (n, d) => { const i = argv.indexOf('--' + n); return i === -1 ? d : argv[i + 1] }
  const dataDir = opt('data', 'out/side')
  const outDir = opt('out', path.join(dataDir, 'dragonbones'))
  const outFileArg = opt('file', null)
  const clips = opt('clips', null)
  const chars = opt('chars', null)
  const merge = argv.includes('--merge')
  const scale = Number(opt('scale', String(M2D_SCALE))) || M2D_SCALE
  const center = !argv.includes('--no-center')

  const charIndex = JSON.parse(fs.readFileSync(path.join(dataDir, 'characters.json'), 'utf8'))
  // 附加角色（例如 AI 皮肤生成后写入的 characters-ai.json）
  const extra = opt('extra', null)
  if (extra) {
    for (const f of extra.split(',')) {
      const p = path.resolve(f.trim())
      if (!fs.existsSync(p)) { console.warn('找不到附加角色文件', p); continue }
      const j = JSON.parse(fs.readFileSync(p, 'utf8'))
      if (j.characters) Object.assign(charIndex.characters, j.characters)
      console.log('  附加角色:', path.basename(p), Object.keys(j.characters || {}).join(','))
    }
  }
  const animData = JSON.parse(fs.readFileSync(path.join(dataDir, 'anim.json'), 'utf8'))
  const wantChars = chars ? chars.split(',') : Object.keys(charIndex.characters)

  fs.mkdirSync(outDir, { recursive: true })

  const texCache = new Map()
  const texInfo = (texRel) => {
    if (texCache.has(texRel)) return texCache.get(texRel)
    const abs = path.join(dataDir, texRel)
    if (!fs.existsSync(abs)) {
      console.warn('找不到贴图:', abs)
      texCache.set(texRel, null)
      return null
    }
    const size = pngSize(fs.readFileSync(abs))
    texCache.set(texRel, { abs, ...size })
    return texCache.get(texRel)
  }

  const wanted = wantChars.filter(c => {
    if (!charIndex.characters[c]) { console.warn('没有角色', c); return false }
    return true
  })

  const made = []
  if (merge) {
    const outFile = outFileArg || path.join(outDir, 'character.json')
    const outAbs = path.resolve(outFile)
    fs.mkdirSync(path.dirname(outAbs), { recursive: true })
    const armatures = []
    const atlases = new Map()
    for (const cname of wanted) {
      const db = exportDragonBones({
        charDef: charIndex.characters[cname],
        charName: cname,
        animData,
        clips: clips ? clips.split(',') : null,
        scale,
        center,
        textureResolver: (texRel) => {
          const tex = texInfo(texRel)
          if (!tex) return null
          return {
            name: subTextureName(texRel),
            imagePath: path.relative(path.dirname(outAbs), tex.abs).split(path.sep).join('/'),
            width: tex.width,
            height: tex.height
          }
        }
      })
      for (const a of db.textureAtlas) atlases.set(a.name, a)
      armatures.push(db.armature[0])
      const arm = db.armature[0]
      console.log(`  骨架 ${cname}: ${arm.bone.length} 骨 / ${arm.slot.length} 槽 / ${arm.skin[0].slot.length} 网格 / ${arm.animation.length} 动画`)
    }
    const out = {
      name: 'M2D',
      version: '5.5',
      compatibleVersion: '5.5',
      frameRate: animData.fps || 30,
      textureAtlas: [...atlases.values()],
      armature: armatures
    }
    fs.writeFileSync(outAbs, JSON.stringify(out))
    made.push(outAbs)
  } else {
    for (const cname of wanted) {
      const outAbs = path.resolve(outFileArg || path.join(outDir, `${cname}.json`))
      fs.mkdirSync(path.dirname(outAbs), { recursive: true })
      const db = exportDragonBones({
        charDef: charIndex.characters[cname],
        charName: cname,
        animData,
        clips: clips ? clips.split(',') : null,
        name: 'M2D',
        scale,
        center,
        textureResolver: (texRel) => {
          const tex = texInfo(texRel)
          if (!tex) return null
          return {
            name: subTextureName(texRel),
            imagePath: path.relative(path.dirname(outAbs), tex.abs).split(path.sep).join('/'),
            width: tex.width,
            height: tex.height
          }
        }
      })
      fs.writeFileSync(outAbs, JSON.stringify(db))
      const arm = db.armature[0]
      const keys = arm.animation.reduce((s, a) => s + (a.bone || []).reduce((t, b) =>
        t + (b.translateFrame ? b.translateFrame.length : 0) + (b.rotateFrame ? b.rotateFrame.length : 0), 0), 0)
      console.log(`  骨架 ${cname}: ${arm.bone.length} 骨 / ${arm.slot.length} 槽 / ${arm.skin[0].slot.length} 网格 / ${arm.animation.length} 动画 / ${keys} 关键帧 -> ${path.basename(outAbs)}`)
      made.push(outAbs)
    }
  }

  let total = 0
  for (const f of made) total += fs.statSync(f).size
  console.log(`\n写出 ${made.length} 个文件，共 ${(total / 1024 / 1024).toFixed(1)}MB`)
  for (const f of made.slice(0, 3)) console.log(' ', f)
  if (made.length > 3) console.log('  …')
}
