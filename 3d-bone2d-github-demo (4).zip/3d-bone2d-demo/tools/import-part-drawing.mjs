// 手绘/外部部件图导入：把 3x2 sheet 或 6 张分块图喂回 ai-skin-parts 的 --source custom。
//
// 输入可以是：
//   1) --sheet templates/side/sheet.png
//      3 列 x 2 行，顺序 head / torso / arm_l / arm_r / leg_l / leg_r
//   2) --dir mydrawings --prefix mychar
//      找 <prefix>-<group>-<view>.png / <prefix>-<group>.png / <group>-<view>.png / template-<group>.png
//
// 模板里的品红 guide 会被自动剥掉（--keep-guide 可关）；背景可以是透明或纯色。
// 导入后默认直接构建角色；加 --no-build 只写部件、打印构建命令。
//
// 用法：
//   node tools/import-part-drawing.mjs --view side --sheet templates/side/sheet.png --name mychar
//   node tools/import-part-drawing.mjs --view side --dir templates/side --prefix template --name mychar --head-scale 2
//   node tools/import-part-drawing.mjs --view front --dir mydrawings --prefix mychar --name mychar --no-build
import fs from 'node:fs'
import path from 'node:path'
import { execFileSync } from 'node:child_process'
import { decodePng, encodePng, processImage, cropImage, GROUP_ORDER } from './ai-image.mjs'

const argv = process.argv.slice(2)
const opt = (n, d) => { const i = argv.indexOf('--' + n); return i === -1 ? d : argv[i + 1] }
const has = (n) => argv.includes('--' + n)

const BASE = opt('base', 'out')
const VIEW = opt('view', 'side')
const NAME = opt('name', '')
const CHAR = opt('char', 'male')
const SHEET = opt('sheet', '')
const DIR = opt('dir', '')
const PREFIX = opt('prefix', '')
const HEAD_SCALE = Number(opt('head-scale', '1'))
const KEEP_GUIDE = has('keep-guide')
const NO_BUILD = has('no-build')
const COLS = Number(opt('cols', '3'))
const ROWS = Number(opt('rows', '2'))

if (!['side', 'front'].includes(VIEW)) throw new Error('--view 只能是 side / front')
if (!NAME || !/^[A-Za-z0-9_-]+$/.test(NAME)) throw new Error('--name 必填，只能用字母/数字/_-')
if (!SHEET && !DIR) throw new Error('需要 --sheet <file> 或 --dir <目录>')
if (SHEET && DIR) throw new Error('--sheet 和 --dir 只能二选一')
if (!Number.isFinite(HEAD_SCALE) || HEAD_SCALE < 0.5 || HEAD_SCALE > 3) throw new Error('--head-scale 必须在 0.5..3')

// 侧视默认：两条手臂都用 Walk 0 纹理姿态（模板也是按这个姿态画的）；--no-pose 可关
const NO_POSE = has('no-pose')
const POSE = VIEW === 'side' && !NO_POSE ? opt('pose', 'Walk') : 'bind'
const POSE_FRAME = Number(opt('pose-frame', '0'))
const POSE_GROUPS = opt('pose-groups', 'arm_l,arm_r')

const partsDir = path.join(BASE, VIEW, 'ai', 'parts')
fs.mkdirSync(partsDir, { recursive: true })

function stripMagenta (img) {
  if (KEEP_GUIDE) return img
  const d = img.data
  let removed = 0
  for (let i = 0; i < d.length; i += 4) {
    const r = d[i], g = d[i + 1], b = d[i + 2], a = d[i + 3]
    if (a === 0) continue
    // guide 是 #FF00FF；叠在白底/半透明底上会变成粉紫。用“R≈B 且 G 明显低”判定，
    // 比单纯 G<min(R,B) 更保守，避免把奶油色/肤色误杀。
    const lo = Math.min(r, b)
    if (r > 100 && b > 100 && Math.abs(r - b) < 70 && g < lo * 0.92) {
      d[i + 3] = 0
      removed++
    } else if (a < 8) {
      d[i + 3] = 0
    }
  }
  if (removed) console.log(`    剥掉品红 guide 像素: ${removed}`)
  return img
}

function loadSheet () {
  const img = decodePng(fs.readFileSync(SHEET))
  const cw = Math.floor(img.width / COLS)
  const ch = Math.floor(img.height / ROWS)
  if (cw < 64 || ch < 64) throw new Error(`sheet 太小/格数不对: ${img.width}x${img.height}, ${COLS}x${ROWS}`)
  if (img.width % COLS || img.height % ROWS) {
    console.log(`  ! sheet ${img.width}x${img.height} 不能被 ${COLS}x${ROWS} 整除，按 ${cw}x${ch} 切，边缘会有少量丢弃`)
  }
  console.log(`  sheet ${img.width}x${img.height} → ${COLS}x${ROWS}，格 ${cw}x${ch}`)
  return { img, cw, ch }
}

function loadPartFile (group) {
  const base = PREFIX ? `${PREFIX}-` : ''
  const candidates = [
    `${base}${group}-${VIEW}.png`,
    `${base}${group}.png`,
    `${group}-${VIEW}.png`,
    `${group}.png`,
    `template-${group}.png`
  ]
  for (const f of candidates) {
    const p = path.join(DIR, f)
    if (fs.existsSync(p)) return { img: decodePng(fs.readFileSync(p)), file: p }
  }
  throw new Error(`找不到 ${group} 的图；试过: ${candidates.map(f => path.join(DIR, f)).join(', ')}`)
}

function writePart (group, src, label) {
  const img = stripMagenta(src)
  let part
  try {
    part = processImage(img, 0.06)
  } catch (e) {
    throw new Error(`[${group}] ${label} 处理失败：${e.message}（是不是这一格是空的？）`)
  }
  const out = path.join(partsDir, `${NAME}-${group}-${VIEW}.png`)
  fs.writeFileSync(out, encodePng(part.width, part.height, part.data))
  console.log(`  [${group}] ${part.width}x${part.height} → ${path.relative(process.cwd(), out)}`)
}

if (SHEET) {
  const { img, cw, ch } = loadSheet()
  for (let i = 0; i < GROUP_ORDER.length; i++) {
    const group = GROUP_ORDER[i]
    const col = i % COLS, row = (i / COLS) | 0
    const cell = cropImage(img, col * cw, row * ch, (col + 1) * cw - 1, (row + 1) * ch - 1)
    writePart(group, cell, `sheet cell ${col},${row}`)
  }
} else {
  for (const group of GROUP_ORDER) {
    const { img, file } = loadPartFile(group)
    console.log(`  [${group}] 读 ${path.relative(process.cwd(), file)}`)
    writePart(group, img, file)
  }
}

const buildArgs = [
  'tools/ai-skin-parts.mjs', '--char', CHAR, '--name', NAME, '--views', VIEW, '--source', 'custom'
]
if (VIEW === 'side' && POSE !== 'bind') {
  buildArgs.push('--pose', POSE, '--pose-frame', String(POSE_FRAME), '--pose-groups', POSE_GROUPS)
}
if (HEAD_SCALE !== 1) buildArgs.push('--head-scale', String(HEAD_SCALE))

console.log('\n构建命令:')
console.log('  node ' + buildArgs.join(' '))

if (NO_BUILD) {
  console.log('\n--no-build：部件已写好，未构建角色。')
} else {
  execFileSync(process.execPath, buildArgs, { stdio: 'inherit' })
  console.log(`\n完成：http://127.0.0.1:8899/web/index.html?view=${VIEW}&char=${NAME}&clip=Walk&frame=0&play=0&bones=0`)
}
