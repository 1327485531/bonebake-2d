// 软件光栅化参考渲染器：不依赖 WebGL，用 z-buffer 正确遮挡，
// 用来验证 convert.mjs + 运行时数学是否正确（浏览器渲染出问题时的"标准答案"）。
// 用法: node tools/render-ref.mjs <数据目录> <char> <clip> <frame> <out.png> [--bones]
//       clip 写 bind 时渲染绑定姿态（不套动画），可用于生成 AI 重绘参考图。
//       --group head|torso|arm_l|arm_r|leg_l|leg_r  只渲染某个身体块（AI 分块参考图）
//       --bg RRGGBB                                背景色（默认 181b22）
import fs from 'node:fs'
import zlib from 'node:zlib'
import { splitMeshGroups, rebalanceNeck } from './ai-image.mjs'

const rawArgs = process.argv.slice(2)
const [dataDir, charName, clipName, frameStr, outPng] = rawArgs
const frame = Number(frameStr)
const drawBones = rawArgs.includes('--bones')
const arg = (name, def) => { const i = rawArgs.indexOf('--' + name); return i === -1 ? def : rawArgs[i + 1] }
const groupName = arg('group', null)
const bgHex = arg('bg', '181b22').replace('#', '')
const bgRGB = [parseInt(bgHex.slice(0, 2), 16), parseInt(bgHex.slice(2, 4), 16), parseInt(bgHex.slice(4, 6), 16)]

const chars = JSON.parse(fs.readFileSync(`${dataDir}/characters.json`, 'utf8'))
const anims = JSON.parse(fs.readFileSync(`${dataDir}/anim.json`, 'utf8'))
const C = chars.characters[charName]
const bindPose = clipName === 'bind'
const clip = bindPose ? null : anims.clips[clipName]
if (!bindPose && !clip) { console.error('没有动画', clipName); process.exit(1) }

const aff = (x, y, r) => { const c = Math.cos(r), s = Math.sin(r); return [c, s, -s, c, x, y] }
const mul = (A, B) => [
  A[0] * B[0] + A[2] * B[1], A[1] * B[0] + A[3] * B[1],
  A[0] * B[2] + A[2] * B[3], A[1] * B[2] + A[3] * B[3],
  A[0] * B[4] + A[2] * B[5] + A[4], A[1] * B[4] + A[3] * B[5] + A[5]
]
const inv = (M) => {
  const det = M[0] * M[3] - M[1] * M[2]; const id = 1 / det
  const a = M[3] * id, b = -M[1] * id, c = -M[2] * id, d = M[0] * id
  return [a, b, c, d, -(a * M[4] + c * M[5]), -(b * M[4] + d * M[5])]
}

// 绑定骨架
const n = C.bones.length
const bg = [], bi = []
for (let i = 0; i < n; i++) {
  const b = C.bones[i]
  const L = aff(b.x, b.y, b.rot)
  bg[i] = b.parent < 0 ? L : mul(bg[b.parent], L)
  bi[i] = inv(bg[i])
}
// 姿态
const g = []
const depth = new Float32Array(n)
for (let i = 0; i < n; i++) {
  const t = bindPose ? null : clip.tracks[C.bones[i].name]
  let lx, ly, rot
  if (t) { const o = frame * 4; lx = t[o] * C.bones[i].len; ly = t[o + 1] * C.bones[i].len; rot = t[o + 2]; depth[i] = t[o + 3] } else { lx = C.bones[i].x; ly = C.bones[i].y; rot = C.bones[i].rot }
  const L = aff(lx, ly, rot)
  g[i] = C.bones[i].parent < 0 ? L : mul(g[C.bones[i].parent], L)
}
// 蒙皮每个顶点
const verts = C.mesh.verts, si = C.mesh.skinIndices, sw = C.mesh.skinWeights
const nv = verts.length / 2
const sk = new Float32Array(nv * 2)
for (let v = 0; v < nv; v++) {
  const bx = verts[v * 2], by = verts[v * 2 + 1]
  let x = 0, y = 0
  for (let k = 0; k < 4; k++) {
    const w = sw[v * 4 + k]; if (w <= 0) continue
    const b = si[v * 4 + k]; const M = mul(g[b], bi[b])
    x += w * (M[0] * bx + M[2] * by + M[4])
    y += w * (M[1] * bx + M[3] * by + M[5])
  }
  sk[v * 2] = x; sk[v * 2 + 1] = y
}

// 身体块（可选）
let groups = null
let groupTris = null
if (groupName) {
  groups = splitMeshGroups(C).groups
  rebalanceNeck(groups, C)
  const gg = groups.find(g => g.name === groupName)
  if (!gg) { console.error('这个角色没有身体块', groupName, '可用:', groups.map(g => g.name).join(',')); process.exit(1) }
  groupTris = gg.tris
}

// 屏幕变换（身体块用方形画布，给 AI 更清楚的局部参考）
let mnx = 1e9, mny = 1e9, mxx = -1e9, mxy = -1e9
const boundsVerts = groupTris ? [...new Set(groupTris.flatMap(t => [t.a, t.b, t.c]))] : null
if (boundsVerts) {
  for (const v of boundsVerts) {
    mnx = Math.min(mnx, sk[v * 2]); mxx = Math.max(mxx, sk[v * 2])
    mny = Math.min(mny, sk[v * 2 + 1]); mxy = Math.max(mxy, sk[v * 2 + 1])
  }
} else {
  for (let v = 0; v < nv; v++) {
    mnx = Math.min(mnx, sk[v * 2]); mxx = Math.max(mxx, sk[v * 2])
    mny = Math.min(mny, sk[v * 2 + 1]); mxy = Math.max(mxy, sk[v * 2 + 1])
  }
}
const W = groupTris ? 768 : 620, H = groupTris ? 768 : 760
const scale = Math.min(W / ((mxx - mnx) * 1.2), H / ((mxy - mny) * 1.2))
const cx = (mnx + mxx) / 2, cy = (mny + mxy) / 2
const toX = (x) => (x - cx) * scale + W / 2
const toY = (y) => H / 2 - (y - cy) * scale

const color = new Uint8Array(W * H * 3)
const zbuf = new Float32Array(W * H).fill(-1e9) // 越大越近
const put = (px, py, z, r, g2, b) => {
  if (px < 0 || py < 0 || px >= W || py >= H) return
  const o = py * W + px
  if (z <= zbuf[o]) return
  zbuf[o] = z
  color[o * 3] = r; color[o * 3 + 1] = g2; color[o * 3 + 2] = b
}

// 三角面
let drawn = 0
const drawTris = []
if (groupTris) {
  for (const tr of groupTris) drawTris.push({ a: tr.a, b: tr.b, c: tr.c, offset: tr.offset })
} else {
  for (const part of C.mesh.parts) {
    const offs = part.depthOffsets || []
    for (let t = 0; t < part.indices.length; t += 3) {
      drawTris.push({ a: part.indices[t], b: part.indices[t + 1], c: part.indices[t + 2], offset: offs[t / 3] || 0 })
    }
  }
}
for (const { a: ia, b: ib, c: ic, offset } of drawTris) {
  // 三角面深度 = 骨骼深度加权 + 静止偏移（和运行时一致的排序键）
  const acc = new Map()
  for (const v of [ia, ib, ic]) for (let k = 0; k < 4; k++) {
    const w = sw[v * 4 + k]; if (w <= 0) continue
    const b = si[v * 4 + k]; acc.set(b, (acc.get(b) || 0) + w)
  }
  let tot = 0; for (const w of acc.values()) tot += w
  let d = 0; for (const [b, w] of acc) d += (w / tot) * depth[b]
  d += offset

  const x0 = toX(sk[ia * 2]), y0 = toY(sk[ia * 2 + 1])
  const x1 = toX(sk[ib * 2]), y1 = toY(sk[ib * 2 + 1])
  const x2 = toX(sk[ic * 2]), y2 = toY(sk[ic * 2 + 1])
  const area = (x1 - x0) * (y2 - y0) - (x2 - x0) * (y1 - y0)
  if (Math.abs(area) < 1e-9) continue
  // 法线（屏幕空间）用于简单明暗
  const shade = 0.55 + 0.45 * Math.abs(Math.sin(area * 0.02))
  const r = Math.round(226 * shade), g2 = Math.round(150 * shade), b = Math.round(90 * shade)
  const minx = Math.max(0, Math.floor(Math.min(x0, x1, x2))), maxx = Math.min(W - 1, Math.ceil(Math.max(x0, x1, x2)))
  const miny = Math.max(0, Math.floor(Math.min(y0, y1, y2))), maxy = Math.min(H - 1, Math.ceil(Math.max(y0, y1, y2)))
  for (let py = miny; py <= maxy; py++) {
    for (let px = minx; px <= maxx; px++) {
      const w0 = ((x1 - px) * (y2 - py) - (x2 - px) * (y1 - py)) / area
      const w1 = ((x2 - px) * (y0 - py) - (x0 - px) * (y2 - py)) / area
      const w2 = 1 - w0 - w1
      if (w0 < 0 || w1 < 0 || w2 < 0) continue
      put(px, py, d, r, g2, b)
    }
  }
  drawn++
}
// 骨架
if (drawBones) {
  for (let i = 0; i < n; i++) {
    const p = C.bones[i].parent
    if (p < 0) continue
    const x0 = toX(g[i][4]), y0 = toY(g[i][5]), x1 = toX(g[p][4]), y1 = toY(g[p][5])
    const steps = Math.ceil(Math.hypot(x1 - x0, y1 - y0)) + 1
    for (let s = 0; s <= steps; s++) {
      const px = Math.round(x0 + (x1 - x0) * s / steps), py = Math.round(y0 + (y1 - y0) * s / steps)
      for (let dx = -1; dx <= 1; dx++) for (let dy = -1; dy <= 1; dy++) put(px + dx, py + dy, 1e9, 60, 150, 255)
    }
  }
}

// 背景
for (let i = 0; i < W * H; i++) if (zbuf[i] < -1e8) { color[i * 3] = bgRGB[0]; color[i * 3 + 1] = bgRGB[1]; color[i * 3 + 2] = bgRGB[2] }

// 写 PNG
function crc32 (buf) {
  let c, crc = 0xffffffff
  for (let i = 0; i < buf.length; i++) {
    c = (crc ^ buf[i]) & 0xff
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1
    crc = (crc >>> 8) ^ c
  }
  return (crc ^ 0xffffffff) >>> 0
}
function chunk (type, data) {
  const len = Buffer.alloc(4); len.writeUInt32BE(data.length)
  const td = Buffer.concat([Buffer.from(type, 'ascii'), data])
  const crc = Buffer.alloc(4); crc.writeUInt32BE(crc32(td))
  return Buffer.concat([len, td, crc])
}
const raw = Buffer.alloc((W * 3 + 1) * H)
for (let y = 0; y < H; y++) {
  raw[y * (W * 3 + 1)] = 0
  Buffer.from(color.buffer, y * W * 3, W * 3).copy(raw, y * (W * 3 + 1) + 1)
}
const ihdr = Buffer.alloc(13)
ihdr.writeUInt32BE(W, 0); ihdr.writeUInt32BE(H, 4)
ihdr[8] = 8; ihdr[9] = 2; ihdr[10] = 0; ihdr[11] = 0; ihdr[12] = 0
const png = Buffer.concat([
  Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]),
  chunk('IHDR', ihdr),
  chunk('IDAT', zlib.deflateSync(raw)),
  chunk('IEND', Buffer.alloc(0))
])
fs.writeFileSync(outPng, png)
console.log(`${charName} / ${clipName}${groupName ? ' / ' + groupName : ''} / frame ${frame}: 画出 ${drawn} 个三角面 -> ${outPng}`)
console.log(`  蒙皮后包围盒 x ${mnx.toFixed(2)}..${mxx.toFixed(2)}  y ${mny.toFixed(2)}..${mxy.toFixed(2)}`)