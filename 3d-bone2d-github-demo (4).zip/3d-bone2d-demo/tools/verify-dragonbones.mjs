// 用官方 DragonBones 运行时验证导出结果。
//
// 关键点：不能只对比"JSON 里的数字"——那只能证明写进去的和读出来的一样，
// 证明不了龙骨**渲染**出来是对的。这里做四层验证：
//   ① 绑定姿态：解析后的骨骼 x/y/rotation 与 M2D 源（缩放、y 翻转、居中后）逐骨对比
//   ② 动画关键帧：稀疏时间轴的键值与 M2D 轨道一致、duration 总和 = 动画帧数
//   ③ 运行时求值：官方 Armature 真正 play 每个动画，逐帧对比每根骨的全局矩阵
//   ④ 蒙皮顶点：用官方解析出的 mesh.weights/bonePose 和官方骨骼矩阵算顶点，
//      与 M2D 的 LBS 结果逐顶点对比（这一层能抓住"顶点空间/坐标系"错误）
// 另外检查 textureAtlas（图片在不在、尺寸对不对、mesh path 能不能对上）。
//
// 导出时做了米 → 像素（默认 300px/m）和整体居中；校验从 aabb 反推该变换，误差按像素给（默认 2px）。
//
// 用法:
//   node tools/verify-dragonbones.mjs --db out/side/dragonbones/male.json --data out/side --char male
//   node tools/verify-dragonbones.mjs --db ... --clip Walk --max-error 2
import fs from 'node:fs'
import path from 'node:path'
import { createRequire } from 'node:module'
import { pngSize } from './export-dragonbones.mjs'

const require = createRequire(import.meta.url)
const argv = process.argv.slice(2)
const opt = (n, d) => { const i = argv.indexOf('--' + n); return i === -1 ? d : argv[i + 1] }

const dbFile = path.resolve(opt('db', 'out/side/dragonbones/male.json'))
const dataDir = path.resolve(opt('data', 'out/side'))
const runtimePath = path.resolve(opt('runtime', 'tools/vendor/dragonBones-core.js'))
const onlyClip = opt('clip', null)
const threshold = Number(opt('max-error', '2'))

if (!fs.existsSync(runtimePath)) {
  console.error('找不到 DragonBones 运行时:', runtimePath)
  process.exit(1)
}
const DB = require(runtimePath)

const dbJson = JSON.parse(fs.readFileSync(dbFile, 'utf8'))
const m2d = JSON.parse(fs.readFileSync(path.join(dataDir, 'characters.json'), 'utf8'))
// AI 皮肤角色（可选）
const aiChars = path.join(dataDir, 'characters-ai.json')
if (fs.existsSync(aiChars)) {
  const j = JSON.parse(fs.readFileSync(aiChars, 'utf8'))
  if (j.characters) Object.assign(m2d.characters, j.characters)
}
const animData = JSON.parse(fs.readFileSync(path.join(dataDir, 'anim.json'), 'utf8'))
const charName = opt('char', dbJson.armature && dbJson.armature.length === 1 ? dbJson.armature[0].name : 'male')
const charDef = m2d.characters[charName]
if (!charDef) { console.error('M2D 里没有角色', charName); process.exit(1) }

// 导出器把 M2D 网格按 300px/m 缩放并居中，写进 aabb。这里用 aabb 与源网格反推
// 实际 scale/offset（不依赖自定义字段，Pro/LoongBones 也不会读到额外元数据）。
let scale = 1
let offset = [0, 0]
const aabb = dbJson.armature && dbJson.armature[0] ? dbJson.armature[0].aabb : null
if (aabb && aabb.width > 0 && aabb.height > 0) {
  let mnx = Infinity, mny = Infinity, mxx = -Infinity, mxy = -Infinity
  for (let i = 0; i < charDef.mesh.verts.length / 2; i++) {
    const x = charDef.mesh.verts[i * 2]
    const y = -charDef.mesh.verts[i * 2 + 1]
    if (x < mnx) mnx = x
    if (x > mxx) mxx = x
    if (y < mny) mny = y
    if (y > mxy) mxy = y
  }
  const sw = mxx - mnx, sh = mxy - mny
  if (sw > 0 && sh > 0) {
    const sx = aabb.width / sw, sy = aabb.height / sh
    scale = (sx + sy) / 2
    const cx = (mnx + mxx) / 2, cy = (mny + mxy) / 2
    offset = [
      aabb.x + aabb.width / 2 - cx * scale,
      aabb.y + aabb.height / 2 - cy * scale
    ]
  }
}
const keyTol = { px: 0.25, deg: 0.05 }

console.log(`验证 ${path.basename(dbFile)}  /  角色 ${charName}`)
console.log(`M2D 数据 ${dataDir}`)
console.log(`米→像素 ${scale}  /  居中偏移 [${offset[0]}, ${offset[1]}]  /  抽帧容差 ${keyTol.px}px, ${keyTol.deg}°`)

// ---------------- 1. 官方解析器读入 ----------------
const parser = new DB.ObjectDataParser()
const data = parser.parseDragonBonesData(dbJson)
if (!data) { console.error('官方解析器读不进去'); process.exit(1) }
const armData = data.getArmature(charName)
if (!armData) { console.error('解析后找不到骨架', charName); process.exit(1) }

let FAIL = 0
const ok = (cond, msg) => { if (!cond) { FAIL++; console.log('   ✘ ' + msg) } return cond }
const fmt = (v) => v.toExponential(2)
const RAD = 180 / Math.PI
const normDeg = (v) => ((v + 180) % 360 + 360) % 360 - 180

// ---------------- 数学工具 ----------------
const aff = (x, y, r) => { const c = Math.cos(r), s = Math.sin(r); return [c, s, -s, c, x, y] }
const mul = (A, B) => [
  A[0] * B[0] + A[2] * B[1], A[1] * B[0] + A[3] * B[1],
  A[0] * B[2] + A[2] * B[3], A[1] * B[2] + A[3] * B[3],
  A[0] * B[4] + A[2] * B[5] + A[4], A[1] * B[4] + A[3] * B[5] + A[5]
]
const inv = (M) => {
  const det = M[0] * M[3] - M[1] * M[2], id = 1 / det
  const a = M[3] * id, b = -M[1] * id, c = -M[2] * id, d = M[0] * id
  return [a, b, c, d, -(a * M[4] + c * M[5]), -(b * M[4] + d * M[5])]
}
// M2D 全局矩阵（y-up，米）→ 龙骨全局矩阵（y-down，像素，居中）
const toDB = (M) => [
  M[0], -M[1], -M[2], M[3],
  M[4] * scale + offset[0], -M[5] * scale + offset[1]
]

// ---------------- 2. 绑定姿态 ----------------
console.log(`\n① 绑定姿态（官方解析 ${Object.keys(armData.bones).length} 骨）`)
let bindErr = 0, bindWorst = ''
for (const pb of Object.values(armData.bones)) {
  const src = charDef.bones.find(b => b.name === pb.name)
  if (!src) continue
  const isRoot = src.parent < 0
  const ex = src.x * scale + (isRoot ? offset[0] : 0)
  const ey = -src.y * scale + (isRoot ? offset[1] : 0)
  const t = pb.transform
  const da = Math.atan2(Math.sin(t.rotation + src.rot), Math.cos(t.rotation + src.rot))
  const e = Math.max(Math.abs(t.x - ex), Math.abs(t.y - ey), Math.abs(da))
  if (e > bindErr) { bindErr = e; bindWorst = pb.name }
}
ok(bindErr < 1e-2, `绑定姿态最大误差 ${fmt(bindErr)}（${bindWorst}）`)
console.log(`   最大误差 ${fmt(bindErr)}（${bindWorst}）  ${bindErr < 1e-2 ? '✔' : '✘'}`)

// ---------------- 3. 动画关键帧 ----------------
const clipNames = onlyClip ? [onlyClip] : Object.keys(animData.clips)
let animErr = 0, animWorst = '', animKeys = 0
console.log('\n② 动画关键帧（稀疏时间轴）')

function expectedDelta (b, tr, f) {
  const o = f * 4
  const isRoot = b.parent < 0
  const ex = tr[o] * b.len * scale + (isRoot ? offset[0] : 0) - (b.x * scale + (isRoot ? offset[0] : 0))
  const ey = -tr[o + 1] * b.len * scale + (isRoot ? offset[1] : 0) - (-b.y * scale + (isRoot ? offset[1] : 0))
  const er = (-tr[o + 2] + b.rot) * RAD
  return [ex, ey, er]
}
function maxDelta (b, tr) {
  let mm = 0, mt = 0
  for (let f = 0; f < tr.length / 4; f++) {
    const [x, y, r] = expectedDelta(b, tr, f)
    mm = Math.max(mm, Math.abs(x), Math.abs(y))
    mt = Math.max(mt, Math.abs(r))
  }
  return [mm, mt]
}

for (const clipName of clipNames) {
  const clip = animData.clips[clipName]
  const dbAnim = dbJson.armature[0].animation.find(a => a.name === clipName)
  if (!clip || !dbAnim) { ok(false, `缺少动画 ${clipName}`); continue }
  const tracks = clip.charTracks && clip.charTracks[charName] ? clip.charTracks[charName] : clip.tracks
  const F = clip.frames
  const byName = new Map((dbAnim.bone || []).map(t => [t.name, t]))
  for (const b of charDef.bones) {
    const tr = tracks[b.name]
    if (!tr) continue
    const tl = byName.get(b.name)
    const tf = tl && tl.translateFrame ? tl.translateFrame : null
    const rf = tl && tl.rotateFrame ? tl.rotateFrame : null
    const [maxMove, maxTurn] = maxDelta(b, tr)
    if (!tf && maxMove > keyTol.px + 0.01) ok(false, `${clipName}/${b.name} 缺 translateFrame（最大 ${maxMove.toFixed(2)}px）`)
    if (!rf && maxTurn > keyTol.deg + 0.01) ok(false, `${clipName}/${b.name} 缺 rotateFrame（最大 ${maxTurn.toFixed(2)}°）`)

    for (const [frames, kind] of [[tf, 'translateFrame'], [rf, 'rotateFrame']]) {
      if (!frames) continue
      let f = 0
      for (const kf of frames) {
        if (f >= F) { ok(false, `${clipName}/${b.name} ${kind} 帧数超出 ${F}`); break }
        const [ex, ey, er] = expectedDelta(b, tr, f)
        if (kind === 'translateFrame') {
          const e = Math.max(Math.abs((kf.x || 0) - ex), Math.abs((kf.y || 0) - ey))
          if (e > animErr) { animErr = e; animWorst = `${clipName}/${b.name}@帧${f}` }
        } else {
          const e = Math.abs(normDeg((kf.rotate || 0) - er))
          if (e > animErr) { animErr = e; animWorst = `${clipName}/${b.name}@帧${f}` }
        }
        // 关键帧 duration 不能跨过动画结尾
        if (kf.duration === undefined || kf.duration <= 0) ok(false, `${clipName}/${b.name} ${kind}@帧${f} duration 非法`)
        f += kf.duration || 0
        animKeys++
      }
      ok(f === F, `${clipName}/${b.name} ${kind} duration 总和 ${f} != ${F}`)
    }
  }
}
ok(animErr < 0.05, `动画关键帧最大误差 ${fmt(animErr)}（${animWorst}）`)
console.log(`   ${animKeys} 个关键帧，最大误差 ${fmt(animErr)}（${animWorst}）  ${animErr < 0.05 ? '✔' : '✘'}`)

// ---------------- 4. 官方运行时求值 ----------------
function makeArmature () {
  const proxy = {
    dbInit () {}, dbUpdate () {}, dbClear () {}, dispatchDBEvent () {},
    hasDBEventListener () { return false }
  }
  const info = console.info
  console.info = () => {}
  const dragonBones = new DB.DragonBones({ dispatchDBEvent () {} })
  console.info = info
  const arm = DB.BaseObject.borrowObject(DB.Armature)
  arm.init(armData, proxy, null, dragonBones)
  for (const bd of armData.sortedBones) {
    const bone = DB.BaseObject.borrowObject(bd.type === 0 ? DB.Bone : DB.Surface)
    bone.init(bd, arm)
  }
  return arm
}

function m2dBind (def) {
  const g = [], gi = []
  for (let i = 0; i < def.bones.length; i++) {
    const b = def.bones[i]
    const L = aff(b.x, b.y, b.rot)
    g[i] = b.parent < 0 ? L : mul(g[b.parent], L)
    gi[i] = inv(g[i])
  }
  return gi
}
function m2dGlobals (def, tracks, f) {
  const g = []
  for (let i = 0; i < def.bones.length; i++) {
    const b = def.bones[i]
    const tr = tracks[b.name]
    let x, y, r
    if (tr) { const o = f * 4; x = tr[o] * b.len; y = tr[o + 1] * b.len; r = tr[o + 2] } else { x = b.x; y = b.y; r = b.rot }
    const L = aff(x, y, r)
    g[i] = b.parent < 0 ? L : mul(g[b.parent], L)
  }
  return g
}
/** M2D 每个 part 用到的源顶点（升序），与导出脚本保持同一顺序 */
function partVertexOrder (part) {
  const s = new Set()
  for (let i = 0; i < part.indices.length; i++) s.add(part.indices[i])
  return [...s].sort((a, b) => a - b)
}
function m2dSkinned (def, globals, bindInv, order) {
  const out = new Float64Array(order.length * 2)
  for (let i = 0; i < order.length; i++) {
    const v = order[i]
    const bx = def.mesh.verts[v * 2], by = def.mesh.verts[v * 2 + 1]
    let X = 0, Y = 0
    for (let k = 0; k < 4; k++) {
      const w = def.mesh.skinWeights[v * 4 + k]
      if (w <= 0) continue
      const b = def.mesh.skinIndices[v * 4 + k]
      const M = mul(globals[b], bindInv[b])
      X += w * (M[0] * bx + M[2] * by + M[4])
      Y += w * (M[1] * bx + M[3] * by + M[5])
    }
    out[i * 2] = X * scale + offset[0]
    out[i * 2 + 1] = -Y * scale + offset[1]
  }
  return out
}
/** 用官方解析出的权重/bonePose + 官方骨骼矩阵算蒙皮顶点 */
function dbMeshVerts (arm) {
  const out = []
  for (const slotData of armData.sortedSlots) {
    const displays = armData.defaultSkin.getDisplays(slotData.name)
    if (!displays || !displays[0] || !displays[0].geometry) { out.push(null); continue }
    const g = displays[0].geometry
    const w = g.weight
    if (!w) { out.push(null); continue }
    const ia = g.data.intArray, fa = g.data.floatArray
    const nv = ia[g.offset]
    const bones = w.bones.map(bd => arm.getBone(bd.name))
    const arr = new Float64Array(nv * 2)
    let iB = w.offset + 2 + w.bones.length
    let iV = ia[w.offset + 1]
    for (let v = 0; v < nv; v++) {
      const cnt = ia[iB++]
      let X = 0, Y = 0
      for (let j = 0; j < cnt; j++) {
        const bi = ia[iB++]
        const wt = fa[iV++]
        const xL = fa[iV++], yL = fa[iV++]
        const M = bones[bi].globalTransformMatrix
        X += wt * (M.a * xL + M.c * yL + M.tx)
        Y += wt * (M.b * xL + M.d * yL + M.ty)
      }
      arr[v * 2] = X; arr[v * 2 + 1] = Y
    }
    out.push(arr)
  }
  return out
}

const bindInv = m2dBind(charDef)
const partOrders = charDef.mesh.parts.map(partVertexOrder)
const fps = animData.fps || 30

console.log('\n③ 官方运行时求值（Armature 逐帧播放，对比每根骨全局矩阵）')
let boneErr = 0, boneWorst = '', bonePoints = 0
let vertErr = 0, vertWorst = '', vertPoints = 0
const clipRows = []

for (const clipName of clipNames) {
  const clip = animData.clips[clipName]
  const dbAnim = dbJson.armature[0].animation.find(a => a.name === clipName)
  if (!clip || !dbAnim) continue
  const tracks = clip.charTracks && clip.charTracks[charName] ? clip.charTracks[charName] : clip.tracks
  const F = clip.frames
  const arm = makeArmature()
  arm.animation.play(clipName, 0)

  // 逐帧检查所有骨；顶点按帧采样（首尾 + 均匀 10 帧）
  const sampleFrames = new Set([0, F - 1])
  for (let s = 1; s < 10; s++) sampleFrames.add(Math.floor((F - 1) * s / 10))

  let clipBoneErr = 0, clipVertErr = 0
  for (let f = 0; f < F; f++) {
    // +1e-6 避开帧边界的浮点误差：龙骨在正好整帧时可能还停在上一个关键帧
    arm.advanceTime((f === 0 ? 0 : 1 / fps) + 1e-6)
    const g = m2dGlobals(charDef, tracks, f)
    for (let i = 0; i < charDef.bones.length; i++) {
      const bone = arm.getBone(charDef.bones[i].name)
      if (!bone) { ok(false, `官方骨架缺少骨 ${charDef.bones[i].name}`); continue }
      const M = bone.globalTransformMatrix
      const E = toDB(g[i])
      const e = Math.max(
        Math.abs(M.a - E[0]), Math.abs(M.b - E[1]), Math.abs(M.c - E[2]),
        Math.abs(M.d - E[3]), Math.abs(M.tx - E[4]), Math.abs(M.ty - E[5])
      )
      if (e > clipBoneErr) clipBoneErr = e
      if (e > boneErr) { boneErr = e; boneWorst = `${clipName}/${charDef.bones[i].name}@帧${f}` }
      bonePoints++
    }

    if (sampleFrames.has(f)) {
      const expVerts = m2dSkinned(charDef, g, bindInv, partOrders[0]) // 单 part；多 part 见下
      const gotVerts = dbMeshVerts(arm)
      if (charDef.mesh.parts.length === 1) {
        const got = gotVerts[0]
        if (!got || got.length !== expVerts.length) {
          ok(false, `${clipName} 帧${f} 顶点数不一致（${got ? got.length / 2 : '?'} vs ${expVerts.length / 2}）`)
        } else {
          for (let i = 0; i < expVerts.length; i++) {
            const e = Math.abs(expVerts[i] - got[i])
            if (e > clipVertErr) clipVertErr = e
            if (e > vertErr) { vertErr = e; vertWorst = `${clipName}/帧${f}/v${i >> 1}.${i & 1}` }
            vertPoints++
          }
        }
      }
    }
  }
  clipRows.push({ clipName, F, boneErr: clipBoneErr, vertErr: clipVertErr })
}

ok(boneErr < threshold, `骨骼全局矩阵最大误差 ${fmt(boneErr)}px（${boneWorst}）`)
ok(vertErr < threshold, `蒙皮顶点最大误差 ${fmt(vertErr)}px（${vertWorst}）`)
for (const r of clipRows) {
  console.log(`   ${r.clipName.padEnd(14)} ${String(r.F).padStart(3)} 帧   骨 ${fmt(r.boneErr)}px   顶点 ${fmt(r.vertErr)}px`)
}
console.log(`   共比对 ${bonePoints} 个(骨,帧) 矩阵、${vertPoints} 个顶点分量`)
console.log(`   骨骼最大误差 ${fmt(boneErr)}px（${boneWorst}）  ${boneErr < threshold ? '✔' : '✘'}`)
console.log(`   顶点最大误差 ${fmt(vertErr)}px（${vertWorst}）  ${vertErr < threshold ? '✔' : '✘'}`)

// ---------------- 5. 网格 / 权重完整性 ----------------
console.log('\n④ 网格与权重')
ok(armData.sortedSlots.length === charDef.mesh.parts.length,
  `slot 数 ${armData.sortedSlots.length} != M2D part 数 ${charDef.mesh.parts.length}`)
let totalTri = 0
for (let i = 0; i < armData.sortedSlots.length; i++) {
  const slotData = armData.sortedSlots[i]
  const dd = armData.defaultSkin.getDisplays(slotData.name)[0]
  const g = dd.geometry
  const nv = g.data.intArray[g.offset]
  const nt = g.data.intArray[g.offset + 1]
  const order = partOrders[i]
  totalTri += nt
  ok(nv === order.length, `${slotData.name} 顶点数 ${nv} != 源 ${order.length}`)
  ok(g.weight && g.weight.count > 0, `${slotData.name} 没有蒙皮权重`)
  // 每个顶点权重和 ≈ 1
  const w = g.weight
  let worstSum = 0
  let iB = w.offset + 2 + w.bones.length
  let iV = g.data.intArray[w.offset + 1]
  for (let v = 0; v < nv; v++) {
    const cnt = g.data.intArray[iB++]
    let sum = 0
    for (let j = 0; j < cnt; j++) { iB++; sum += g.data.floatArray[iV++]; iV += 2 }
    worstSum = Math.max(worstSum, Math.abs(sum - 1))
  }
  ok(worstSum < 2e-3, `${slotData.name} 权重和最大偏差 ${fmt(worstSum)}`)
  console.log(`   ${slotData.name}: ${nv} 顶点 / ${nt} 三角 / ${w.bones.length} 根骨参与蒙皮 / 权重和偏差 ${fmt(worstSum)}  ✔`)
}
const srcTri = charDef.mesh.parts.reduce((s, p) => s + p.indices.length / 3, 0)
ok(totalTri === srcTri, `三角面总数 ${totalTri} != 源 ${srcTri}`)

// ---------------- 6. 贴图集 ----------------
console.log('\n⑤ 贴图集')
const atlases = dbJson.textureAtlas || []
ok(atlases.length > 0, '没有 textureAtlas')
let atlasOk = 0
for (const a of atlases) {
  const imgAbs = path.resolve(path.dirname(dbFile), a.imagePath)
  if (!ok(fs.existsSync(imgAbs), `贴图不存在: ${a.imagePath}`)) continue
  const size = pngSize(fs.readFileSync(imgAbs))
  const subs = a.SubTexture || []
  const dimOk = a.width === size.width && a.height === size.height
  ok(dimOk, `${a.name} 尺寸 ${a.width}x${a.height} != PNG ${size.width}x${size.height}`)
  ok(subs.length > 0, `${a.name} 没有 SubTexture`)
  let subOk = true
  for (const sub of subs) {
    if (!(sub.x === 0 && sub.y === 0 && sub.width === size.width && sub.height === size.height)) subOk = false
  }
  ok(subOk, `${a.name} 有 SubTexture 没覆盖整张图`)
  atlasOk++
  console.log(`   ${a.name}: ${size.width}x${size.height} / ${subs.length} 个 SubTexture  ${path.relative(process.cwd(), imgAbs)}`)
}
// 每个 mesh display 的 path 都能在 atlas 里找到
for (const skinName in (armData.skins || {})) {
  const skin = armData.skins[skinName]
  for (const slotName in skin.displays) {
    for (const dd of skin.displays[slotName]) {
      if (!dd.path) continue
      ok(atlases.some(a => (a.SubTexture || []).some(s => s.name === dd.path)),
        `mesh path "${dd.path}" 在 textureAtlas 里找不到`)
    }
  }
}
console.log(`   ${atlases.length} 个 atlas，${atlasOk} 个通过`)
ok(atlases.length > 0 && atlasOk === atlases.length, '贴图集检查未全部通过')

// ---------------- 总结 ----------------
const allOk = FAIL === 0
console.log(`\n${allOk
  ? '✔ 全部通过：官方运行时解析 + 逐帧求值 + 蒙皮顶点 + 贴图集都一致'
  : `✘ 有 ${FAIL} 项未通过，见上面的 ✘`}`)
console.log('  JSON 可直接放进 DragonBones Pro / LoongBones，或任何支持龙骨 5.5 的运行时（Pixi/Phaser 等）')
process.exit(allOk ? 0 : 1)
