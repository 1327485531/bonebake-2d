// 自动蒙皮：给没有权重的模型算 skinIndices / skinWeights
//
// 移植自 Mesh2Motion 的 solvers/ 流水线，但把"最近骨头 + 边界混合"换成了
// "最近骨段的反距离加权 + 邻接拉普拉斯平滑"，理由：
//   - Mesh2Motion 初算只给每顶点 1 根骨头，靠边界混合过渡，弯关节时容易出现折痕；
//   - 反距离加权天然给出 2~4 个影响，配合平滑，肘/膝弯曲更圆滑，也更适合 GPU 的 4 权重 LBS。
// 保留的关键经验：
//   - root 和叶子骨（*_leaf / *tip）不接收顶点（它们只负责朝向，不该带动网格）；
//   - 骨盆不能抢走低于胯部的顶点（否则大腿根会被躯干拖住，抬腿就撕）；
//   - 末端（手、脚、手指）不做平滑，保持硬朗。
//
// 所有计算都在 3D 世界空间里做 —— 权重与视角无关，这样才能同时给正面/侧面两个 2D 版本用。

const EPS = 1e-9

export const BONE_CATEGORIES = {
  torso: ['spine', 'chest', 'hips', 'pelvis', 'torso', 'abdomen', 'body', 'stomach', 'collar', 'scapula', 'ribcage', 'tail'],
  limb: ['arm', 'upperarm', 'lowerarm', 'forearm', 'elbow', 'wrist', 'shoulder', 'clavicle', 'ankle',
    'thigh', 'calf', 'shin', 'knee', 'leg', 'upleg', 'lowleg', 'neck', 'head', 'humerus', 'nose', 'jaw'],
  extremity: ['hand', 'foot', 'feet', 'toe', 'ball', 'thumb', 'index', 'middle', 'ring', 'pinky',
    'finger', 'eye', 'tongue', 'wing', 'feather', 'leaf', 'ear', 'horn', 'teeth']
}

export function classifyBone (name) {
  const n = name.toLowerCase()
  if (BONE_CATEGORIES.extremity.some(k => n.includes(k))) return 'extremity'
  if (BONE_CATEGORIES.limb.some(k => n.includes(k))) return 'limb'
  if (BONE_CATEGORIES.torso.some(k => n.includes(k))) return 'torso'
  return 'other'
}

/** 点到线段的距离平方 */
function distSqPointSegment (p, a, b) {
  const abx = b[0] - a[0], aby = b[1] - a[1], abz = b[2] - a[2]
  const apx = p[0] - a[0], apy = p[1] - a[1], apz = p[2] - a[2]
  const len2 = abx * abx + aby * aby + abz * abz
  let t = len2 > EPS ? (apx * abx + apy * aby + apz * abz) / len2 : 0
  t = t < 0 ? 0 : t > 1 ? 1 : t
  const dx = apx - abx * t, dy = apy - aby * t, dz = apz - abz * t
  return dx * dx + dy * dy + dz * dz
}

/**
 * 构造每根骨头对应的"骨段"（骨头世界位置 → 首个子骨世界位置）。
 * 没有子骨的骨头用父骨方向外推一段，长度取全骨架骨长的中位数。
 */
export function buildBoneSegments (boneWorld, parentOf, names) {
  const n = boneWorld.length
  const children = Array.from({ length: n }, () => [])
  parentOf.forEach((p, i) => { if (p >= 0) children[p].push(i) })

  let lens = []
  for (let i = 0; i < n; i++) {
    for (const c of children[i]) {
      const dx = boneWorld[c][0] - boneWorld[i][0]
      const dy = boneWorld[c][1] - boneWorld[i][1]
      const dz = boneWorld[c][2] - boneWorld[i][2]
      lens.push(Math.hypot(dx, dy, dz))
    }
  }
  lens = lens.filter(l => l > 1e-5).sort((a, b) => a - b)
  const medianLen = lens.length ? lens[Math.floor(lens.length / 2)] : 0.1

  const segments = []
  for (let i = 0; i < n; i++) {
    const a = boneWorld[i]
    // 优先选非叶子子骨作为骨段末端
    let child = children[i].find(c => !/leaf|tip/i.test(names[c]))
    if (child === undefined) child = children[i][0]
    if (child !== undefined) {
      segments.push([a, boneWorld[child], true])
    } else {
      // 叶子骨：顺着父骨方向外推
      const p = parentOf[i]
      let dir = [0, 1, 0]
      if (p >= 0) {
        const d = [a[0] - boneWorld[p][0], a[1] - boneWorld[p][1], a[2] - boneWorld[p][2]]
        const l = Math.hypot(...d)
        if (l > 1e-6) dir = d.map(v => v / l)
      }
      segments.push([a, [a[0] + dir[0] * medianLen, a[1] + dir[1] * medianLen, a[2] + dir[2] * medianLen], false])
    }
  }
  return segments
}

/** 顶点邻接（按三角形），并把重合位置焊在一起，避免 UV 接缝处不参与平滑 */
function buildAdjacency (positions, indices) {
  const nv = positions.length / 3
  const adj = Array.from({ length: nv }, () => new Set())
  for (let t = 0; t < indices.length; t += 3) {
    const a = indices[t], b = indices[t + 1], c = indices[t + 2]
    adj[a].add(b); adj[a].add(c)
    adj[b].add(a); adj[b].add(c)
    adj[c].add(a); adj[c].add(b)
  }
  // 位置焊接：同一位置的分裂顶点互为邻居
  const map = new Map()
  for (let v = 0; v < nv; v++) {
    const key = `${positions[v * 3].toFixed(5)},${positions[v * 3 + 1].toFixed(5)},${positions[v * 3 + 2].toFixed(5)}`
    if (!map.has(key)) map.set(key, [])
    map.get(key).push(v)
  }
  for (const list of map.values()) {
    if (list.length < 2) continue
    for (const a of list) for (const b of list) if (a !== b) adj[a].add(b)
  }
  return adj
}

/**
 * 主函数
 * @param {object} o
 * @param {number[]} o.positions   顶点世界坐标（扁平，3/顶点）
 * @param {number[]} o.indices     三角面索引（多段拼接）
 * @param {number[][]} o.boneWorld 每根骨头的世界位置
 * @param {number[]} o.parentOf    每根骨头的父骨下标（-1 表示根）
 * @param {string[]} o.names       骨头名
 * @param {number} [o.maxInfluences=4]
 * @param {number} [o.smoothIterations=8]
 */
export function autoSkin ({
  positions, indices, boneWorld, parentOf, names,
  maxInfluences = 4, smoothIterations = 8, falloff = 4
}) {
  const nv = positions.length / 3
  const nb = boneWorld.length
  const segments = buildBoneSegments(boneWorld, parentOf, names)
  const cats = names.map(classifyBone)

  // 不接收顶点的骨头：root（整体位移）和叶子骨（只负责朝向）
  const skip = new Set()
  for (let i = 0; i < nb; i++) {
    const isRoot = parentOf[i] === -1 && /root|armature|master|reference/i.test(names[i])
    const isLeaf = /leaf|tip/i.test(names[i])
    if (isRoot || isLeaf) skip.add(i)
  }
  // 骨盆：不允许抢胯部以下的顶点（否则大腿根被躯干拖住，抬腿会撕开）
  const pelvisIdx = names.findIndex(n => /hips|pelvis/i.test(n))
  const pelvisY = pelvisIdx >= 0 ? boneWorld[pelvisIdx][1] - 0.04 : -Infinity

  // 1) 反距离加权取最近 K 根骨段
  const candIdx = []
  const candW = []
  for (let v = 0; v < nv; v++) {
    const p = [positions[v * 3], positions[v * 3 + 1], positions[v * 3 + 2]]
    const best = []
    for (let b = 0; b < nb; b++) {
      if (skip.has(b)) continue
      if (b === pelvisIdx && p[1] < pelvisY) continue
      const [a, c] = segments[b]
      const d2 = distSqPointSegment(p, a, c)
      best.push([d2, b])
    }
    best.sort((x, y) => x[0] - y[0])
    const k = Math.min(maxInfluences, best.length)
    const idxs = [], ws = []
    let sum = 0
    for (let i = 0; i < k; i++) {
      const d2 = Math.max(best[i][0], 1e-8)
      const w = 1 / Math.pow(d2, falloff / 2)
      idxs.push(best[i][1]); ws.push(w); sum += w
    }
    for (let i = 0; i < k; i++) ws[i] /= sum
    candIdx.push(idxs)
    candW.push(ws)
  }

  // 2) 邻接平滑（拉普拉斯），末端骨不参与
  const adj = buildAdjacency(positions, indices)
  const weightMap = new Array(nv) // Map<boneIdx, weight>
  for (let v = 0; v < nv; v++) {
    const m = new Map()
    candIdx[v].forEach((b, i) => m.set(b, candW[v][i]))
    weightMap[v] = m
  }

  for (let it = 0; it < smoothIterations; it++) {
    const next = new Array(nv)
    for (let v = 0; v < nv; v++) {
      // 末端顶点保持刚性
      const dominant = [...weightMap[v].entries()].sort((a, b) => b[1] - a[1])[0]
      if (dominant && cats[dominant[0]] === 'extremity') { next[v] = weightMap[v]; continue }
      const acc = new Map()
      const self = 0.5
      for (const [b, w] of weightMap[v]) acc.set(b, (acc.get(b) || 0) + w * self)
      const neigh = adj[v]
      const share = neigh.size > 0 ? (1 - self) / neigh.size : 0
      for (const u of neigh) {
        for (const [b, w] of weightMap[u]) acc.set(b, (acc.get(b) || 0) + w * share)
      }
      next[v] = acc
    }
    for (let v = 0; v < nv; v++) weightMap[v] = next[v]
  }

  // 3) 归一化 + 只保留最大的 4 个
  const skinIndices = []
  const skinWeights = []
  for (let v = 0; v < nv; v++) {
    let entries = [...weightMap[v].entries()].filter(e => e[1] > 1e-5)
    if (entries.length === 0) entries = [[0, 1]]
    entries.sort((a, b) => b[1] - a[1])
    entries = entries.slice(0, 4)
    let sum = 0
    for (const e of entries) sum += e[1]
    for (let i = 0; i < 4; i++) {
      const e = entries[i]
      skinIndices.push(e ? e[0] : 0)
      skinWeights.push(e ? +(e[1] / sum).toFixed(4) : 0)
    }
  }
  return { skinIndices, skinWeights, stats: { vertices: nv, bones: nb, skipped: [...skip].map(i => names[i]) } }
}