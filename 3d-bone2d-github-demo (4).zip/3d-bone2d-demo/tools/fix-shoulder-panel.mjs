// 修“右肩皮肤向前移动/被拉伸变形”。
//
// 7.14 削掉了 torso 的 upperarm 权重，但肩皮还带着 clavicle_r 权重；跑步右臂前伸时
// 锁骨跟着转，右后肩 panel 被锁骨带着往前移动，看起来像肩皮被扯变形。
// 这个脚本只把右后肩 panel 的 clavicle_r 权重转给 spine_03，让肩皮留在躯干上；
// upperarm/胸口/脖子不动。
//
// 用法：
//   node tools/fix-shoulder-panel.mjs --data out/side --name ai_ronin_v5
//   node tools/fix-shoulder-panel.mjs --data out/side --name ai_ronin_v5 --frac 1
//   node tools/fix-shoulder-panel.mjs --data out/side --name ai_ronin_v5 --force
//
// 只适合侧视右肩；换视角/角色要重新量 box。
import fs from 'node:fs'
import path from 'node:path'
import { splitMeshGroups, rebalanceNeck } from './ai-image.mjs'

const argv = process.argv.slice(2)
const opt = (n, d) => { const i = argv.indexOf('--' + n); return i === -1 ? d : argv[i + 1] }
const has = (n) => argv.includes('--' + n)

const DATA = opt('data', 'out/side')
const NAME = opt('name', 'ai_ronin_v5')
const FRAC = Number(opt('frac', '1'))
const FORCE = has('force')
const BOTH = has('both')
const [X0, X1, Y0, Y1] = opt('box', '-0.30,-0.02,1.40,1.56').split(',').map(Number)

if (!(FRAC > 0 && FRAC <= 1)) throw new Error('--frac 需要 (0,1]')
if (![X0, X1, Y0, Y1].every(Number.isFinite) || X0 >= X1 || Y0 >= Y1) throw new Error('--box 不合法')

const files = ['characters-ai.json', 'characters.json']
let found = null
for (const f of files) {
  const p = path.join(DATA, f)
  if (!fs.existsSync(p)) continue
  const j = JSON.parse(fs.readFileSync(p, 'utf8'))
  if (j.characters && j.characters[NAME]) { found = { p, j, char: j.characters[NAME], file: f }; break }
}
if (!found) throw new Error(`${DATA} 里没有 ${NAME}`)
const { p: file, j, char } = found

if (char.shoulderPanelFix && char.shoulderPanelFix.version === 2 && !FORCE) {
  console.log(`${NAME} 已经冻结过右后肩 panel（${char.shoulderPanelFix.frac}），跳过。`)
  process.exit(0)
}

const names = char.bones.map(b => b.name)
const cr = names.indexOf('clavicle_r')
const sp = names.indexOf('spine_03')
const ur = names.indexOf('upperarm_r')
if (cr < 0 || sp < 0) throw new Error('没有 clavicle_r / spine_03')
const FREEZE = BOTH ? [cr, ur].filter(i => i >= 0) : [cr]
const neck = names.findIndex(n => /neck|head/i.test(n))
const armBone = /upperarm|lowerarm|forearm|hand|finger|thumb|index|middle|ring|pinky/i

let torso
if (char.ai && Array.isArray(char.ai.groups)) {
  let off = 0
  for (const g of char.ai.groups) {
    if (g.name === 'torso') { torso = Array.from({ length: g.vertices }, (_, i) => off + i); break }
    off += g.vertices
  }
} else {
  const { groups } = splitMeshGroups(char)
  rebalanceNeck(groups, char)
  const t = groups.find(g => g.name === 'torso')
  torso = t ? t.verts : []
}
if (!torso || !torso.length) throw new Error('找不到 torso 顶点')

const mesh = char.mesh
let touched = 0
for (const v of torso) {
  const x = mesh.verts[v * 2], y = mesh.verts[v * 2 + 1]
  if (!(x >= X0 && x <= X1 && y >= Y0 && y <= Y1)) continue

  // 跳过脖子/头主导的顶点
  let best = -1, bw = 0
  for (let k = 0; k < 4; k++) {
    const b = mesh.skinIndices[v * 4 + k], w = mesh.skinWeights[v * 4 + k]
    if (w > bw) { bw = w; best = b }
  }
  if (best === neck || /head|neck/i.test(names[best] || '')) continue

  const m = new Map()
  for (let k = 0; k < 4; k++) {
    const b = mesh.skinIndices[v * 4 + k], w = mesh.skinWeights[v * 4 + k]
    if (w > 0) m.set(b, (m.get(b) || 0) + w)
  }
  let moved = 0
  for (const b of FREEZE) {
    const w = m.get(b) || 0
    if (w <= 0) continue
    const cut = w * FRAC
    m.set(b, w - cut)
    moved += cut
  }
  if (moved <= 1e-6) continue
  m.set(sp, (m.get(sp) || 0) + moved)

  const arr = [...m.entries()].filter(([, w]) => w > 1e-6).sort((a, b) => b[1] - a[1]).slice(0, 4)
  const sum = arr.reduce((s, x) => s + x[1], 0) || 1
  for (let k = 0; k < 4; k++) {
    const e = arr[k]
    mesh.skinIndices[v * 4 + k] = e ? e[0] : 0
    mesh.skinWeights[v * 4 + k] = e ? e[1] / sum : 0
  }
  touched++
}

char.shoulderPanelFix = { version: 2, mode: BOTH ? 'freeze-clavicle+upperarm' : 'freeze-clavicle', frac: FRAC, box: [X0, X1, Y0, Y1], touched }
fs.writeFileSync(file, JSON.stringify(j))
console.log(`✔ ${NAME}: 右后肩 panel ${touched} 个顶点，${Math.round(FRAC * 100)}% ${BOTH ? 'clavicle_r+upperarm_r' : 'clavicle_r'} 权重 → spine_03`)
console.log(`  ${file}；重新导出龙骨后生效。`)
