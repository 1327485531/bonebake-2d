#!/usr/bin/env bash
# 一键烘焙全部演示数据（正/侧两个视角）。
# 前置：仓库根目录下要有 mesh2motion-app/（git clone --depth 1 https://github.com/Mesh2Motion/mesh2motion-app.git）
set -euo pipefail
cd "$(dirname "$0")/.."

M2M=mesh2motion-app/static
[ -d "$M2M" ] || { echo "缺少 $M2M，请先克隆 mesh2motion-app"; exit 1; }

CLIPS=Idle_A,Walk,Jog,Sprint,Jump_air,Sword_Attack,Punch_Jab,Dance_Simple,Roll,Zombie_Walk,Pistol_Shoot,Crouch_Walk

CHARS=(
  male monster swat_male killer_4 doctor_m
  police_male female_8 male_5 police_female hazmat_female
  zombie
)

ARGS=()
for c in "${CHARS[@]}"; do
  ARGS+=(--char "$c=$M2M/models-variation/human/$c.glb")
done
# 没有蒙皮的裸模型：用外部骨架 + 自动蒙皮
ARGS+=(--char "naked=$M2M/models/model-human.glb")
RIG=(--rig "$M2M/rigs/rig-human.glb" --remap)

for VIEW in side front; do
  echo "===== 烘焙 $VIEW ====="
  node tools/convert.mjs --view "$VIEW" --fps 30 \
    --anim "$M2M/animations/human-base-animations.glb" \
    --clips "$CLIPS" "${ARGS[@]}" "${RIG[@]}" \
    --out "out/$VIEW"

  echo "----- 修肩部权重（$VIEW） -----"
  node tools/fix-shoulder-weights.mjs --views "$VIEW"

  echo "----- 导出 DragonBones（$VIEW） -----"
  node tools/export-dragonbones.mjs --data "out/$VIEW" --out "out/$VIEW/dragonbones"
done

echo
echo "完成。起服务： python3 -m http.server 8899 --bind 127.0.0.1"
echo "  M2D 演示：  http://127.0.0.1:8899/web/index.html"
echo "  龙骨实测：  http://127.0.0.1:8899/web/dragonbones.html"
echo "  数值校验：  ./tools/verify-all-dragonbones.sh side"
echo "  AI 皮肤：   ARUHUB_API_KEY=... node tools/ai-skin.mjs --char male --name ai_ronin --views side,front"