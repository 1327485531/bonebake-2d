// GPT Image 2 → M2D 皮肤
//
// 思路：AI 生成的是一张"人物图"，而 M2D 的蒙皮网格是 2D 角色剪影。
// 直接把 AI 图当纹理贴上去需要一套 UV，这里用**绑定姿态的平面投影 UV**：
//   - 先把角色的绑定姿态渲染成参考图（tools/render-ref.mjs → bind）
//   - 让 gpt-image-2 的 /images/edits 按参考图重绘（保持姿势/轮廓/构图）
//   - 抠掉品红背景、裁到人物包围盒、向外扩几像素色边
//   - 每个顶点按绑定姿态的 (x,y) 映射到图片人物包围盒里 → 写进 characters-ai.json
//
// 这样生成的是一张"画在角色身上的皮"，骨架、动画、权重、深度排序全部沿用原角色。
//
// 用法（密钥只走环境变量，绝不写进仓库）：
//   ARUHUB_API_KEY=sk-... node tools/ai-skin.mjs --char male --name ai_ronin --views side,front
//   ARUHUB_API_KEY=sk-... node tools/ai-skin.mjs --char male --name ai_ronin --views front --reuse
//
// 输出：
//   out/<view>/ai/ref-<char>-<view>.png      参考图（绑定姿态）
//   out/<view>/ai/raw-<name>-<view>.png      API 原图
//   out/<view>/ai/<name>-<view>.png          抠图/裁剪后的纹理
//   out/<view>/characters-ai.json            合并进演示页的 AI 角色
//   out/<view>/ai/<name>-<view>.json         生成参数元数据（不含密钥）

import fs from 'node:fs'
import path from 'node:path'
import { execFileSync } from 'node:child_process'
import { decodePng, encodePng, processImage, planarUvs } from './ai-image.mjs'
import { generateEdit } from './aruhub.mjs'

const argv = process.argv.slice(2)
const opt = (n, d) => { const i = argv.indexOf('--' + n); return i === -1 ? d : argv[i + 1] }
const has = (n) => argv.includes('--' + n)

const BASE = opt('base', 'out')
const CHAR = opt('char', 'male')
const NAME = opt('name', 'ai_ronin')
const VIEWS = (() => {
  const v = (opt('views', 'side,front')).split(',').map(s => s.trim()).filter(Boolean)
  return v.includes('both') ? ['side', 'front'] : v
})()
const MODEL = opt('model', 'gpt-image-2')
const QUALITY = opt('quality', 'medium')
const SIZE = opt('size', '1024x1024')
const REUSE = has('reuse')
const NO_API = has('no-api')
const NO_CHAR = has('no-char')
const PAD_RATIO = Number(opt('pad', '0.012'))

const DEFAULT_PROMPT = `Repaint the character in the reference image as a detailed stylized cyberpunk street samurai:
lean adult male, short black hair, glowing cyan visor over the eyes, dark teal techwear jacket with
orange emissive trim, mechanical right forearm, dark cargo pants, armored boots.
Keep the EXACT same pose, body proportions, limb positions, silhouette, camera angle and full-body
framing as the reference, from head to toe. Do not add a weapon, cape, hat, long hair, backpack or
anything that changes the silhouette. {VIEW_HINT}
Solid chroma-key magenta background (#FF00FF), no shadow, no ground, no text, no border, no frame.
Clean 2D game character concept art, crisp edges, readable silhouette, high detail.`
const PROMPT = opt('prompt', DEFAULT_PROMPT)
const VIEW_HINT = {
  front: 'Strict front-facing T-pose, both arms extended horizontally and symmetrically.',
  side: 'Strict side profile facing right, arms relaxed close to the body.'
}

// ---------------- 主流程 ----------------
async function runView (view) {
  const dataDir = path.join(BASE, view)
  const charFile = path.join(dataDir, 'characters.json')
  if (!fs.existsSync(charFile)) throw new Error('找不到 ' + charFile)
  const chars = JSON.parse(fs.readFileSync(charFile, 'utf8'))
  const base = chars.characters[CHAR]
  if (!base) throw new Error(`characters.json 里没有角色 ${CHAR}`)

  const aiDir = path.join(dataDir, 'ai')
  fs.mkdirSync(aiDir, { recursive: true })
  const ref = path.join(aiDir, `ref-${CHAR}-${view}.png`)
  const raw = path.join(aiDir, `raw-${NAME}-${view}.png`)
  const tex = path.join(aiDir, `${NAME}-${view}.png`)

  console.log(`\n===== ${view} / ${NAME}（底模 ${CHAR}）=====`)

  if (!REUSE || !fs.existsSync(ref)) {
    console.log('  渲染绑定姿态参考图…')
    execFileSync(process.execPath, ['tools/render-ref.mjs', dataDir, CHAR, 'bind', '0', ref], { stdio: 'inherit' })
  } else console.log('  复用参考图:', path.relative(process.cwd(), ref))

  const prompt = PROMPT.replace('{VIEW_HINT}', VIEW_HINT[view] || '')
  if (!NO_API && (!REUSE || !fs.existsSync(raw))) {
    console.log('  调用 gpt-image-2 /images/edits …')
    await generateEdit({ refPath: ref, prompt, model: MODEL, size: SIZE, quality: QUALITY, rawPath: raw })
  } else if (!fs.existsSync(raw)) {
    throw new Error('没有原始生成图，且指定了 --no-api: ' + raw)
  } else console.log('  复用生成图:', path.relative(process.cwd(), raw))

  const img = decodePng(fs.readFileSync(raw))
  const frame = processImage(img, PAD_RATIO)
  fs.writeFileSync(tex, encodePng(frame.width, frame.height, frame.data))
  console.log(`  抠图/裁边：${frame.width}x${frame.height}，uv 内缩 [${frame.u0.toFixed(3)},${frame.v0.toFixed(3)}]-[${frame.u1.toFixed(3)},${frame.v1.toFixed(3)}]`)

  const { uvs, meshBounds } = planarUvs(base.mesh, frame)
  const def = JSON.parse(JSON.stringify(base))
  def.textures = [`ai/${NAME}-${view}.png`]
  def.mesh.uvs = uvs
  for (const p of def.mesh.parts) p.tex = 0
  def.ai = {
    source: CHAR,
    view,
    model: MODEL,
    size: SIZE,
    quality: QUALITY,
    texture: `ai/${NAME}-${view}.png`,
    ref: `ai/ref-${CHAR}-${view}.png`,
    generatedAt: new Date().toISOString()
  }

  const aiJsonPath = path.join(dataDir, 'characters-ai.json')
  if (!NO_CHAR) {
    const aiJson = fs.existsSync(aiJsonPath) ? JSON.parse(fs.readFileSync(aiJsonPath, 'utf8')) : { characters: {} }
    aiJson.characters[NAME] = def
    fs.writeFileSync(aiJsonPath, JSON.stringify(aiJson))
  }

  fs.writeFileSync(path.join(aiDir, `${NAME}-${view}.json`), JSON.stringify({
    name: NAME,
    source: CHAR,
    view,
    model: MODEL,
    size: SIZE,
    quality: QUALITY,
    prompt,
    ref: path.relative(process.cwd(), ref),
    raw: path.relative(process.cwd(), raw),
    texture: path.relative(process.cwd(), tex),
    meshBounds,
    uvFrame: { u0: frame.u0, v0: frame.v0, u1: frame.u1, v1: frame.v1 },
    generatedAt: new Date().toISOString()
  }, null, 2))

  console.log('  ✔ 纹理:', path.relative(process.cwd(), tex))
  if (NO_CHAR) console.log('  （--no-char：只写纹理/元数据，不加入演示角色）')
  else console.log('  ✔ 角色数据:', path.relative(process.cwd(), aiJsonPath))
}

if (VIEWS.length === 0) { console.error('没有指定 --views'); process.exit(1) }
for (const view of VIEWS) await runView(view)
console.log(NO_CHAR
  ? '\n完成（--no-char）：纹理/元数据已写出，未改动 characters-ai.json'
  : `\n完成。演示页里刷新后，角色下拉框会出现带「AI」标记的 ${NAME}`)
