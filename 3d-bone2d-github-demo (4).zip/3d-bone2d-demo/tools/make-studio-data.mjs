// 把 file:// 下必须用到的数据打包成 web/studio-data.js：
//   - templates/<view>/base-male.json
//   - templates/side/pose-walk0.json
//   - templates/<view>/ref-<group>.png
// 这样生成页和导入页不 fetch 本地 JSON/PNG，双击 HTML 也能用。
//
// 用法：node tools/make-studio-data.mjs
import fs from 'node:fs'
import path from 'node:path'

const ROOT = path.resolve('.')
const GROUPS = ['head', 'torso', 'arm_l', 'arm_r', 'leg_l', 'leg_r']
const data = { generatedAt: new Date().toISOString(), side: {}, front: {} }

for (const view of ['side', 'front']) {
  const basePath = path.join(ROOT, 'templates', view, 'base-male.json')
  data[view].base = JSON.parse(fs.readFileSync(basePath, 'utf8'))
  if (view === 'side') {
    data[view].pose = JSON.parse(fs.readFileSync(path.join(ROOT, 'templates', 'side', 'pose-walk0.json'), 'utf8'))
  }
  data[view].refs = {}
  for (const g of GROUPS) {
    const p = path.join(ROOT, 'templates', view, `ref-${g}.png`)
    data[view].refs[g] = 'data:image/png;base64,' + fs.readFileSync(p).toString('base64')
  }
}

const out = `// 自动生成，勿手改：node tools/make-studio-data.mjs
// 让 web/import.html / web/generate.html 在 file:// 下不 fetch 本地文件。
window.STUDIO_DATA = ${JSON.stringify(data)};
`
fs.writeFileSync(path.join(ROOT, 'web', 'studio-data.js'), out)
console.log('写出 web/studio-data.js', (out.length / 1024 / 1024).toFixed(2), 'MB')
