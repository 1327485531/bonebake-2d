// 精细版 AI 皮肤：按身体分块生成/裁图，再打包成一张单 part 图集。
//
// 和 ai-skin.mjs 的区别：
//   - 旧版：整张人物图按整个人物包围盒做平面 UV，所有部位共用一张图；
//   - 新版：按主导骨骼把网格分成头/躯干/左右臂/左右腿 6 块，每块单独一张 AI 图，
//     各自映射到自己的包围盒，最后拼进一张图集 + 单 part 网格。
//   单 part 意味着 M2D 运行时仍然是"逐三角面全局深度排序"，不会因为分块丢遮挡。
//
// 默认 hybrid：正视图的 6 块分别调 gpt-image-2 生成（机械臂/脸/夹克各有细节），
// 侧视图的 6 块从已有整身侧视 AI 图里裁（侧视各块重叠严重，逐块生成接缝更明显）。
//
// 纹理姿态（--pose）：绑定姿态是 T-pose 时，侧视手臂正对镜头，屏幕投影退化，
// 整条手臂会被压进肩部一个小圆，平面 UV 必然糊。--pose Walk --pose-frame 0 --pose-groups arm_r
// 只把 arm_r 换到"手臂已经伸开"的帧求 UV/参考图，其余块仍用 bind。详见 docs 7.8。
//
// 用法：
//   ARUHUB_API_KEY=... node tools/ai-skin-parts.mjs --char male --name ai_ronin_hd --views front --source generated
//   ARUHUB_API_KEY=... node tools/ai-skin-parts.mjs --char male --name ai_ronin_hd --views side  --source full --full-name ai_ronin
//   node tools/ai-skin-parts.mjs --char male --name ai_ronin_v5 --views side --source custom \
//     --pose Walk --pose-frame 0 --pose-groups arm_r
//   ARUHUB_API_KEY=... node tools/ai-skin-parts.mjs --char male --name ai_chibi --views side \
//     --source generated --style chibi --pose Walk --pose-frame 0 --pose-groups arm_r \
//     --hide arm_l --head-scale 2
//
// 输出：
//   out/<view>/ai/parts/ref-<name>-<group>-<view>.png
//   out/<view>/ai/parts/raw-<name>-<group>-<view>.png
//   out/<view>/ai/parts/<name>-<group>-<view>.png
//   out/<view>/ai/<name>-atlas-<view>.png
//   out/<view>/characters-ai.json（合并角色）

import fs from 'node:fs'
import path from 'node:path'
import { execFileSync } from 'node:child_process'
import {
  decodePng, encodePng, processImage, planarUvsForBox,
  splitMeshGroups, rebalanceNeck, GROUP_LABEL, GROUP_ORDER, cropImage, packAtlas
} from './ai-image.mjs'
import { loadClip, computePosedVerts, vertsBox, bindBoneOrigin } from './pose2d.mjs'
import { generateEdit } from './aruhub.mjs'

const argv = process.argv.slice(2)
const opt = (n, d) => { const i = argv.indexOf('--' + n); return i === -1 ? d : argv[i + 1] }
const has = (n) => argv.includes('--' + n)

const BASE = opt('base', 'out')
const CHAR = opt('char', 'male')
const NAME = opt('name', 'ai_ronin_hd')
const VIEWS = (() => {
  const v = (opt('views', 'front,side')).split(',').map(s => s.trim()).filter(Boolean)
  return v.includes('both') ? ['front', 'side'] : v
})()
const MODEL = opt('model', 'gpt-image-2')
const QUALITY = opt('quality', 'medium')
const SIZE = opt('size', '1024x1024')
const SOURCE = opt('source', 'hybrid') // hybrid | generated | full | custom
const FULL_NAME = opt('full-name', 'ai_ronin')
const STYLE = opt('style', 'cyberpunk') // cyberpunk | chibi
const REUSE = has('reuse')
const NO_API = has('no-api')

// 造型预设：每块单独生成时用哪套 CHARACTER BIBLE / PART_PROMPT
// chibi = 卡通 Q 版（大头、大眼睛、粗描边、亮色），配合 --head-scale 放大头部网格
const HIDE = new Set(
  opt('hide', '').split(',').map(s => s.trim()).filter(Boolean)
)
const HEAD_SCALE = Number(opt('head-scale', '1'))
if (!Number.isFinite(HEAD_SCALE) || HEAD_SCALE < 0.5 || HEAD_SCALE > 3) {
  throw new Error('--head-scale 必须在 0.5..3 之间')
}
const badHide = [...HIDE].filter(g => !GROUP_ORDER.includes(g))
if (badHide.length) throw new Error('未知的 --hide: ' + badHide.join(','))

// 纹理姿态：绑定姿态下侧视 T-pose 的手臂指向镜头，投影退化；
// 用某个手臂伸开的动画帧求 UV，才能把整条手臂的贴图铺开。
// --pose bind（默认）保持旧行为；--pose Walk --pose-frame 0 --pose-groups arm_r 只给指定块换姿态。
const POSE = opt('pose', 'bind')
const POSE_FRAME = Number(opt('pose-frame', '0'))
const POSE_GROUPS = new Set(
  opt('pose-groups', POSE === 'bind' ? '' : GROUP_ORDER.join(','))
    .split(',').map(s => s.trim()).filter(Boolean)
)
if (!Number.isInteger(POSE_FRAME) || POSE_FRAME < 0) throw new Error('--pose-frame 必须是非负整数')
if (POSE !== 'bind') {
  const bad = [...POSE_GROUPS].filter(g => !GROUP_ORDER.includes(g))
  if (bad.length) throw new Error('未知的 --pose-groups: ' + bad.join(','))
  if (POSE_GROUPS.size === 0) throw new Error('--pose 非 bind 时 --pose-groups 不能为空')
}

const STYLES = {
  cyberpunk: {
    bible: `CHARACTER BIBLE (must stay identical across all parts):
lean adult male cyberpunk street samurai. Short black hair, glowing cyan visor over the eyes,
warm tan skin. Dark teal techwear jacket (#0d3b3f) with hot orange emissive piping (#ff7a1a),
black under-suit, black tactical pants, heavy black armored boots with orange accents.
LEFT arm: normal arm in a dark jacket sleeve and black glove.
RIGHT arm: fully mechanical cybernetic arm, brushed chrome and dark teal plates, orange glowing seams,
articulated metal fingers. Detailed 2D game character concept art, crisp edges, consistent palette.`,
    parts: {
      head: `TASK: paint ONLY the isolated HEAD AND NECK.
Black hair, cyan visor, face, ear, neck. No shoulders, no jacket, no arms, no hands, no torso.
The head must fill the frame and use the same angle/orientation as the reference.`,
      torso: `TASK: paint ONLY the isolated TORSO (neck opening to waist/hips).
Dark teal techwear jacket with orange piping, black under-suit, chest harness, belt, hip pouches.
No head, no arms, no hands, no legs. The torso must fill the frame.`,
      arm_l: `TASK: paint ONLY the isolated LEFT ARM (shoulder to gloved hand).
Dark teal jacket sleeve, black glove, normal human hand. No torso, no head, no legs.
The arm must fill the frame horizontally, same orientation as the reference.`,
      arm_r: `TASK: paint ONLY the isolated RIGHT MECHANICAL ARM (shoulder to hand).
Brushed chrome and dark teal plated cybernetic arm, orange glowing seams, articulated metal fingers.
No torso, no head, no legs. The arm must fill the frame horizontally, same orientation as the reference.`,
      leg_l: `TASK: paint ONLY the isolated LEFT LEG (hip to boot).
Black tactical pants, knee pad, heavy armored boot with orange accents. No torso, no other leg.
The leg must fill the frame vertically, same orientation as the reference.`,
      leg_r: `TASK: paint ONLY the isolated RIGHT LEG (hip to boot).
Black tactical pants, knee pad, heavy armored boot with orange accents. No torso, no other leg.
The leg must fill the frame vertically, same orientation as the reference.`
    },
    common: `Keep the exact same silhouette, proportions, pose and orientation as the reference body part.
Do not add extra limbs, a second leg/arm, a weapon, cape, hat, backpack, text or frame.
Solid chroma-key magenta background (#FF00FF), no shadow, no ground, one isolated part, centered.`
  },

  chibi: {
    bible: `CHARACTER BIBLE (must stay identical across all parts):
cute chibi cyberpunk street kid. Big head, huge expressive amber eyes, tiny nose, small smile, rosy cheeks,
spiky mint-green hair, chunky orange goggles pushed up on the forehead, warm light skin.
Oversized cream and teal bomber jacket (#e8e0c8 / #0d6b6b) with hot orange trim (#ff8a1a),
black shorts, chunky orange-and-teal sneakers, small chest patch.
LEFT arm: puffy cream jacket sleeve with orange stripe, big rounded mitten hand.
RIGHT arm: cute chunky mechanical arm, rounded teal and chrome plates, orange glowing joints,
big rounded three-finger mitten hand.
Thick clean cartoon outlines, cel-shaded flat colors, bright neon palette, 2D game character art, cute.`,
    parts: {
      head: `TASK: paint ONLY the isolated HEAD AND NECK.
Cute chibi face: HUGE expressive amber eyes (about one third of the face), tiny nose, small smile, rosy cheeks,
spiky mint-green hair, chunky orange goggles pushed up on the forehead, big round ear.
No shoulders, no jacket, no arms, no hands, no torso.
The head must fill the frame and use the same angle/orientation as the reference.`,
      torso: `TASK: paint ONLY the isolated TORSO (neck opening to waist/hips).
Oversized cream and teal bomber jacket, big orange zipper, chest patch, chunky belt, rounded shoulders,
cute chibi proportions. No head, no arms, no hands, no legs. The torso must fill the frame.`,
      arm_l: `TASK: paint ONLY the isolated LEFT ARM (shoulder to mitten hand).
Puffy cream jacket sleeve with an orange stripe, big rounded mitten hand, cute chibi proportions.
No torso, no head, no legs. The arm must fill the frame horizontally, same orientation as the reference.`,
      arm_r: `TASK: paint ONLY the isolated RIGHT MECHANICAL ARM (shoulder to mitten hand).
Cute chunky robot arm: rounded teal and chrome plates, orange glowing joints,
big rounded three-finger mitten hand. No torso, no head, no legs.
The arm must fill the frame horizontally, same orientation as the reference.`,
      leg_l: `TASK: paint ONLY the isolated LEFT LEG (hip to boot).
Baggy teal cargo pants, rounded knee pad, big chunky sneaker with a THIN orange sole and a tall
cream and teal upper, laces and a round toe cap. The sneaker upper must fill the bottom of the frame;
avoid a thick platform sole. Cute chibi proportions.
No torso, no arm, no hand, no other leg. The leg must fill the frame vertically, same orientation as the reference.`,
      leg_r: `TASK: paint ONLY the isolated RIGHT LEG (hip to boot).
Baggy teal cargo pants, rounded knee pad, big chunky sneaker with a THIN orange sole and a tall
cream and teal upper, laces and a round toe cap. The sneaker upper must fill the bottom of the frame;
avoid a thick platform sole. Cute chibi proportions.
No torso, no arm, no hand, no other leg. The leg must fill the frame vertically, same orientation as the reference.`
    },
    common: `Keep the exact same silhouette, proportions, pose and orientation as the reference body part.
Do not add extra limbs, a second leg/arm, a weapon, cape, hat, backpack, text or frame.
Thick clean cartoon outlines, cel-shaded flat colors, crisp edges, bright and readable.
Solid chroma-key magenta background (#FF00FF), no shadow, no ground, one isolated part, centered.`
  }
}

const VIEW_HINT = {
  front: 'View: strict front view, same T-pose as the reference, symmetrical.',
  side: 'View: strict side profile facing right, same pose as the reference.'
}

const styleDef = STYLES[STYLE]
if (!styleDef) throw new Error(`未知的 --style: ${STYLE}（可选: ${Object.keys(STYLES).join(', ')}）`)
const BIBLE = styleDef.bible
const PART_PROMPT = styleDef.parts
const COMMON = styleDef.common

function log (...a) { console.log(...a) }

function renderPartRef (view, dataDir, name, group, refPath, posed = false) {
  fs.mkdirSync(path.dirname(refPath), { recursive: true })
  execFileSync(process.execPath, [
    'tools/render-ref.mjs', dataDir, CHAR, posed ? POSE : 'bind', posed ? String(POSE_FRAME) : '0', refPath,
    '--group', group, '--bg', 'f2f2f2'
  ], { stdio: 'inherit' })
}

/** 从整身 AI 图里裁出某个身体块（侧视 hybrid 用） */
function cropPartFromFull (view, group) {
  const texPath = path.join(BASE, view, 'ai', `${FULL_NAME}-${view}.png`)
  const metaPath = path.join(BASE, view, 'ai', `${FULL_NAME}-${view}.json`)
  if (!fs.existsSync(texPath) || !fs.existsSync(metaPath)) {
    throw new Error(`--source full 需要 ${texPath} 和 ${metaPath}（先跑 ai-skin.mjs）`)
  }
  const img = decodePng(fs.readFileSync(texPath))
  const meta = JSON.parse(fs.readFileSync(metaPath, 'utf8'))
  const f = meta.uvFrame
  const [minX, minY, maxX, maxY] = meta.meshBounds
  const [bx0, by0, bx1, by1] = group.box
  const u0 = f.u0 + ((bx0 - minX) / (maxX - minX)) * (f.u1 - f.u0)
  const u1 = f.u0 + ((bx1 - minX) / (maxX - minX)) * (f.u1 - f.u0)
  const v0 = f.v0 + (1 - (by1 - minY) / (maxY - minY)) * (f.v1 - f.v0)
  const v1 = f.v0 + (1 - (by0 - minY) / (maxY - minY)) * (f.v1 - f.v0)
  const padU = (u1 - u0) * 0.05, padV = (v1 - v0) * 0.05
  const x0 = (u0 - padU) * img.width, x1 = (u1 + padU) * img.width
  const y0 = (v0 - padV) * img.height, y1 = (v1 + padV) * img.height
  const crop = cropImage(img, x0, y0, x1, y1)
  const cw = crop.width, ch = crop.height
  const frame = {
    u0: Math.max(0, (u0 * img.width - Math.max(0, Math.floor(x0))) / cw),
    v0: Math.max(0, (v0 * img.height - Math.max(0, Math.floor(y0))) / ch),
    u1: Math.min(1, (u1 * img.width - Math.max(0, Math.floor(x0))) / cw),
    v1: Math.min(1, (v1 * img.height - Math.max(0, Math.floor(y0))) / ch)
  }
  return { name: group.name, width: cw, height: ch, data: crop.data, ...frame }
}

async function buildView (view) {
  const dataDir = path.join(BASE, view)
  const chars = JSON.parse(fs.readFileSync(path.join(dataDir, 'characters.json'), 'utf8'))
  const base = chars.characters[CHAR]
  if (!base) throw new Error(`没有角色 ${CHAR}`)
  const { groups } = splitMeshGroups(base)
  rebalanceNeck(groups, base)
  const partsDir = path.join(dataDir, 'ai', 'parts')
  fs.mkdirSync(partsDir, { recursive: true })
  const posedVerts = POSE !== 'bind'
    ? computePosedVerts(base, loadClip(dataDir, POSE), POSE_FRAME)
    : null
  if (posedVerts) {
    log(`  纹理姿态: ${POSE} 第 ${POSE_FRAME} 帧，块: ${[...POSE_GROUPS].join(',')}（其余仍用绑定姿态）`)
  }
  if (STYLE !== 'cyberpunk') log(`  造型风格: ${STYLE}`)
  if (HEAD_SCALE !== 1) log(`  头部缩放: ${HEAD_SCALE}x（只放大 head 组顶点，骨骼/权重/动画不变）`)

  const allGroups = groups.map(g => g.name)
  const generatedSet = new Set(
    SOURCE === 'generated' ? allGroups
      : SOURCE === 'full' ? []
        : view === 'front' ? allGroups
          : [] // 侧视各块重叠严重，逐块生成反而接缝明显；侧视统一用整身图裁块
  )
  log(`\n===== ${view} / ${NAME} / ${SOURCE === 'custom' ? '自定义分块图' : generatedSet.size ? '部分逐块 AI 生成' : '从整身图裁块'} =====`)
  log('  生成块: ' + ([...generatedSet].join(',') || '无') + '；其余从整身图裁')
  if (HIDE.size) log('  隐藏块: ' + [...HIDE].join(','))
  log('  分块: ' + groups.map(g => `${g.name}(${g.tris.length}三角/${g.verts.length}顶点)`).join(', '))

  const partImages = []
  for (const g of groups) {
    // 这个块是否用纹理姿态求 UV / 渲染参考图
    const posed = !!posedVerts && POSE_GROUPS.has(g.name)
    const uvPositions = posed ? posedVerts : base.mesh.verts
    const uvBox = vertsBox(uvPositions, g.verts)
    let part
    if (HIDE.has(g.name)) {
      part = { name: g.name, width: 2, height: 2, data: new Uint8Array(16), u0: 0, v0: 0, u1: 1, v1: 1 }
      // 落一张全透明分块图，方便以后用 --source custom 重建，不必重新生成
      fs.writeFileSync(path.join(partsDir, `${NAME}-${g.name}-${view}.png`), encodePng(2, 2, new Uint8Array(16)))
      log(`  [${g.name}] 隐藏（全透明，不调 API）`)
      partImages.push({ ...part, name: g.name, posed, uvPositions, uvBox })
      continue
    }
    if (SOURCE === 'custom') {
      const src = path.join(partsDir, `${NAME}-${g.name}-${view}.png`)
      if (!fs.existsSync(src)) throw new Error('自定义分块图不存在: ' + src)
      const img = decodePng(fs.readFileSync(src))
      // 全透明图：表示这个部位在**这个视角**里被挡住/不画（例如侧视的远侧手臂）
      let any = false
      for (let i = 3; i < img.data.length; i += 4) if (img.data[i] > 0) { any = true; break }
      if (any) {
        part = processImage(img, 0.06)
        log(`  [${g.name}] 自定义图 ${part.width}x${part.height}`)
      } else {
        part = { name: g.name, width: 2, height: 2, data: new Uint8Array(16), u0: 0, v0: 0, u1: 1, v1: 1 }
        log(`  [${g.name}] 全透明（该视角隐藏）`)
      }
    } else if (generatedSet.has(g.name)) {
      const ref = path.join(partsDir, `ref-${NAME}-${g.name}-${view}.png`)
      const raw = path.join(partsDir, `raw-${NAME}-${g.name}-${view}.png`)
      const tex = path.join(partsDir, `${NAME}-${g.name}-${view}.png`)
      if (!REUSE || !fs.existsSync(ref)) {
        log(`  [${g.name}] 渲染局部参考${posed ? `（${POSE} 帧 ${POSE_FRAME}）` : ''}…`)
        renderPartRef(view, dataDir, NAME, g.name, ref, posed)
      }
      if (!NO_API && (!REUSE || !fs.existsSync(raw))) {
        const prompt = `${BIBLE}\n\n${PART_PROMPT[g.name] || ''}\n${VIEW_HINT[view]}\n${COMMON}`
        log(`  [${g.name}] 调 gpt-image-2…`)
        await generateEdit({ refPath: ref, prompt, model: MODEL, size: SIZE, quality: QUALITY, rawPath: raw })
      }
      if (!fs.existsSync(raw)) throw new Error('没有生成图: ' + raw)
      const img = decodePng(fs.readFileSync(raw))
      part = processImage(img, 0.06)
      fs.writeFileSync(tex, encodePng(part.width, part.height, part.data))
      log(`  [${g.name}] 纹理 ${part.width}x${part.height}`)
    } else {
      if (posed) {
        throw new Error(`块 ${g.name} 用了纹理姿态 ${POSE}:${POSE_FRAME}，不能从绑定姿态的整身图裁块；`
          + '请用 --source custom/generated 给它单独出图')
      }
      part = cropPartFromFull(view, g)
      const tex = path.join(partsDir, `${NAME}-${g.name}-${view}.png`)
      fs.writeFileSync(tex, encodePng(part.width, part.height, part.data))
      log(`  [${g.name}] 从整身图裁出 ${part.width}x${part.height}`)
    }
    partImages.push({ ...part, name: g.name, posed, uvPositions, uvBox })
  }

  // 打包图集（6 块：3x2，单格 650x980，总尺寸 2014x2008，保持在 2048 以内）
  // WebGL2 最低保证的 MAX_TEXTURE_SIZE 是 2048；太大在低端设备上会直接创建失败
  const atlas = packAtlas(partImages, { cols: 3, rows: 2, cellW: 650, cellH: 980, pad: 10, gap: 16 })
  const atlasPath = path.join(dataDir, 'ai', `${NAME}-atlas-${view}.png`)
  fs.writeFileSync(atlasPath, encodePng(atlas.width, atlas.height, atlas.data))
  log(`  图集 ${atlas.width}x${atlas.height} → ${path.relative(process.cwd(), atlasPath)}`)

  // 拼新网格：每个身体块复制自己的顶点，UV 指向图集里对应块
  const src = base.mesh
  const newVerts = [], newUvs = [], newSkin = [], newWeights = [], newIdx = [], newOffsets = []
  const groupMeta = []
  for (const g of groups) {
    const map = new Map()
    const part = partImages.find(p => p.name === g.name)
    const uv = planarUvsForBox(src, g.verts, part.uvBox, atlas.frames[g.name], part.uvPositions)
    for (let i = 0; i < g.verts.length; i++) {
      const old = g.verts[i]
      map.set(old, newVerts.length / 2)
      newVerts.push(src.verts[old * 2], src.verts[old * 2 + 1])
      newUvs.push(uv[i * 2], uv[i * 2 + 1])
      for (let k = 0; k < 4; k++) {
        newSkin.push(src.skinIndices[old * 4 + k])
        newWeights.push(src.skinWeights[old * 4 + k])
      }
    }
    for (const tr of g.tris) {
      newIdx.push(map.get(tr.a), map.get(tr.b), map.get(tr.c))
      newOffsets.push(tr.offset)
    }
    groupMeta.push({
      name: g.name,
      label: GROUP_LABEL[g.name] || g.name,
      triangles: g.tris.length,
      vertices: g.verts.length,
      box: part.uvBox.map(v => Math.round(v * 1e4) / 1e4),
      pose: part.posed ? `${POSE}:${POSE_FRAME}` : 'bind',
      atlasFrame: atlas.frames[g.name]
    })
  }
  if (newVerts.length / 2 > 65535) throw new Error('合并后顶点超过 65535，无法用 Uint16 索引')

  const def = JSON.parse(JSON.stringify(base))
  def.textures = [`ai/${NAME}-atlas-${view}.png`]
  def.mesh = {
    verts: newVerts,
    uvs: newUvs,
    skinIndices: newSkin,
    skinWeights: newWeights,
    parts: [{
      base: 0,
      count: newIdx.length / 3,
      indices: newIdx,
      tex: 0,
      color: (src.parts[0] && src.parts[0].color) || [1, 1, 1, 1],
      depthOffsets: newOffsets
    }]
  }

  // Q 版大头：只放大 head 组的顶点（绕 head 骨骼原点），UV/权重/动画全不动。
  // 头部 UV 已按原 bbox 算好；放大后纹理跟着几何拉伸，仍在同一块 UV 岛内。
  let chibi = null
  if (HEAD_SCALE !== 1) {
    const headIdx = groupMeta.findIndex(g => g.name === 'head')
    if (headIdx < 0) throw new Error('没有 head 组，无法 --head-scale')
    let headOffset = 0
    for (let i = 0; i < headIdx; i++) headOffset += groupMeta[i].vertices
    const headCount = groupMeta[headIdx].vertices
    const [px, py] = bindBoneOrigin(base, 'head')
    for (let i = 0; i < headCount; i++) {
      const o = (headOffset + i) * 2
      def.mesh.verts[o] = px + (def.mesh.verts[o] - px) * HEAD_SCALE
      def.mesh.verts[o + 1] = py + (def.mesh.verts[o + 1] - py) * HEAD_SCALE
    }
    let minX = 1e9, minY = 1e9, maxX = -1e9, maxY = -1e9
    for (let i = 0; i < headCount; i++) {
      const o = (headOffset + i) * 2
      const x = def.mesh.verts[o], y = def.mesh.verts[o + 1]
      if (x < minX) minX = x
      if (x > maxX) maxX = x
      if (y < minY) minY = y
      if (y > maxY) maxY = y
    }
    groupMeta[headIdx].box = [minX, minY, maxX, maxY].map(v => Math.round(v * 1e4) / 1e4)
    chibi = {
      headScale: HEAD_SCALE,
      pivot: [Math.round(px * 1e4) / 1e4, Math.round(py * 1e4) / 1e4]
    }
  }

  def.ai = {
    kind: 'parts',
    source: CHAR,
    view,
    model: MODEL,
    size: SIZE,
    quality: QUALITY,
    style: STYLE,
    texture: `ai/${NAME}-atlas-${view}.png`,
    pose: posedVerts ? { clip: POSE, frame: POSE_FRAME, groups: [...POSE_GROUPS] } : null,
    chibi,
    groups: groupMeta,
    generatedAt: new Date().toISOString()
  }

  const aiJsonPath = path.join(dataDir, 'characters-ai.json')
  const aiJson = fs.existsSync(aiJsonPath) ? JSON.parse(fs.readFileSync(aiJsonPath, 'utf8')) : { characters: {} }
  aiJson.characters[NAME] = def
  fs.writeFileSync(aiJsonPath, JSON.stringify(aiJson))

  fs.writeFileSync(path.join(dataDir, 'ai', `${NAME}-${view}.json`), JSON.stringify({
    name: NAME, source: CHAR, view, sourceMode: SOURCE, model: MODEL, size: SIZE, quality: QUALITY,
    pose: posedVerts ? { clip: POSE, frame: POSE_FRAME, groups: [...POSE_GROUPS] } : null,
    style: STYLE, chibi,
    atlas: path.relative(process.cwd(), atlasPath), groups: groupMeta, mesh: {
      vertices: newVerts.length / 2, triangles: newIdx.length / 3
    }, generatedAt: new Date().toISOString()
  }, null, 2))

  log(`  ✔ 角色 ${NAME}: ${newVerts.length / 2} 顶点 / ${newIdx.length / 3} 三角 / 单 part 图集`)
  log(`  ✔ ${path.relative(process.cwd(), aiJsonPath)}`)
}

for (const view of VIEWS) await buildView(view)
log('\n完成。演示页刷新后会出现', NAME, '（带 AI 标记）')
