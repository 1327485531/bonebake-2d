// 用 AruHub GPT Image 批量生成“不同主题/画风”的角色套图。
// 每个角色：6 个部位各调一次 images/edits（ref 来自 templates/<view>/ref-<group>.png），
// 处理成透明部件后，用 ai-skin-parts --source custom 构建进 out/<view>/characters-ai.json。
//
// 用法：
//   ARUHUB_API_KEY=... node tools/generate-character-sets.mjs
//   ARUHUB_API_KEY=... node tools/generate-character-sets.mjs --only ai_mage,ai_wuxia
//   ARUHUB_API_KEY=... node tools/generate-character-sets.mjs --views side --force
import fs from 'node:fs'
import path from 'node:path'
import { execFileSync } from 'node:child_process'
import { generateEdit } from './aruhub.mjs'
import { decodePng, encodePng, processImage } from './ai-image.mjs'

const argv = process.argv.slice(2)
const opt = (n, d) => { const i = argv.indexOf('--' + n); return i === -1 ? d : argv[i + 1] }
const has = (n) => argv.includes('--' + n)
const DATA = opt('base', 'out')
const VIEWS = opt('views', 'side').split(',').map(s => s.trim()).filter(Boolean)
const ONLY = opt('only', '').split(',').map(s => s.trim()).filter(Boolean)
const FORCE = has('force')
const MODEL = opt('model', 'gpt-image-2')
const QUALITY = opt('quality', 'medium')
const SIZE = opt('size', '1024x1024')
const GROUPS = ['head', 'torso', 'arm_l', 'arm_r', 'leg_l', 'leg_r']

const PART = {
  head: `TASK: paint ONLY the isolated HEAD AND NECK (face, hair, ears, neck).
Use the CHARACTER DESIGN for hair, eyes, skin, accessories and colors.
No shoulders, no jacket, no arms, no hands, no torso.
The head must fill the frame and use the same angle/orientation as the reference.`,
  torso: `TASK: paint ONLY the isolated TORSO (neck opening to waist/hips).
Use the CHARACTER DESIGN for top/jacket/robe, belts, harness, pouches and colors.
No head, no arms, no hands, no legs.
The torso must fill the frame and use the same orientation as the reference.`,
  arm_l: `TASK: paint ONLY the isolated LEFT ARM (shoulder to hand/fingers), including sleeve,
glove or mechanical design from the CHARACTER DESIGN.
No torso, no head, no legs, no right arm.
The arm must fill the frame along the reference arm, same orientation as the reference.`,
  arm_r: `TASK: paint ONLY the isolated RIGHT ARM (shoulder to hand/fingers), including sleeve,
glove or mechanical design from the CHARACTER DESIGN.
No torso, no head, no legs, no left arm.
The arm must fill the frame along the reference arm, same orientation as the reference.`,
  leg_l: `TASK: paint ONLY the isolated LEFT LEG (hip to boot/foot), including pants,
knee pad and shoe design from the CHARACTER DESIGN.
No torso, no arm, no hand, no other leg.
The leg must fill the frame vertically, same orientation as the reference.`,
  leg_r: `TASK: paint ONLY the isolated RIGHT LEG (hip to boot/foot), including pants,
knee pad and shoe design from the CHARACTER DESIGN.
No torso, no arm, no hand, no other leg.
The leg must fill the frame vertically, same orientation as the reference.`
}
const VIEW_HINT = {
  side: 'View: strict side profile facing right, same pose as the reference.',
  front: 'View: strict front view, same T-pose as the reference, symmetrical.'
}
const COMMON = `Keep the exact same silhouette, proportions, pose, orientation and framing as the reference body part.
The reference is a flat-shaded geometry render: ignore its orange color and use the CHARACTER DESIGN colors.
Do not add extra limbs, a second arm/leg, a weapon, cape, hat, backpack, text or frame.
One isolated part, centered, solid chroma-key magenta background (#FF00FF), no shadow, no ground.`

const CHARS = [
  {
    name: 'ai_mage',
    headScale: 2,
    style: 'chibi',
    bible: `A cute Q-version fantasy mage. Big head, huge amber eyes, tiny nose, soft smile, warm light skin.
Long wavy lavender hair with silver streaks and side-swept bangs, small silver moon hairpin.
Oversized pastel-violet and cream robe with gold star and moon embroidery, cream sash, brown leather belt,
dark leggings, soft brown boots, small leather satchel.
LEFT arm: loose lavender sleeve with cream cuff and a thin silver bracer, small mitten hand.
RIGHT arm: loose lavender sleeve with a gold star cuff, small mitten hand.
Soft pastel palette (#b9a7ff / #f2e6d8 / #ffd166), thick clean cartoon outlines, cel-shaded flat colors,
cute 2D game character art.`,
    styleText: `Q-version chibi 2D game character art, soft pastel storybook palette, thick clean cartoon outlines,
cel-shaded flat colors, cute rounded shapes, crisp edges.`
  },
  {
    name: 'ai_steam',
    headScale: 1,
    style: 'cyberpunk',
    bible: `A steampunk inventor, adult, sharp amber eyes, short copper hair, brass goggles pushed up on the forehead,
light skin with faint freckles.
Cream linen shirt, brown leather vest with brass buckles, leather tool harness, dark charcoal trousers,
heavy leather boots, copper and brass palette (#b87333 / #6b4a2f / #e8d8b0).
LEFT arm: polished brass mechanical arm with copper pipes, small pressure gauge and leather straps.
RIGHT arm: rolled cream sleeve with a worn leather glove.
Semi-realistic painterly 2D game character illustration, detailed materials, warm workshop lighting,
visible brushwork, crisp edges.`,
    styleText: `Semi-realistic painterly 2D game character illustration, detailed brass/leather materials,
warm workshop lighting, visible brush strokes, rich but readable shapes.`
  },
  {
    name: 'ai_wuxia',
    headScale: 1,
    style: 'cyberpunk',
    bible: `A Chinese ink-wash xianxia swordsman, adult, long black hair tied with a silver hairpin,
pale skin, calm dark eyes, a thin red ribbon at the collar.
Layered white and ink-grey robe with wide sleeves, dark red sash, black inner collar, flowing hem, dark boots.
LEFT arm: wide white sleeve with faint ink-brush patterns.
RIGHT arm: wide grey sleeve with a dark red cuff.
Chinese ink-wash / sumi-e inspired 2D game character art, flowing brush strokes, limited black/white/red palette,
elegant, textured rice-paper background feel.`,
    styleText: `Chinese ink-wash / sumi-e inspired 2D game character art, flowing brush strokes,
limited black/white/red palette, elegant silhouettes, textured rice-paper feel.`
  },
  {
    name: 'ai_waste',
    headScale: 1,
    style: 'cyberpunk',
    bible: `A wasteland scavenger, adult, undercut black hair, weathered tan skin, one amber eye,
a narrow scar across the brow, a faded olive scarf around the neck.
Patched olive-drab jacket with rust-orange straps, mismatched armor plates, cargo pants, heavy boots,
fingerless gloves, muted rust/olive/sand palette (#6b6b3a / #a0522d / #d2b48c).
RIGHT arm: scavenged mechanical arm of rusted steel and orange cables, exposed pistons.
LEFT arm: patched sleeve with wrapped forearm and a fingerless glove.
Gritty graphic-novel / comic 2D game character art, bold ink shadows, rough textures, muted desert palette.`,
    styleText: `Gritty graphic-novel / comic 2D game character art, bold ink shadows, rough textures,
muted rust/olive desert palette, strong readable shapes.`
  },
  {
    name: 'ai_fairy',
    headScale: 2,
    style: 'chibi',
    bible: `A cute Q-version forest fairy child. Big head, huge green eyes, tiny nose, soft smile, freckles,
warm light skin, pointed ears.
Short mint-green hair with tiny leaves and lavender flowers, soft bangs.
Cream and moss-green leaf tunic, layered petal skirt, woven belt, small satchel, soft brown boots.
LEFT arm: puffy cream sleeve with a leaf cuff, small hand.
RIGHT arm: moss-green sleeve with a flower bracelet, small hand.
Soft watercolor storybook illustration, pastel greens/cream/lavender, delicate ink lines,
gentle paper texture, cute 2D game character art.`,
    styleText: `Soft watercolor storybook illustration, pastel greens/cream/lavender, delicate ink lines,
gentle paper texture, cute 2D game character art, clean shapes.`
  }
]

function promptFor (char, view, group) {
  return `${char.bible}

STYLE:
${char.styleText}

${PART[group]}

${VIEW_HINT[view]}

${COMMON}`
}

function partPath (view, name, group) {
  return path.join(DATA, view, 'ai', 'parts', `${name}-${group}-${view}.png`)
}
function rawPath (view, name, group) {
  return path.join(DATA, view, 'ai', 'parts', `raw-${name}-${group}-${view}.png`)
}
function refPath (view, group) {
  return path.join('templates', view, `ref-${group}.png`)
}

async function generateOne (char, view, group) {
  const out = partPath(view, char.name, group)
  if (!FORCE && fs.existsSync(out)) { console.log(`   [${group}] 已存在，跳过`); return }
  const ref = refPath(view, group)
  if (!fs.existsSync(ref)) throw new Error('缺少 ref: ' + ref)
  const raw = rawPath(view, char.name, group)
  let last
  for (let attempt = 1; attempt <= 4; attempt++) {
    try {
      if (attempt === 1) await new Promise(r => setTimeout(r, 1500))
      const buf = await generateEdit({
        refPath: ref,
        prompt: promptFor(char, view, group),
        model: MODEL,
        size: SIZE,
        quality: QUALITY,
        rawPath: raw
      })
      const img = decodePng(buf)
      const part = processImage(img, 0.06)
      fs.mkdirSync(path.dirname(out), { recursive: true })
      fs.writeFileSync(out, encodePng(part.width, part.height, part.data))
      console.log(`   [${group}] ${part.width}x${part.height} → ${out}`)
      return
    } catch (e) {
      last = e
      console.log(`   [${group}] 第 ${attempt} 次失败：${e.message}`)
      if (attempt < 4) await new Promise(r => setTimeout(r, 6000 * attempt))
    }
  }
  throw last
}

function build (char) {
  const args = [
    'tools/ai-skin-parts.mjs',
    '--char', 'male',
    '--name', char.name,
    '--views', VIEWS.join(','),
    '--source', 'custom',
    '--head-scale', String(char.headScale),
    '--style', char.style
  ]
  if (VIEWS.includes('side')) args.push('--pose', 'Walk', '--pose-frame', '0', '--pose-groups', 'arm_l,arm_r')
  console.log('   构建：node ' + args.join(' '))
  execFileSync(process.execPath, args, { stdio: 'inherit' })
}

if (!process.env.ARUHUB_API_KEY) throw new Error('需要 ARUHUB_API_KEY 环境变量')
for (const view of VIEWS) {
  if (!fs.existsSync(path.join(DATA, view, 'characters.json'))) throw new Error('缺少 ' + path.join(DATA, view, 'characters.json'))
}

const chars = ONLY.length ? CHARS.filter(c => ONLY.includes(c.name)) : CHARS
if (!chars.length) throw new Error('--only 没有匹配到角色')

for (const char of chars) {
  console.log(`\n===== ${char.name} / ${VIEWS.join(',')} / ${MODEL} =====`)
  for (const view of VIEWS) {
    for (const g of GROUPS) await generateOne(char, view, g)
  }
  build(char)
}
console.log('\n全部完成。演示页刷新后可在角色下拉框里看到新角色。')
