// 把一张 AI 生成的角色图烘焙进**角色原本的 UV 图集**。
//
// 和 ai-skin-parts 的区别：
//   - ai-skin / ai-skin-parts 是新建平面 UV，顶点/贴图布局都变了；
//   - 这里保留模型原始的 UV、权重、网格，把 AI 图按三角形的绑定姿态屏幕坐标
//     "烤"回原图集。适合 female_8 / police_male / monster 这类本来就有语义 UV 图的角色
//     （male / naked 的 UV 只是两块调色板，烤进去也只有 95x98 像素可用，不适合）。
//
// 用法：
//   ARUHUB_API_KEY=... node tools/ai-skin.mjs --char police_male --name ai_police_src --views side,front --no-char
//   node tools/bake-ai-atlas.mjs --data out/side  --char police_male --ai ai_police_src --name ai_police
//   node tools/bake-ai-atlas.mjs --data out/front --char police_male --ai ai_police_src --name ai_police
//
// 输出：
//   out/<view>/ai/<name>-atlas-<view>.png    烘焙后的原 UV 图集（默认 2x，512→1024）
//   out/<view>/characters-ai.json            合并角色
//   out/<view>/ai/<name>-<view>.json         烘焙元数据

import fs from 'node:fs'
import path from 'node:path'
import { decodePng, encodePng } from './ai-image.mjs'

const argv = process.argv.slice(2)
const opt = (n, d) => { const i = argv.indexOf('--' + n); return i === -1 ? d : argv[i + 1] }
const dataDir = path.resolve(opt('data', 'out/side'))
const CHAR = opt('char', 'police_male')
const AI = opt('ai', 'ai_police_src')
const NAME = opt('name', 'ai_police')
const SCALE = Number(opt('scale', '2'))
const DILATE = Number(opt('dilate', '4'))

const chars = JSON.parse(fs.readFileSync(path.join(dataDir, 'characters.json'), 'utf8'))
const def = chars.characters[CHAR]
if (!def) throw new Error(`没有角色 ${CHAR}`)
if (def.textures.length !== 1) throw new Error('目前只支持单张贴图角色；这个角色有 ' + def.textures.length + ' 张')
if (def.mesh.parts.length !== 1) throw new Error('目前只支持单 part 角色；这个角色有 ' + def.mesh.parts.length + ' 个 part')

const aiTexPath = path.join(dataDir, 'ai', `${AI}-${path.basename(dataDir)}.png`)
const aiMetaPath = path.join(dataDir, 'ai', `${AI}-${path.basename(dataDir)}.json`)
if (!fs.existsSync(aiTexPath) || !fs.existsSync(aiMetaPath)) throw new Error('找不到 AI 图/元数据: ' + aiTexPath)
const aiMeta = JSON.parse(fs.readFileSync(aiMetaPath, 'utf8'))
const aiImg = decodePng(fs.readFileSync(aiTexPath))
const baseTex = decodePng(fs.readFileSync(path.join(dataDir, def.textures[0])))

const W = Math.round(baseTex.width * SCALE)
const H = Math.round(baseTex.height * SCALE)
if (W > 4096 || H > 4096) throw new Error(`输出图集太大 ${W}x${H}`)
const out = new Uint8Array(W * H * 4)
const baked = new Uint8Array(W * H)

// AI 图的透明背景用最近的边缘颜色填满，避免 UV 边缘采到透明/品红
function fillAlpha (img) {
  const { width: w, height: h, data } = img
  const seen = new Uint8Array(w * h)
  const q = []
  for (let i = 0; i < w * h; i++) if (data[i * 4 + 3] > 0) { seen[i] = 1; q.push(i) }
  if (q.length === 0) throw new Error('AI 图完全透明')
  let head = 0
  while (head < q.length) {
    const i = q[head++]
    const x = i % w, y = (i / w) | 0
    for (const [nx, ny] of [[x - 1, y], [x + 1, y], [x, y - 1], [x, y + 1]]) {
      if (nx < 0 || ny < 0 || nx >= w || ny >= h) continue
      const ni = ny * w + nx
      if (seen[ni]) continue
      seen[ni] = 1
      data[ni * 4] = data[i * 4]; data[ni * 4 + 1] = data[i * 4 + 1]; data[ni * 4 + 2] = data[i * 4 + 2]; data[ni * 4 + 3] = 255
      q.push(ni)
    }
  }
}
fillAlpha(aiImg)

const [minX, minY, maxX, maxY] = aiMeta.meshBounds
const f = aiMeta.uvFrame
const mesh = def.mesh
const uv = mesh.uvs, vp = mesh.verts
const aiD = aiImg.data, aw = aiImg.width, ah = aiImg.height

function sampleAI (u, v) {
  const x = Math.min(aw - 1, Math.max(0, u * aw - 0.5))
  const y = Math.min(ah - 1, Math.max(0, v * ah - 0.5))
  const x0 = Math.floor(x), y0 = Math.floor(y)
  const x1 = Math.min(aw - 1, x0 + 1), y1 = Math.min(ah - 1, y0 + 1)
  const fx = x - x0, fy = y - y0
  const o00 = (y0 * aw + x0) * 4, o10 = (y0 * aw + x1) * 4, o01 = (y1 * aw + x0) * 4, o11 = (y1 * aw + x1) * 4
  const out = [0, 0, 0, 255]
  for (let k = 0; k < 3; k++) {
    const a = aiD[o00 + k] + (aiD[o10 + k] - aiD[o00 + k]) * fx
    const b = aiD[o01 + k] + (aiD[o11 + k] - aiD[o01 + k]) * fx
    out[k] = Math.round(a + (b - a) * fy)
  }
  return out
}

let tris = 0
const part = mesh.parts[0]
for (let t = 0; t < part.indices.length; t += 3) {
  const ia = part.indices[t], ib = part.indices[t + 1], ic = part.indices[t + 2]
  const u0 = uv[ia * 2] * W, v0 = uv[ia * 2 + 1] * H
  const u1 = uv[ib * 2] * W, v1 = uv[ib * 2 + 1] * H
  const u2 = uv[ic * 2] * W, v2 = uv[ic * 2 + 1] * H
  const den = (v1 - v2) * (u0 - u2) + (u2 - u1) * (v0 - v2)
  if (Math.abs(den) < 1e-9) continue
  const minU = Math.max(0, Math.floor(Math.min(u0, u1, u2))), maxU = Math.min(W - 1, Math.ceil(Math.max(u0, u1, u2)))
  const minV = Math.max(0, Math.floor(Math.min(v0, v1, v2))), maxV = Math.min(H - 1, Math.ceil(Math.max(v0, v1, v2)))
  for (let py = minV; py <= maxV; py++) {
    for (let px = minU; px <= maxU; px++) {
      const cx = px + 0.5, cy = py + 0.5
      const l0 = ((v1 - v2) * (cx - u2) + (u2 - u1) * (cy - v2)) / den
      const l1 = ((v2 - v0) * (cx - u2) + (u0 - u2) * (cy - v2)) / den
      const l2 = 1 - l0 - l1
      if (l0 < -1e-4 || l1 < -1e-4 || l2 < -1e-4) continue
      const sx = l0 * vp[ia * 2] + l1 * vp[ib * 2] + l2 * vp[ic * 2]
      const sy = l0 * vp[ia * 2 + 1] + l1 * vp[ib * 2 + 1] + l2 * vp[ic * 2 + 1]
      const au = f.u0 + ((sx - minX) / (maxX - minX)) * (f.u1 - f.u0)
      const av = f.v0 + (1 - (sy - minY) / (maxY - minY)) * (f.v1 - f.v0)
      const c = sampleAI(au, av)
      const oi = py * W + px
      out[oi * 4] = c[0]; out[oi * 4 + 1] = c[1]; out[oi * 4 + 2] = c[2]; out[oi * 4 + 3] = 255
      baked[oi] = 1
    }
  }
  tris++
}

// 往 UV 岛的空隙扩几圈颜色，避免 mipmap/双线性采到黑边
for (let iter = 0; iter < DILATE; iter++) {
  const add = []
  for (let y = 1; y < H - 1; y++) {
    for (let x = 1; x < W - 1; x++) {
      const i = y * W + x
      if (baked[i]) continue
      let r = 0, g = 0, b = 0, n = 0
      for (const [dx, dy] of [[-1, 0], [1, 0], [0, -1], [0, 1]]) {
        const ni = i + dy * W + dx
        if (!baked[ni]) continue
        r += out[ni * 4]; g += out[ni * 4 + 1]; b += out[ni * 4 + 2]; n++
      }
      if (n) add.push([i, Math.round(r / n), Math.round(g / n), Math.round(b / n)])
    }
  }
  for (const [i, r, g, b] of add) {
    out[i * 4] = r; out[i * 4 + 1] = g; out[i * 4 + 2] = b; out[i * 4 + 3] = 255
    baked[i] = 2
  }
  for (let i = 0; i < W * H; i++) if (baked[i] === 2) baked[i] = 1
}

const outName = `${NAME}-atlas-${path.basename(dataDir)}.png`
const outPath = path.join(dataDir, 'ai', outName)
fs.writeFileSync(outPath, encodePng(W, H, out))

const aiDef = JSON.parse(JSON.stringify(def))
aiDef.textures = [`ai/${outName}`]
aiDef.ai = {
  kind: 'atlas-bake',
  source: CHAR,
  view: path.basename(dataDir),
  aiSource: AI,
  texture: `ai/${outName}`,
  baseTexture: def.textures[0],
  outputSize: [W, H],
  generatedAt: new Date().toISOString()
}
const aiJsonPath = path.join(dataDir, 'characters-ai.json')
const aiJson = fs.existsSync(aiJsonPath) ? JSON.parse(fs.readFileSync(aiJsonPath, 'utf8')) : { characters: {} }
aiJson.characters[NAME] = aiDef
fs.writeFileSync(aiJsonPath, JSON.stringify(aiJson))

fs.writeFileSync(path.join(dataDir, 'ai', `${NAME}-${path.basename(dataDir)}.json`), JSON.stringify({
  name: NAME, source: CHAR, view: path.basename(dataDir), aiSource: AI,
  baseTexture: def.textures[0], atlas: path.relative(process.cwd(), outPath),
  size: [W, H], triangles: tris, generatedAt: new Date().toISOString()
}, null, 2))

console.log(`${CHAR} → ${NAME}: 烘焙 ${tris} 个三角面 / ${W}x${H} → ${path.relative(process.cwd(), outPath)}`)
console.log('  角色已写入', path.relative(process.cwd(), aiJsonPath))
