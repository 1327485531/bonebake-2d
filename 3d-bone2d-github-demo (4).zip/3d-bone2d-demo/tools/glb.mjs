// 极简 GLB / glTF 2.0 读取器（零依赖）
// 只实现我们做 3D→2D 转换真正需要的那部分：节点树、skin、mesh(含 UV/权重)、animation、纹理。
import fs from 'node:fs'

const COMPONENT = {
  5120: Int8Array,
  5121: Uint8Array,
  5122: Int16Array,
  5123: Uint16Array,
  5125: Uint32Array,
  5126: Float32Array
}
const NUM_COMPONENTS = { SCALAR: 1, VEC2: 2, VEC3: 3, VEC4: 4, MAT2: 4, MAT3: 9, MAT4: 16 }

/** 解析一个 .glb 文件，返回 { json, bin } */
export function readGlb (file) {
  const buf = fs.readFileSync(file)
  const dv = new DataView(buf.buffer, buf.byteOffset, buf.byteLength)
  const magic = dv.getUint32(0, true)
  if (magic !== 0x46546c67) throw new Error('不是 GLB 文件: ' + file)
  const total = dv.getUint32(8, true)
  let offset = 12
  let json = null
  let bin = null
  while (offset < total) {
    const len = dv.getUint32(offset, true)
    const type = dv.getUint32(offset + 4, true)
    const start = offset + 8
    if (type === 0x4e4f534a) {
      json = JSON.parse(new TextDecoder().decode(buf.subarray(start, start + len)))
    } else if (type === 0x004e4942) {
      bin = buf.subarray(start, start + len)
    }
    offset = start + len + ((4 - (len % 4)) % 4)
  }
  if (!json) throw new Error('GLB 里没有 JSON chunk')
  return { json, bin }
}

/** 读取 accessor，返回扁平的 number[]（自动处理 byteStride / 交错缓冲） */
export function readAccessor (gltf, bin, index) {
  const acc = gltf.accessors[index]
  const n = NUM_COMPONENTS[acc.type]
  const Arr = COMPONENT[acc.componentType]
  if (!Arr) throw new Error('未知 componentType ' + acc.componentType)
  const out = new Array(acc.count * n)
  if (acc.bufferView === undefined) return out // 全 0（稀疏 accessor 的常见简写）

  const bv = gltf.bufferViews[acc.bufferView]
  const base = (bv.byteOffset || 0) + (acc.byteOffset || 0)
  const stride = bv.byteStride || 0
  const elemSize = Arr.BYTES_PER_ELEMENT * n
  const dv = new DataView(bin.buffer, bin.byteOffset, bin.byteLength)

  for (let i = 0; i < acc.count; i++) {
    const off = base + (stride ? i * stride : i * elemSize)
    for (let c = 0; c < n; c++) {
      const o = off + c * Arr.BYTES_PER_ELEMENT
      let v
      switch (acc.componentType) {
        case 5120: v = dv.getInt8(o); break
        case 5121: v = dv.getUint8(o); break
        case 5122: v = dv.getInt16(o, true); break
        case 5123: v = dv.getUint16(o, true); break
        case 5125: v = dv.getUint32(o, true); break
        default: v = dv.getFloat32(o, true)
      }
      out[i * n + c] = v
    }
  }
  if (acc.normalized) {
    const div = acc.componentType === 5121 ? 255 : acc.componentType === 5123 ? 65535 : 1
    if (div !== 1) for (let i = 0; i < out.length; i++) out[i] /= div
  }
  return out
}

/** glTF 节点默认 TRS */
export function nodeTRS (node) {
  if (node.matrix) return { matrix: node.matrix }
  return {
    translation: node.translation || [0, 0, 0],
    rotation: node.rotation || [0, 0, 0, 1],
    scale: node.scale || [1, 1, 1]
  }
}

// ---------- 4x4 矩阵工具（列主序，和 glTF 一致） ----------
export function mat4Identity () {
  return [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1]
}
export function mat4Multiply (a, b) {
  const o = new Array(16)
  for (let c = 0; c < 4; c++) {
    for (let r = 0; r < 4; r++) {
      o[c * 4 + r] = a[r] * b[c * 4] + a[4 + r] * b[c * 4 + 1] + a[8 + r] * b[c * 4 + 2] + a[12 + r] * b[c * 4 + 3]
    }
  }
  return o
}
export function mat4FromTRS (t, q, s) {
  const [x, y, z, w] = q
  const x2 = x + x, y2 = y + y, z2 = z + z
  const xx = x * x2, xy = x * y2, xz = x * z2
  const yy = y * y2, yz = y * z2, zz = z * z2
  const wx = w * x2, wy = w * y2, wz = w * z2
  const [sx, sy, sz] = s
  return [
    (1 - (yy + zz)) * sx, (xy + wz) * sx, (xz - wy) * sx, 0,
    (xy - wz) * sy, (1 - (xx + zz)) * sy, (yz + wx) * sy, 0,
    (xz + wy) * sz, (yz - wx) * sz, (1 - (xx + yy)) * sz, 0,
    t[0], t[1], t[2], 1
  ]
}
export function mat4GetTranslation (m) {
  return [m[12], m[13], m[14]]
}
/** 取出矩阵的旋转部分，转成四元数 */
export function mat4ToQuat (m) {
  const m00 = m[0], m01 = m[4], m02 = m[8]
  const m10 = m[1], m11 = m[5], m12 = m[9]
  const m20 = m[2], m21 = m[6], m22 = m[10]
  const trace = m00 + m11 + m22
  if (trace > 0) {
    const s = 0.5 / Math.sqrt(trace + 1)
    return [(m21 - m12) * s, (m02 - m20) * s, (m10 - m01) * s, 0.25 / s]
  }
  if (m00 > m11 && m00 > m22) {
    const s = 2 * Math.sqrt(1 + m00 - m11 - m22)
    return [0.25 * s, (m01 + m10) / s, (m02 + m20) / s, (m21 - m12) / s]
  }
  if (m11 > m22) {
    const s = 2 * Math.sqrt(1 + m11 - m00 - m22)
    return [(m01 + m10) / s, 0.25 * s, (m12 + m21) / s, (m02 - m20) / s]
  }
  const s = 2 * Math.sqrt(1 + m22 - m00 - m11)
  return [(m02 + m20) / s, (m12 + m21) / s, 0.25 * s, (m10 - m01) / s]
}

// ---------- 语义化封装 ----------

/** 建立每个节点的父索引表 */
export function buildParentMap (gltf) {
  const parent = new Array(gltf.nodes.length).fill(-1)
  gltf.nodes.forEach((n, i) => {
    for (const c of n.children || []) parent[c] = i
  })
  return parent
}

/**
 * 计算某个节点在给定"节点本地变换覆盖"下的世界矩阵。
 * localOverrides: Map<nodeIndex, {translation,rotation,scale}>，用于播放动画。
 */
export function computeWorld (gltf, parentMap, nodeIndex, localOverrides, cache = new Map()) {
  if (cache.has(nodeIndex)) return cache.get(nodeIndex)
  const node = gltf.nodes[nodeIndex]
  const ov = localOverrides.get(nodeIndex)
  let local
  if (ov) {
    local = mat4FromTRS(ov.translation, ov.rotation, ov.scale)
  } else if (node.matrix) {
    local = node.matrix.slice()
  } else {
    const t = node.translation || [0, 0, 0]
    const r = node.rotation || [0, 0, 0, 1]
    const s = node.scale || [1, 1, 1]
    local = mat4FromTRS(t, r, s)
  }
  const p = parentMap[nodeIndex]
  if (p === -1) {
    cache.set(nodeIndex, local)
    return local
  }
  const world = mat4Multiply(computeWorld(gltf, parentMap, p, localOverrides, cache), local)
  cache.set(nodeIndex, world)
  return world
}

/** 找出所有 skin 的关节节点索引（joints 数组） */
export function skinJointSet (gltf) {
  const s = new Set()
  for (const skin of gltf.skins || []) for (const j of skin.joints) s.add(j)
  return s
}

/** 列出 glTF 的全部动画名 */
export function animationNames (gltf) {
  return (gltf.animations || []).map((a, i) => a.name || `anim_${i}`)
}