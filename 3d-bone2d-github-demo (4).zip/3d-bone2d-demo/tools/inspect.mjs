// 检查 GLB：节点树 / 骨骼 / 蒙皮 / UV / 动画 / 纹理
// 用法: node tools/inspect.mjs <file.glb> [--bones] [--anim <name>] [--tree]
import { readGlb, readAccessor, buildParentMap, skinJointSet, animationNames } from './glb.mjs'

const file = process.argv[2]
if (!file) { console.error('用法: node tools/inspect.mjs <file.glb>'); process.exit(1) }
const flags = new Set(process.argv.slice(3))

const { json: g, bin } = readGlb(file)
const parentMap = buildParentMap(g)

console.log('文件:', file)
console.log('generator:', g.asset?.generator, '| version', g.asset?.version)
console.log('nodes:', g.nodes.length, '| meshes:', (g.meshes || []).length,
  '| skins:', (g.skins || []).length, '| animations:', (g.animations || []).length,
  '| materials:', (g.materials || []).length, '| textures:', (g.textures || []).length,
  '| images:', (g.images || []).length)

const joints = skinJointSet(g)
console.log('\n=== SKINS ===')
;(g.skins || []).forEach((s, i) => {
  console.log(`  skin[${i}] name=${s.name || '-'} joints=${s.joints.length} skeleton=${s.skeleton ?? '-'}`)
  const roots = s.joints.filter(j => !joints.has(parentMap[j]) || parentMap[j] === -1)
  console.log('    骨骼根:', roots.map(r => `${r}:${g.nodes[r].name}`).join(', '))
})

console.log('\n=== MESHES ===')
;(g.meshes || []).forEach((m, mi) => {
  m.primitives.forEach((p, pi) => {
    const attrs = Object.keys(p.attributes)
    const posAcc = g.accessors[p.attributes.POSITION]
    console.log(`  mesh[${mi}] "${m.name || '-'}" prim[${pi}] verts=${posAcc.count} tris=${p.indices !== undefined ? g.accessors[p.indices].count / 3 : '-'}`)
    console.log(`     attrs: ${attrs.join(', ')}`)
    console.log(`     material=${p.material ?? '-'}${p.material !== undefined ? ' (' + (g.materials[p.material].name || '') + ')' : ''}  mode=${p.mode ?? 4}`)
    if (p.attributes.POSITION !== undefined) {
      const pos = readAccessor(g, bin, p.attributes.POSITION)
      const min = g.accessors[p.attributes.POSITION].min
      const max = g.accessors[p.attributes.POSITION].max
      if (min && max) console.log(`     bbox min=[${min.map(v => v.toFixed(3))}] max=[${max.map(v => v.toFixed(3))}]`)
    }
  })
})

console.log('\n=== 材质 / 贴图 ===')
;(g.materials || []).forEach((m, i) => {
  const pbr = m.pbrMetallicRoughness || {}
  const tex = pbr.baseColorTexture
  console.log(`  mat[${i}] "${m.name || '-'}" baseColorTex=${tex ? tex.index : '-'} factor=${pbr.baseColorFactor || '-'} doubleSided=${m.doubleSided || false}`)
})
;(g.images || []).forEach((im, i) => {
  const bv = im.bufferView !== undefined ? g.bufferViews[im.bufferView] : null
  console.log(`  img[${i}] "${im.name || '-'}" mime=${im.mimeType} bytes=${bv ? bv.byteLength : 'uri:' + im.uri}`)
})

console.log('\n=== NODE TREE ===')
const roots = g.nodes.map((_, i) => i).filter(i => parentMap[i] === -1)
const lines = []
function walk (i, depth) {
  const n = g.nodes[i]
  const tag = []
  if (joints.has(i)) tag.push('BONE')
  if (n.mesh !== undefined) tag.push('mesh' + n.mesh)
  if (n.skin !== undefined) tag.push('skin' + n.skin)
  const t = n.translation
  lines.push('  '.repeat(depth) + `[${i}] ${n.name || '-'} ${tag.join(' ')}` +
    (t ? `  t=[${t.map(v => +v.toFixed(3))}]` : ''))
  for (const c of n.children || []) walk(c, depth + 1)
}
if (flags.has('--tree')) {
  roots.forEach(r => walk(r, 0))
  console.log(lines.join('\n'))
  console.log('共', lines.length, '个节点')
} else {
  console.log('  (加 --tree 打印完整树)')
}

console.log('\n=== ANIMATIONS ===')
;(g.animations || []).forEach((a, i) => {
  let maxTime = 0
  const targets = new Set()
  const paths = {}
  for (const ch of a.channels) {
    targets.add(ch.target.node)
    paths[ch.target.path] = (paths[ch.target.path] || 0) + 1
    const sampler = a.samplers[ch.sampler]
    const inAcc = g.accessors[sampler.input]
    if (inAcc.max) maxTime = Math.max(maxTime, inAcc.max[0])
  }
  console.log(`  anim[${i}] "${a.name || '-'}" duration=${maxTime.toFixed(2)}s channels=${a.channels.length} 影响节点=${targets.size} ${JSON.stringify(paths)}`)
})

if (flags.has('--bones')) {
  console.log('\n=== BONE 层级 + 绑定姿态局部平移 ===')
  for (const skin of g.skins || []) {
    const set = new Set(skin.joints)
    const jroots = skin.joints.filter(j => !set.has(parentMap[j]) || parentMap[j] === -1)
    const rec = (i, d) => {
      const n = g.nodes[i]
      const t = n.translation || [0, 0, 0]
      console.log('  '.repeat(d) + `${n.name}  t=[${t.map(v => +v.toFixed(3))}]`)
      for (const c of n.children || []) if (set.has(c)) rec(c, d + 1)
    }
    jroots.forEach(r => rec(r, 1))
  }
}

if (flags.has('--anim') ) {
  const idx = process.argv.indexOf('--anim')
  const name = process.argv[idx + 1]
  const a = (g.animations || []).find((x, i) => (x.name || `anim_${i}`) === name)
  if (!a) { console.log('没找到动画', name); process.exit(0) }
  console.log(`\n=== 动画 "${name}" 的通道（前 40 条） ===`)
  a.channels.slice(0, 40).forEach((ch, i) => {
    const s = a.samplers[ch.sampler]
    const inAcc = g.accessors[s.input]
    console.log(`  [${i}] node=${ch.target.node}(${g.nodes[ch.target.node].name || '-'}) path=${ch.target.path} keys=${inAcc.count} interp=${s.interpolation || 'LINEAR'}`)
  })
}