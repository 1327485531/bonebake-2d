#!/usr/bin/env python3
"""零依赖本地静态服务器（Windows 上用 python -m http.server 时，.js 可能被注册表映射成 text/plain，
导致浏览器拒绝加载 ES module）。用法：python tools/serve.py
"""
import http.server
import mimetypes
import os
import socketserver

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
os.chdir(ROOT)

# 关键：Windows 的 mimetypes 会读注册表，.js 可能是 text/plain；
# 这里显式覆盖，保证 module script 的严格 MIME 检查通过。
MIME = {
    ".html": "text/html; charset=utf-8",
    ".js": "text/javascript; charset=utf-8",
    ".mjs": "text/javascript; charset=utf-8",
    ".css": "text/css; charset=utf-8",
    ".json": "application/json; charset=utf-8",
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".webp": "image/webp",
    ".svg": "image/svg+xml",
    ".woff2": "font/woff2",
    ".woff": "font/woff",
    ".ico": "image/x-icon",
}
for ext, typ in MIME.items():
    mimetypes.add_type(typ.split(";")[0], ext)


class Handler(http.server.SimpleHTTPRequestHandler):
    extensions_map = {
        **http.server.SimpleHTTPRequestHandler.extensions_map,
        **MIME,
    }

    def end_headers(self):
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-3D-Bone2D-Server", "python")
        super().end_headers()

    def do_GET(self):
        if self.path == "/__server":
            body = ('{"server":"python","jsMime":"text/javascript; charset=utf-8"}').encode()
            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return
        super().do_GET()


class Server(socketserver.ThreadingTCPServer):
    allow_reuse_address = True


if __name__ == "__main__":
    port = int(os.environ.get("PORT", "8899"))
    host = os.environ.get("HOST", "127.0.0.1")
    httpd = None
    for try_port in range(port, port + 11):
        try:
            httpd = Server((host, try_port), Handler)
            port = try_port
            break
        except OSError:
            print(f"端口 {try_port} 被占用，试 {try_port + 1}...")
    if httpd is None:
        raise SystemExit("找不到可用端口")
    print(f"3d-bone2d demo: http://{host}:{port}/web/index.html")
    print(f"服务器标识: http://{host}:{port}/__server")
    print("Ctrl+C 停止")
    with httpd:
        httpd.serve_forever()
