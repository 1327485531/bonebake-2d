// 可视化手绘皮肤导入器：本地 HTTP 服务 + 上传 sheet/6 块图 + 调 import-part-drawing.mjs。
//
// 只绑定 127.0.0.1，无外部依赖。默认 8898：
//   node tools/import-ui-server.mjs
//   http://127.0.0.1:8898/
//
// 前端：web/import.html + web/import.js
// 处理：复用 tools/import-part-drawing.mjs（--no-build 先预览，再构建）
import fs from 'node:fs'
import path from 'node:path'
import http from 'node:http'
import crypto from 'node:crypto'
import { execFile } from 'node:child_process'

const ROOT = process.cwd()
const PORT = Number(process.env.IMPORT_UI_PORT || 8898)
const HOST = '127.0.0.1'
const GROUP_ORDER = ['head', 'torso', 'arm_l', 'arm_r', 'leg_l', 'leg_r']
const MAX_BODY = 40 * 1024 * 1024
const previews = new Map()

if (!fs.existsSync(path.join(ROOT, 'tools', 'import-part-drawing.mjs'))) {
  console.error('请在工程根目录运行：node tools/import-ui-server.mjs')
  process.exit(1)
}
if (!Number.isInteger(PORT) || PORT < 1 || PORT > 65535) {
  console.error('IMPORT_UI_PORT 不合法')
  process.exit(1)
}

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.png': 'image/png',
  '.json': 'application/json; charset=utf-8',
  '.woff2': 'font/woff2',
  '.txt': 'text/plain; charset=utf-8',
  '.md': 'text/plain; charset=utf-8'
}

function json (res, code, obj) {
  const body = Buffer.from(JSON.stringify(obj))
  res.writeHead(code, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': body.length,
    'Cache-Control': 'no-store'
  })
  res.end(body)
}

function safeJoin (root, rel) {
  const p = path.resolve(root, '.' + rel)
  if (p !== root && !p.startsWith(root + path.sep)) return null
  return p
}

function sendFile (res, file) {
  fs.readFile(file, (err, buf) => {
    if (err) { json(res, 404, { ok: false, error: '文件不存在' }); return }
    const ext = path.extname(file).toLowerCase()
    res.writeHead(200, {
      'Content-Type': MIME[ext] || 'application/octet-stream',
      'Content-Length': buf.length,
      'Cache-Control': 'no-store'
    })
    res.end(buf)
  })
}

function readBody (req) {
  return new Promise((resolve, reject) => {
    let size = 0
    const chunks = []
    req.on('data', c => {
      size += c.length
      if (size > MAX_BODY) { reject(new Error('请求太大（>40MB）')); req.destroy(); return }
      chunks.push(c)
    })
    req.on('end', () => {
      try { resolve(chunks.length ? JSON.parse(Buffer.concat(chunks).toString('utf8')) : {}) } catch (e) { reject(new Error('JSON 解析失败')) }
    })
    req.on('error', reject)
  })
}

function decodePngDataUrl (s) {
  const m = /^data:image\/png;base64,([A-Za-z0-9+/=\s]+)$/.exec(String(s || ''))
  if (!m) throw new Error('只接受 PNG（data:image/png;base64,...）')
  const buf = Buffer.from(m[1], 'base64')
  if (buf.length < 8 || buf.readUInt32BE(0) !== 0x89504e47) throw new Error('不是有效 PNG')
  return buf
}

function checkName (name) {
  if (!/^[A-Za-z0-9_-]{1,40}$/.test(name || '')) throw new Error('角色名只能包含字母/数字/_-，1..40 字符')
}

function viewOk (view) {
  if (!['side', 'front'].includes(view)) throw new Error('view 只能是 side / front')
}

function characterExists (view, name) {
  // characters.json 是烘焙的基础角色；characters-ai.json 是 AI/手绘角色。
  // 两边都查，避免手滑用 male / zombie 这种名字把基础角色盖掉。
  for (const file of ['characters.json', 'characters-ai.json']) {
    const p = path.join(ROOT, 'out', view, file)
    if (!fs.existsSync(p)) continue
    try {
      const j = JSON.parse(fs.readFileSync(p, 'utf8'))
      if (j.characters && j.characters[name]) return true
    } catch {}
  }
  return false
}

function runNode (args, timeout = 180000) {
  return new Promise(resolve => {
    execFile(process.execPath, args, {
      cwd: ROOT,
      timeout,
      maxBuffer: 20 * 1024 * 1024,
      env: process.env
    }, (err, stdout, stderr) => {
      resolve({
        code: err ? (typeof err.code === 'number' ? err.code : 1) : 0,
        stdout: stdout || '',
        stderr: stderr || ''
      })
    })
  })
}

function sessionDir () {
  const d = path.join(ROOT, 'out', 'import-ui', `${Date.now()}-${crypto.randomBytes(3).toString('hex')}`)
  fs.mkdirSync(d, { recursive: true })
  return d
}

async function handlePreview (req, res) {
  let body
  try { body = await readBody(req) } catch (e) { json(res, 413, { ok: false, error: e.message }); return }
  try {
    const view = body.view
    const name = body.name
    const mode = body.mode
    const keepGuide = !!body.keepGuide
    const overwrite = !!body.overwrite
    viewOk(view); checkName(name)
    if (!['sheet', 'parts'].includes(mode)) throw new Error('mode 只能是 sheet / parts')
    if (characterExists(view, name) && !overwrite) {
      json(res, 409, { ok: false, error: `角色 ${name} 已存在；勾选“允许覆盖同名角色”或换个名字` })
      return
    }

    const dir = sessionDir()
    let args
    if (mode === 'sheet') {
      const sheet = path.join(dir, 'sheet.png')
      fs.writeFileSync(sheet, decodePngDataUrl(body.sheet))
      args = ['tools/import-part-drawing.mjs', '--view', view, '--name', name, '--sheet', sheet, '--no-build']
    } else {
      const parts = body.parts || {}
      for (const g of GROUP_ORDER) {
        if (!parts[g]) throw new Error(`缺少 ${g} 的图`)
        fs.writeFileSync(path.join(dir, `${g}-${view}.png`), decodePngDataUrl(parts[g]))
      }
      args = ['tools/import-part-drawing.mjs', '--view', view, '--name', name, '--dir', dir, '--no-build']
    }
    if (keepGuide) args.push('--keep-guide')

    const out = await runNode(args)
    const log = out.stdout + out.stderr
    if (out.code !== 0) {
      json(res, 400, { ok: false, error: '处理失败，详见日志', log })
      return
    }

    const partsDir = path.join(ROOT, 'out', view, 'ai', 'parts')
    const preview = []
    for (const g of GROUP_ORDER) {
      const p = path.join(partsDir, `${name}-${g}-${view}.png`)
      if (!fs.existsSync(p)) throw new Error(`处理成功但缺少 ${p}`)
      preview.push({
        group: g,
        png: 'data:image/png;base64,' + fs.readFileSync(p).toString('base64')
      })
    }
    const token = crypto.randomBytes(12).toString('hex')
    previews.set(token, { view, name, ts: Date.now() })
    json(res, 200, { ok: true, token, parts: preview, log })
  } catch (e) {
    json(res, 400, { ok: false, error: e.message })
  }
}

async function handleBuild (req, res) {
  let body
  try { body = await readBody(req) } catch (e) { json(res, 413, { ok: false, error: e.message }); return }
  try {
    const { token, view, name } = body
    const headScale = Number(body.headScale || 1)
    const overwrite = !!body.overwrite
    viewOk(view); checkName(name)
    const pv = previews.get(token)
    if (!pv || pv.view !== view || pv.name !== name) throw new Error('预览已失效，请先点“预览 6 块”')
    if (!Number.isFinite(headScale) || headScale < 0.5 || headScale > 3) throw new Error('头放大倍数不合法')
    if (characterExists(view, name) && !overwrite) {
      json(res, 409, { ok: false, error: `角色 ${name} 已存在；勾选“允许覆盖同名角色”或换个名字` })
      return
    }
    for (const g of GROUP_ORDER) {
      const p = path.join(ROOT, 'out', view, 'ai', 'parts', `${name}-${g}-${view}.png`)
      if (!fs.existsSync(p)) throw new Error(`缺少 ${name}-${g}-${view}.png，请重新预览`)
    }

    const args = ['tools/ai-skin-parts.mjs', '--char', 'male', '--name', name, '--views', view, '--source', 'custom']
    if (view === 'side') args.push('--pose', 'Walk', '--pose-frame', '0', '--pose-groups', 'arm_l,arm_r')
    if (headScale !== 1) args.push('--head-scale', String(headScale))
    const out = await runNode(args)
    const log = out.stdout + out.stderr
    if (out.code !== 0) {
      json(res, 500, { ok: false, error: '构建失败，详见日志', log })
      return
    }
    const atlasFile = path.join(ROOT, 'out', view, 'ai', `${name}-atlas-${view}.png`)
    if (!fs.existsSync(atlasFile)) throw new Error('构建成功但没找到图集')
    json(res, 200, {
      ok: true,
      log,
      atlas: `/out/${view}/ai/${name}-atlas-${view}.png?t=${Date.now()}`,
      demo: `http://127.0.0.1:8899/web/index.html?view=${view}&char=${name}&clip=Walk&frame=0&play=0&bones=0`
    })
  } catch (e) {
    json(res, 400, { ok: false, error: e.message })
  }
}

const server = http.createServer(async (req, res) => {
  const u = new URL(req.url, `http://${HOST}:${PORT}`)
  const p = decodeURIComponent(u.pathname)
  try {
    if (req.method === 'GET' && (p === '/' || p === '/index.html' || p === '/import.html')) {
      // 注入一个标记，前端据此进入“服务模式”，不用去探测 /api/health（静态模式就不会有 404）
      const html = fs.readFileSync(path.join(ROOT, 'web', 'import.html'), 'utf8')
        .replace('</head>', '<script>window.__IMPORT_UI_SERVER__=true</script></head>')
      const body = Buffer.from(html)
      res.writeHead(200, {
        'Content-Type': 'text/html; charset=utf-8',
        'Content-Length': body.length,
        'Cache-Control': 'no-store'
      })
      res.end(body); return
    }
    if (req.method === 'GET' && p === '/import.js') {
      sendFile(res, path.join(ROOT, 'web', 'import.js')); return
    }
    if (req.method === 'GET' && p === '/offline-build.js') {
      sendFile(res, path.join(ROOT, 'web', 'offline-build.js')); return
    }
    if (req.method === 'GET' && p === '/studio.html') {
      sendFile(res, path.join(ROOT, 'web', 'studio.html')); return
    }
    if (req.method === 'GET' && p === '/studio-data.js') {
      sendFile(res, path.join(ROOT, 'web', 'studio-data.js')); return
    }
    if (req.method === 'GET' && p === '/generate.html') {
      sendFile(res, path.join(ROOT, 'web', 'generate.html')); return
    }
    if (req.method === 'GET' && p === '/generate.js') {
      sendFile(res, path.join(ROOT, 'web', 'generate.js')); return
    }
    if (req.method === 'GET' && p.startsWith('/fonts/')) {
      const f = safeJoin(path.join(ROOT, 'web', 'fonts'), p.slice('/fonts'.length))
      if (!f) { json(res, 403, { ok: false, error: 'forbidden' }); return }
      sendFile(res, f); return
    }
    if (req.method === 'GET' && p.startsWith('/templates/')) {
      const f = safeJoin(path.join(ROOT, 'templates'), p.slice('/templates'.length))
      if (!f) { json(res, 403, { ok: false, error: 'forbidden' }); return }
      sendFile(res, f); return
    }
    if (req.method === 'GET' && p.startsWith('/out/')) {
      const f = safeJoin(path.join(ROOT, 'out'), p.slice('/out'.length))
      if (!f) { json(res, 403, { ok: false, error: 'forbidden' }); return }
      sendFile(res, f); return
    }
    if (req.method === 'GET' && p === '/api/health') {
      json(res, 200, { ok: true, port: PORT, previews: previews.size }); return
    }
    if (req.method === 'POST' && p === '/api/preview') {
      await handlePreview(req, res); return
    }
    if (req.method === 'POST' && p === '/api/build') {
      await handleBuild(req, res); return
    }
    json(res, 404, { ok: false, error: 'not found' })
  } catch (e) {
    console.error(e)
    json(res, 500, { ok: false, error: e.message })
  }
})

server.listen(PORT, HOST, () => {
  console.log(`手绘皮肤导入器: http://${HOST}:${PORT}/`)
  console.log('模板: /templates/side/sheet.png  /templates/front/sheet.png')
  console.log('构建结果会写入 out/<view>/ai/，演示页仍在 http://127.0.0.1:8899/')
})
