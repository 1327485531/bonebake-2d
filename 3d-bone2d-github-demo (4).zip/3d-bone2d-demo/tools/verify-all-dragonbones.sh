#!/usr/bin/env bash
# 逐个角色用官方 DragonBones 运行时校验导出结果（默认 side front 两个视角）。
# 用法: ./tools/verify-all-dragonbones.sh [side] [front]
set -uo pipefail
cd "$(dirname "$0")/.."

VIEWS=("$@")
[ ${#VIEWS[@]} -eq 0 ] && VIEWS=(side front)
fail=0

for VIEW in "${VIEWS[@]}"; do
  [ -f "out/$VIEW/characters.json" ] || { echo "缺少 out/$VIEW/characters.json"; exit 1; }
  chars=$(node -e "console.log(Object.keys(require('./out/$VIEW/characters.json').characters).join(' '))")
  echo "===== 校验 $VIEW ====="
  for c in $chars; do
    log="/tmp/verify-db-$VIEW-$c.log"
    if node tools/verify-dragonbones.mjs --db "out/$VIEW/dragonbones/$c.json" --data "out/$VIEW" --char "$c" > "$log" 2>&1; then
      echo "  ✔ $c"
    else
      echo "  ✘ $c  （详见 $log）"
      fail=1
    fi
  done
done

echo
[ $fail -eq 0 ] && echo "✔ 全部角色通过" || echo "✘ 有角色未通过"
exit $fail
