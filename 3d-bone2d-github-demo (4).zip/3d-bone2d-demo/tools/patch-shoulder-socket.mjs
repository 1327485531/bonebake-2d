// 补侧视躯干贴图的“肩窝黑洞”。
//
// 背景：ai_ronin_v5 的侧视 torso 是从“没有手臂的 torso 参考图”生成的，AI 把肩窝画成了
// 一整块黑色。手臂前摆时肩球让开，黑洞露出来，看起来像肩膀皮肤被拉走。
// 权重修复解决的是 torso 被 upperarm 拖动；这个脚本只补贴图，让露出的肩窝变成
// 暗色机械内衬 + 金属圈，不再像破洞/拉丝。
//
// 用法：
//   node tools/patch-shoulder-socket.mjs
//   node tools/patch-shoulder-socket.mjs --file out/side/ai/parts/ai_ronin_v5-torso-side.png
//   node tools/patch-shoulder-socket.mjs --center 82,228 --radius 64 --rebuild
//
// --rebuild 会调用 ai-skin-parts --source custom 重建 side 的 ai_ronin_v5。
// 注意：这是针对 v5 侧视 torso 的坐标；换角色/换图要重新量 center/radius。
import fs from 'node:fs'
import path from 'node:path'
import { spawnSync } from 'node:child_process'
import { decodePng, encodePng } from './ai-image.mjs'

const argv = process.argv.slice(2)
const opt = (n, d) => { const i = argv.indexOf('--' + n); return i === -1 ? d : argv[i + 1] }
const has = (n) => argv.includes('--' + n)

const FILE = path.resolve(opt('file', 'out/side/ai/parts/ai_ronin_v5-torso-side.png'))
const NAME = opt('name', 'ai_ronin_v5')
const CHAR = opt('char', 'male')
const VIEW = opt('view', 'side')
const [CX, CY] = opt('center', '82,228').split(',').map(Number)
const R = Number(opt('radius', '64'))
const REBUILD = has('rebuild')

if (!fs.existsSync(FILE)) throw new Error('找不到贴图: ' + FILE + '（先生成/构建角色）')
if (!(R > 4) || !Number.isFinite(CX) || !Number.isFinite(CY)) throw new Error('center/radius 不合法')

const img = decodePng(fs.readFileSync(FILE))
const { width: w, height: h, data } = img
let filled = 0
const isDark = (i) => data[i + 3] > 180 && data[i] < 40 && data[i + 1] < 45 && data[i + 2] < 45

for (let y = Math.max(0, CY - R); y <= Math.min(h - 1, CY + R); y++) {
  for (let x = Math.max(0, CX - R); x <= Math.min(w - 1, CX + R); x++) {
    const dx = x - CX, dy = y - CY
    const d = Math.hypot(dx, dy)
    if (d > R - 4) continue
    const i = (y * w + x) * 4
    if (!isDark(i)) continue
    if (d >= R - 9 && d <= R - 5) {
      // 金属圈：冷灰，略带明暗
      const ang = Math.atan2(dy, dx)
      const hi = 0.5 + 0.5 * Math.sin(ang * 8)
      const v = Math.round(70 + 35 * hi)
      data[i] = v - 12; data[i + 1] = v - 5; data[i + 2] = v - 2; data[i + 3] = 255
    } else {
      // 暗色机械内衬
      const t = Math.min(1, d / R)
      data[i] = Math.round(22 - 10 * t)
      data[i + 1] = Math.round(32 - 14 * t)
      data[i + 2] = Math.round(38 - 16 * t)
      data[i + 3] = 255
    }
    filled++
  }
}

if (!filled) {
  console.log('肩窝区域没有黑色像素；可能已经补过。')
  process.exit(0)
}

const bak = FILE + '.bak'
if (!fs.existsSync(bak)) fs.copyFileSync(FILE, bak)
fs.writeFileSync(FILE, encodePng(w, h, data))
console.log(`✔ 补肩窝：${filled} 像素 → ${FILE}（备份 ${path.basename(bak)}）`)

if (REBUILD) {
  const args = [
    'tools/ai-skin-parts.mjs',
    '--char', CHAR,
    '--name', NAME,
    '--views', VIEW,
    '--source', 'custom',
    ...(VIEW === 'side' ? ['--pose', 'Walk', '--pose-frame', '0', '--pose-groups', 'arm_l,arm_r'] : [])
  ]
  console.log('重建：node ' + args.join(' '))
  const r = spawnSync(process.execPath, args, { stdio: 'inherit' })
  if (r.status !== 0) process.exit(r.status || 1)
  console.log('✔ 重建完成；重新导出龙骨后生效。')
}
