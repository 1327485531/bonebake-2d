// 3D 骨骼动画 → 2D 骨骼动画 转换器
//
// 思路（详见 docs/研究报告.md）：
//   1. 骨架：取角色自己的 rest pose，把每根骨头的世界位置/朝向投影到 2D 平面 → 2D 绑定骨架
//   2. 网格：把绑定姿态的顶点投影到同一平面，保留 UV；蒙皮权重沿用 3D 里的（或后续自动计算）
//   3. 动画：逐帧算 3D 世界矩阵 → 投影 → 求 2D 局部变换（平移/旋转），平移按骨长归一化，
//      这样同一套动画可以套到任何共用该骨架的角色上
//   4. 深度：逐帧记录每根骨头到摄像机的深度，运行时用来做三角面排序（2D 里的"前后遮挡"）
//
// 用法:
//   node tools/convert.mjs --anim <anim.glb> --clips Idle,Walk --view side \
//        --char male=<male.glb> --char monster=<monster.glb> --out out/
import fs from 'node:fs'
import path from 'node:path'
import {
  readGlb, readAccessor, buildParentMap, computeWorld, mat4GetTranslation,
  mat4Multiply, mat4FromTRS, nodeTRS
} from './glb.mjs'
import { autoSkin } from './autoskin.mjs'
import { buildBoneMap, summarizeMapping } from './bonemap.mjs'

// ---------------- 参数解析 ----------------
const argv = process.argv.slice(2)
function opt (name, def) {
  const i = argv.indexOf('--' + name)
  return i === -1 ? def : argv[i + 1]
}
function optAll (name) {
  const out = []
  argv.forEach((a, i) => { if (a === '--' + name) out.push(argv[i + 1]) })
  return out
}

// ---------------- 投影视图 ----------------
// 世界坐标：Y 向上，角色面向 +Z，T-pose 手臂沿 ±X
// 返回 { sx(p), sy(p), depth(p) }，其中 depth 升序 = 由远及近
const VIEWS = {
  // 正面：摄像机在 +Z 看向 -Z。屏幕右 = +X，屏幕上 = +Y，远 = z 小
  front: { sx: p => p[0], sy: p => p[1], depth: p => p[2] },
  // 侧面朝右：摄像机在 -X 看向 +X。屏幕右 = +Z，远 = x 大
  side: { sx: p => p[2], sy: p => p[1], depth: p => -p[0] },
  // 侧面朝左
  sideL: { sx: p => -p[2], sy: p => p[1], depth: p => p[0] }
}

// ---------------- 数学小工具 ----------------
const EPS = 1e-4
function vlen (v) { return Math.hypot(v[0], v[1], v[2]) }
function sub3 (a, b) { return [a[0] - b[0], a[1] - b[1], a[2] - b[2]] }

/** 2D 仿射矩阵 [a,b,c,d,tx,ty] = [[a,c,tx],[b,d,ty]]，对应 R(θ) 旋转 */
function affineMul (A, B) {
  return [
    A[0] * B[0] + A[2] * B[1], A[1] * B[0] + A[3] * B[1],
    A[0] * B[2] + A[2] * B[3], A[1] * B[2] + A[3] * B[3],
    A[0] * B[4] + A[2] * B[5] + A[4], A[1] * B[4] + A[3] * B[5] + A[5]
  ]
}
function affineInv (M) {
  const det = M[0] * M[3] - M[1] * M[2]
  const id = 1 / (Math.abs(det) < 1e-12 ? 1e-12 : det)
  const a = M[3] * id, b = -M[1] * id, c = -M[2] * id, d = M[0] * id
  return [a, b, c, d, -(a * M[4] + c * M[5]), -(b * M[4] + d * M[5])]
}
function affineFrom (px, py, theta) {
  const c = Math.cos(theta), s = Math.sin(theta)
  return [c, s, -s, c, px, py]
}

/** 采样一个动画通道（LINEAR / STEP），返回插值结果 */
function sampleChannel (times, values, n, t, path, interp) {
  if (times.length === 0) return null
  if (t <= times[0]) return values.slice(0, n)
  if (t >= times[times.length - 1]) return values.slice((times.length - 1) * n, times.length * n)
  let lo = 0, hi = times.length - 1
  while (hi - lo > 1) { const m = (lo + hi) >> 1; if (times[m] <= t) lo = m; else hi = m }
  if (interp === 'STEP') return values.slice(lo * n, lo * n + n)
  const t0 = times[lo], t1 = times[hi]
  const a = (t - t0) / Math.max(1e-9, t1 - t0)
  const v0 = values.slice(lo * n, lo * n + n)
  const v1 = values.slice(hi * n, hi * n + n)
  if (path === 'rotation') {
    // 四元数球面插值
    let [x0, y0, z0, w0] = v0
    let [x1, y1, z1, w1] = v1
    let dot = x0 * x1 + y0 * y1 + z0 * z1 + w0 * w1
    if (dot < 0) { x1 = -x1; y1 = -y1; z1 = -z1; w1 = -w1; dot = -dot }
    if (dot > 0.9995) {
      const r = [x0 + (x1 - x0) * a, y0 + (y1 - y0) * a, z0 + (z1 - z0) * a, w0 + (w1 - w0) * a]
      return r
    }
    const th0 = Math.acos(Math.max(-1, Math.min(1, dot)))
    const th = th0 * a
    const s0 = Math.sin(th0 - th) / Math.sin(th0)
    const s1 = Math.sin(th) / Math.sin(th0)
    return [x0 * s0 + x1 * s1, y0 * s0 + y1 * s1, z0 * s0 + z1 * s1, w0 * s0 + w1 * s1]
  }
  return v0.map((v, i) => v + (v1[i] - v) * a)
}

/** 把动画文件的一个 clip 展开成 每节点每帧的本地 TRS */
function buildClipSampler (gltf, bin, clip) {
  const parentMap = buildParentMap(gltf)
  // nodeIndex -> { translation:{times,values}, rotation:..., scale:... }
  const tracks = new Map()
  let duration = 0
  for (const ch of clip.channels) {
    const s = clip.samplers[ch.sampler]
    const node = ch.target.node
    const times = readAccessor(gltf, bin, s.input)
    const n = ch.target.path === 'rotation' ? 4 : ch.target.path === 'translation' ? 3 : 3
    const values = readAccessor(gltf, bin, s.output)
    if (!tracks.has(node)) tracks.set(node, {})
    tracks.get(node)[ch.target.path] = { times, values, n, interp: s.interpolation || 'LINEAR' }
    duration = Math.max(duration, times[times.length - 1] || 0)
  }
  return { parentMap, tracks, duration }
}

function localOverridesAt (gltf, sampler, t) {
  const ov = new Map()
  for (const [node, tr] of sampler.tracks) {
    const base = nodeTRS(gltf.nodes[node])
    const res = {
      translation: base.translation || [0, 0, 0],
      rotation: base.rotation || [0, 0, 0, 1],
      scale: base.scale || [1, 1, 1]
    }
    if (tr.translation) {
      const v = sampleChannel(tr.translation.times, tr.translation.values, 3, t, 'translation', tr.translation.interp)
      if (v) res.translation = v
    }
    if (tr.rotation) {
      const v = sampleChannel(tr.rotation.times, tr.rotation.values, 4, t, 'rotation', tr.rotation.interp)
      if (v) res.rotation = v
    }
    if (tr.scale) {
      const v = sampleChannel(tr.scale.times, tr.scale.values, 3, t, 'scale', tr.scale.interp)
      if (v) res.scale = v
    }
    ov.set(node, res)
  }
  return ov
}

// ---------------- 骨架处理 ----------------
/**
 * 从 glb 里取出一个 skin 的骨架信息
 * 返回 { jointNodes, names, parentOf, restLocalT, restWorld, rootJoint }
 */
function readSkeleton (gltf, bin) {
  const skin = (gltf.skins || [])[0]
  if (!skin) return null
  const parentMap = buildParentMap(gltf)
  const jointNodes = skin.joints.slice()
  const names = jointNodes.map(j => gltf.nodes[j].name || ('node' + j))
  const nameToBone = new Map()
  names.forEach((n, i) => nameToBone.set(n, i))

  // 骨头的父骨头（在 joints 里找）
  const jointSet = new Map()
  jointNodes.forEach((j, i) => jointSet.set(j, i))
  const parentOf = jointNodes.map(j => {
    let p = parentMap[j]
    while (p !== -1 && !jointSet.has(p)) p = parentMap[p]
    return p === -1 ? -1 : jointSet.get(p)
  })

  // rest 世界矩阵
  const worldCache = new Map()
  const restWorld = jointNodes.map(j => computeWorld(gltf, parentMap, j, new Map(), worldCache))
  // rest 局部平移（3D，来自节点自身）
  const restLocalT = jointNodes.map((j, i) => {
    const w = mat4GetTranslation(restWorld[i])
    const p = parentOf[i]
    if (p === -1) return w
    return sub3(w, mat4GetTranslation(restWorld[p]))
  })
  // 3D 绑定骨长（视图无关）
  const restLen = restLocalT.map(t => vlen(t))

  return { jointNodes, names, nameToBone, parentOf, restLocalT, restWorld, restLen, skin, parentMap }
}

/**
 * 计算骨架在某一帧的 2D 全局变换 + 深度
 * @return { globals: number[][], depths: number[] }
 */
function poseTo2D (skeleton, worldMatrices, view) {
  const n = skeleton.names.length
  const globals = new Array(n)
  const depths = new Array(n)
  const thetas = new Array(n)
  const pos2 = new Array(n)

  for (let i = 0; i < n; i++) {
    const W = worldMatrices[i]
    const p = mat4GetTranslation(W)
    pos2[i] = [view.sx(p), view.sy(p)]
    depths[i] = view.depth(p)
    // 骨头自身 +Y 轴在世界空间的方向
    const axis = [W[4], W[5], W[6]]
    const A = [view.sx(axis), view.sy(axis)]
    const l = Math.hypot(A[0], A[1])
    if (l < EPS) thetas[i] = null // 与摄像机轴平行，退化，稍后回退
    else thetas[i] = Math.atan2(-A[0], A[1])
  }
  // 退化时回退到父骨朝向（自洽：子骨由自身投影位置推导，会自动补偿）
  for (let i = 0; i < n; i++) {
    if (thetas[i] === null) {
      let p = skeleton.parentOf[i]
      while (p !== -1 && thetas[p] === null) p = skeleton.parentOf[p]
      thetas[i] = p === -1 ? 0 : thetas[p]
    }
  }
  for (let i = 0; i < n; i++) globals[i] = affineFrom(pos2[i][0], pos2[i][1], thetas[i])
  return { globals, depths }
}

/** 由 2D 全局变换和父级全局变换求局部变换 */
function globalsToLocals (skeleton, globals) {
  const n = globals.length
  const locals = new Array(n)
  for (let i = 0; i < n; i++) {
    const p = skeleton.parentOf[i]
    locals[i] = p === -1 ? globals[i].slice() : affineMul(affineInv(globals[p]), globals[i])
  }
  return locals
}

/** 从局部仿射矩阵提取 (旋转, 平移) */
function decomposeLocal (M) {
  const theta = Math.atan2(M[1], M[0])
  return { theta, tx: M[4], ty: M[5] }
}

function round (v, d = 4) { const f = Math.pow(10, d); return Math.round(v * f) / f }

// ---------------- 主流程 ----------------
function main () {
  const viewName = opt('view', 'side')
  const view = VIEWS[viewName]
  if (!view) throw new Error('未知视图 ' + viewName)
  const fps = Number(opt('fps', 30))
  const outDir = opt('out', 'out')
  const charSpecs = optAll('char')
  const animFile = opt('anim', null)
  const clipsArg = opt('clips', null)
  const cull = argv.includes('--cull')
  fs.mkdirSync(outDir, { recursive: true })
  fs.mkdirSync(path.join(outDir, 'tex'), { recursive: true })

  // ---- 1. 动画 ----
  const animData = { format: 'm2d-anim', version: 1, view: viewName, fps, clips: {} }
  if (animFile) {
    const { json: ag, bin: ab } = readGlb(animFile)
    const skel = readSkeleton(ag, ab)
    if (!skel) throw new Error('动画文件里没有 skin')
    const allClips = (ag.animations || []).map((a, i) => a.name || ('anim_' + i))
    const want = clipsArg ? clipsArg.split(',').map(s => s.trim()).filter(Boolean) : allClips
    for (const clipName of want) {
      const idx = allClips.indexOf(clipName)
      if (idx === -1) { console.warn('  ! 找不到动画', clipName); continue }
      const clip = ag.animations[idx]
      const sampler = buildClipSampler(ag, ab, clip)
      const frames = Math.max(2, Math.round(sampler.duration * fps) + 1)
      const tracks = {}
      // 先算全部帧
      const perFrame = []
      for (let f = 0; f < frames; f++) {
        const t = Math.min(sampler.duration, (f / fps))
        const ov = localOverridesAt(ag, sampler, t)
        const wc = new Map()
        const worlds = skel.jointNodes.map(j => computeWorld(ag, sampler.parentMap, j, ov, wc))
        const { globals, depths } = poseTo2D(skel, worlds, view)
        const locals = globalsToLocals(skel, globals)
        perFrame.push({ locals: locals.map(decomposeLocal), depths })
      }
      // 归一化：平移 / 3D 骨长
      for (let i = 0; i < skel.names.length; i++) {
        const L = skel.restLen[i] || 1
        const arr = []
        for (let f = 0; f < frames; f++) {
          const d = perFrame[f].locals[i]
          arr.push(round(d.tx / L), round(d.ty / L), round(d.theta), round(perFrame[f].depths[i]))
        }
        tracks[skel.names[i]] = arr
      }
      animData.clips[clipName] = { duration: round(sampler.duration, 3), frames, bones: skel.names, tracks }
      console.log(`  动画 ${clipName}: ${frames} 帧 x ${skel.names.length} 骨`)
    }
  }

  // ---- 2. 角色 ----
  const charIndex = { format: 'm2d', version: 1, view: viewName, characters: {} }
  // 可选的外部骨架：给"没有蒙皮 / 想换骨架"的模型用
  const rigFile = opt('rig', null)
  let rigData = null
  if (rigFile) {
    const { json: rg, bin: rb } = readGlb(rigFile)
    const rigSkel = readSkeleton(rg, rb)
    if (!rigSkel) throw new Error('骨架文件里没有 skin: ' + rigFile)
    rigData = { gltf: rg, bin: rb, skel: rigSkel }
    console.log(`外部骨架: ${rigFile} (${rigSkel.names.length} 骨)`)
  }
  const forceReskin = argv.includes('--reskin')

  for (const spec of charSpecs) {
    const eq = spec.indexOf('=')
    const name = spec.slice(0, eq)
    const file = spec.slice(eq + 1)
    console.log(`角色 ${name} <- ${file}`)
    const { json: g, bin: b } = readGlb(file)
    const ownSkel = readSkeleton(g, b)

    // 决定用哪套骨架：模型自带 skin 就用它自己的；否则用 --rig 指定的骨架
    const skel = ownSkel || (rigData ? rigData.skel : null)
    if (!skel) {
      throw new Error(`角色文件里没有 skin，且没给 --rig：${file}`)
    }
    const skeletonFromRig = skel !== ownSkel
    // 模型顶点用它自己的节点树算世界坐标；骨架来自外部时，节点树也用外部的
    const srcGltf = skeletonFromRig ? rigData.gltf : g
    const srcBin = skeletonFromRig ? rigData.bin : b

    // 角色自己的绑定 2D 骨架
    const { globals: bindGlobals, depths: bindDepths } = poseTo2D(skel, skel.restWorld, view)
    const bindLocals = globalsToLocals(skel, bindGlobals)

    const bones = skel.names.map((bn, i) => {
      const d = decomposeLocal(bindLocals[i])
      return {
        name: bn,
        parent: skel.parentOf[i],
        x: round(d.tx), y: round(d.ty), rot: round(d.theta),
        len: round(skel.restLen[i])
      }
    })

    // 顶点 / UV / 权重
    const verts = [], uvs = [], skinIdx = [], skinW = [], parts = []
    const textures = []
    const texKeyToIdx = new Map()
    // 自动蒙皮需要先把顶点攒齐（世界坐标 + 三角面），最后一次性算权重
    const worldPositions = []
    const allTriangles = []

    const meshNodes = g.nodes.map((n, i) => n.mesh !== undefined ? i : -1).filter(i => i !== -1)
    const modelParentMap = buildParentMap(g)
    const worldCache = new Map()
    for (const mn of meshNodes) {
      const mesh = g.meshes[g.nodes[mn].mesh]
      // 注意：顶点用模型自己的节点树算世界坐标，骨架（可能是外部的）只提供骨头
      const mw = computeWorld(g, modelParentMap, mn, new Map(), worldCache)
      const normalMat = mw // 只用旋转部分做变换（缩放在这里可忽略）
      for (const prim of mesh.primitives) {
        const base = verts.length / 2
        const P = readAccessor(g, b, prim.attributes.POSITION)
        const hasNormal = prim.attributes.NORMAL !== undefined
        const N = hasNormal ? readAccessor(g, b, prim.attributes.NORMAL) : null
        const UV = prim.attributes.TEXCOORD_0 !== undefined ? readAccessor(g, b, prim.attributes.TEXCOORD_0) : null
        const J = prim.attributes.JOINTS_0 !== undefined ? readAccessor(g, b, prim.attributes.JOINTS_0) : null
        const Wt = prim.attributes.WEIGHTS_0 !== undefined ? readAccessor(g, b, prim.attributes.WEIGHTS_0) : null
        const useModelWeights = !skeletonFromRig && !forceReskin && J && Wt
        const count = P.length / 3
        const zs = new Float32Array(count)
        for (let v = 0; v < count; v++) {
          const x = P[v * 3], y = P[v * 3 + 1], z = P[v * 3 + 2]
          const wx = mw[0] * x + mw[4] * y + mw[8] * z + mw[12]
          const wy = mw[1] * x + mw[5] * y + mw[9] * z + mw[13]
          const wz = mw[2] * x + mw[6] * y + mw[10] * z + mw[14]
          verts.push(round(view.sx([wx, wy, wz])), round(view.sy([wx, wy, wz])))
          zs[v] = view.depth([wx, wy, wz])
          worldPositions.push(wx, wy, wz)
          // glTF 的 UV 原点在左上，和 WebGL 不翻转贴图时的采样约定一致，直接沿用
          if (UV) uvs.push(round(UV[v * 2], 5), round(UV[v * 2 + 1], 5))
          else uvs.push(0, 0)
          if (useModelWeights) {
            skinIdx.push(J[v * 4], J[v * 4 + 1], J[v * 4 + 2], J[v * 4 + 3])
            skinW.push(round(Wt[v * 4], 4), round(Wt[v * 4 + 1], 4),
              round(Wt[v * 4 + 2], 4), round(Wt[v * 4 + 3], 4))
          }
        }
        // 三角形。默认保留全部三角面（相当于"把 3D 压平"，前后两面靠深度排序解决遮挡，
        // 这样薄片/发片/平面也不会破洞）。加 --cull 则只留朝向摄像机的一面。
        const idx = readAccessor(g, b, prim.indices)
        const tris = []
        for (let t = 0; t < idx.length; t += 3) {
          const a = idx[t], bb = idx[t + 1], c = idx[t + 2]
          if (cull && N) {
            const nx = (N[a * 3] + N[bb * 3] + N[c * 3]) / 3
            const ny = (N[a * 3 + 1] + N[bb * 3 + 1] + N[c * 3 + 1]) / 3
            const nz0 = (N[a * 3 + 2] + N[bb * 3 + 2] + N[c * 3 + 2]) / 3
            const wnx = normalMat[0] * nx + normalMat[4] * ny + normalMat[8] * nz0
            const wny = normalMat[1] * nx + normalMat[5] * ny + normalMat[9] * nz0
            const wnz = normalMat[2] * nx + normalMat[6] * ny + normalMat[10] * nz0
            // depth 是线性泛函：depth(法线) < 0 表示法线朝摄像机
            if (view.depth([wnx, wny, wnz]) > 0.02) continue // 背面，剔除
          }
          const d = (zs[a] + zs[bb] + zs[c]) / 3
          tris.push([d, a, bb, c])
          allTriangles.push(base + a, base + bb, base + c)
        }
        tris.sort((p, q) => p[0] - q[0])
        const indices = []
        for (const t of tris) indices.push(t[1], t[2], t[3])

        // 贴图
        let texRef = null
        let color = [1, 1, 1, 1]
        const mat = prim.material !== undefined ? g.materials[prim.material] : null
        if (mat) {
          const pbr = mat.pbrMetallicRoughness || {}
          if (pbr.baseColorFactor) color = pbr.baseColorFactor
          if (pbr.baseColorTexture) {
            const texIdx = pbr.baseColorTexture.index
            const srcIdx = g.textures[texIdx].source
            const key = 'img' + srcIdx
            if (!texKeyToIdx.has(key)) {
              const im = g.images[srcIdx]
              const ext = (im.mimeType || 'image/png').includes('jpeg') ? 'jpg' : 'png'
              const fn = `${name}_${srcIdx}.${ext}`
              if (im.bufferView !== undefined) {
                const bv = g.bufferViews[im.bufferView]
                const data = b.slice(bv.byteOffset || 0, (bv.byteOffset || 0) + bv.byteLength)
                fs.writeFileSync(path.join(outDir, 'tex', fn), data)
              }
              texKeyToIdx.set(key, textures.length)
              textures.push('tex/' + fn)
            }
            texRef = texKeyToIdx.get(key)
          }
        }
        // depthOffsets 要等权重算完才能填，这里先占位
        parts.push({ base, count, indices, tex: texRef, color, _tris: tris })
      }
    }

    // ---- 自动蒙皮 ----
    let usedAutoSkin = false
    if (skinIdx.length === 0) {
      const t0 = Date.now()
      const res = autoSkin({
        positions: worldPositions,
        indices: allTriangles,
        boneWorld: skel.restWorld.map(m => mat4GetTranslation(m)),
        parentOf: skel.parentOf,
        names: skel.names
      })
      skinIdx.push(...res.skinIndices)
      skinW.push(...res.skinWeights)
      usedAutoSkin = true
      console.log(`  自动蒙皮: ${res.stats.vertices} 顶点 x ${res.stats.bones} 骨 ` +
        `(${Date.now() - t0}ms)，跳过 ${res.stats.skipped.length} 根骨(根/叶)`)
    }

    // ---- 算每个三角面相对骨骼的静止深度偏移 ----
    for (const part of parts) {
      const tris = part._tris
      delete part._tris
      const offs = []
      for (const t of tris) {
        const a = t[1], bb = t[2], c = t[3]
        let boneBindDepth = 0, wsum = 0
        for (const v of [a, bb, c]) {
          for (let k = 0; k < 4; k++) {
            const w = skinW[(part.base + v) * 4 + k]
            if (w <= 0) continue
            wsum += w
            boneBindDepth += w * bindDepths[skinIdx[(part.base + v) * 4 + k]]
          }
        }
        // 每个顶点权重和为 1，所以 wsum ≈ 3，boneBindDepth/wsum 就是"按骨骼算的静止深度"
        offs.push(round(t[0] - (wsum > 0 ? boneBindDepth / wsum : 0), 5))
      }
      part.depthOffsets = offs
    }

    charIndex.characters[name] = {
      source: path.basename(file),
      autoSkinned: usedAutoSkin,
      bones,
      mesh: { verts, uvs, skinIndices: skinIdx, skinWeights: skinW, parts },
      textures
    }
    console.log(`  骨骼 ${bones.length} 根 / 顶点 ${verts.length / 2} / 三角 ${parts.reduce((s, p) => s + p.indices.length / 3, 0)} / 贴图 ${textures.length}${usedAutoSkin ? ' / 自动蒙皮' : ''}`)
  }

  // ---- 3. 异构骨架重映射（可选）----
  // 给每个角色按"语义槽位"反查它需要的轨道；角色骨架与动画骨架完全一致时不需要。
  const remap = argv.includes('--remap')
  if (remap && animFile) {
    const { json: ag } = readGlb(animFile)
    const srcSkel = readSkeleton(ag, null)
    for (const [cname, ch] of Object.entries(charIndex.characters)) {
      const dstNames = ch.bones.map(b => b.name)
      const dstParent = ch.bones.map(b => b.parent)
      const { map } = buildBoneMap(srcSkel.names, srcSkel.parentOf, dstNames, dstParent)
      const info = summarizeMapping(srcSkel.names, dstNames, map)
      // 给每个 clip 生成目标骨架自己的 tracks
      for (const clip of Object.values(animData.clips)) {
        if (!clip._perChar) clip._perChar = {}
        const tracks = {}
        const srcTracks = clip.tracks
        for (let d = 0; d < dstNames.length; d++) {
          const si = map.get(d)
          if (si === undefined) {
            // 没有语义对应：该骨不参与动画（保持绑定姿态）
            continue
          }
          tracks[dstNames[d]] = srcTracks[srcSkel.names[si]]
        }
        clip._perChar[cname] = tracks
      }
      console.log(`  重映射 ${cname}: ${dstNames.length} 骨中 ${info.mappedCount} 根有对应` +
        (info.unmapped.length ? `，未对应 ${info.unmapped.length} 根` : ''))
    }
    // 把 perChar 轨道提到顶层，运行时按角色名取
    for (const clip of Object.values(animData.clips)) {
      if (clip._perChar) { clip.charTracks = clip._perChar; delete clip._perChar }
    }
  }

  fs.writeFileSync(path.join(outDir, 'anim.json'), JSON.stringify(animData))
  fs.writeFileSync(path.join(outDir, 'characters.json'), JSON.stringify(charIndex))
  console.log('写出:', path.join(outDir, 'anim.json'), path.join(outDir, 'characters.json'))
}

main()