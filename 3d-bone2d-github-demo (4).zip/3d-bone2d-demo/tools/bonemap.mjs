// 骨骼语义映射：把一套骨架的动画，映射到"骨骼数量/命名不同"的另一套骨架上
//
// 对应 Mesh2Motion 的 retarget/bone-automap/：
//   BoneNameTokenizer → 把 "mixamorig:LeftForeArm" 切成词元
//   BoneChainResolver → 归约成 (slot, side, ordinal)
//   CanonicalSlotMapper → 按语义槽位配对，而不是按名字配对
//
// 关键点：链长不同也要能配上（4 节脊椎对 3 节、4 节手指对 3 节），
// 按"相对位置比例"重采样，而不是简单地丢头丢尾。

/** 已知骨骼语义槽位（顺序即脊椎/手指链的自然顺序，用于排序） */
const SLOT_RULES = [
  // [槽位, 匹配词, 链顺序]
  ['pelvis', /pelvis|hips|hip$/, 0],
  ['spine', /spine|chest|torso|abdomen|ribcage/, 0],
  ['neck', /neck/, 0],
  ['head', /head$|head_/, 0],
  ['clavicle', /clavicle|shoulder|scapula|collar/, 0],
  ['upperarm', /upper_?arm|upperarm|arm_upper|humerus|shoulder_arm/, 0],
  ['lowerarm', /lower_?arm|lowerarm|forearm|elbow|arm_lower/, 0],
  ['hand', /hand$|hand_|wrist/, 0],
  ['thigh', /thigh|upper_?leg|upleg|leg_upper|hip_leg/, 0],
  ['calf', /calf|calf_|shin|lower_?leg|lowleg|leg_lower|knee/, 0],
  ['foot', /foot$|foot_|ankle/, 0],
  ['toe', /toe|ball/, 0]
]

const FINGERS = ['thumb', 'index', 'middle', 'ring', 'pinky']

/** 把骨骼名切成词元：LeftForeArm -> [left, fore, arm] */
export function tokenize (name) {
  return name
    .replace(/^(mixamorig|armature|bip\d*|rig)[:_.\s]*/i, '')
    .replace(/([a-z0-9])([A-Z])/g, '$1 $2')
    .replace(/([a-zA-Z])(\d)/g, '$1 $2')
    .replace(/[_\-.]+/g, ' ')
    .toLowerCase()
    .trim()
    .split(/\s+/)
    .filter(Boolean)
}

/** 判断左右：优先末尾 _l / _r，其次词元 left/right/l/r */
export function sideOf (name) {
  const lower = name.toLowerCase()
  if (/[_.\s]l$/.test(lower) || /\bleft\b/.test(lower) || lower.startsWith('l_')) return 'L'
  if (/[_.\s]r$/.test(lower) || /\bright\b/.test(lower) || lower.startsWith('r_')) return 'R'
  return 'C'
}

/**
 * 把一根骨头解析成 { slot, side, ord }。
 * ord 是该骨在其所属链里的序号（脊椎 0,1,2…；手指 1,2,3…）。
 */
export function resolveBone (name, ctx = {}) {
  const lower = name.toLowerCase()
  const side = sideOf(name)
  const toks = tokenize(name)

  if (/leaf|tip$|_tip|end$/.test(lower)) {
    return { slot: 'leaf', side, ord: 0, isLeaf: true }
  }
  if (/^root$|armature|master|reference/i.test(lower)) {
    return { slot: 'root', side: 'C', ord: 0, isRoot: true }
  }

  // 手指：thumb/index/middle/ring/pinky + 序号
  for (const f of FINGERS) {
    const idx = toks.indexOf(f)
    if (idx !== -1) {
      const numTok = toks.slice(idx + 1).find(t => /^\d+$/.test(t))
      const ord = numTok ? Number(numTok) : 1
      return { slot: 'finger_' + f, side, ord, finger: f }
    }
  }

  // 普通槽位
  for (const [slot, re] of SLOT_RULES) {
    if (re.test(lower) || toks.some(t => re.test(t))) {
      const numTok = toks.find(t => /^\d+$/.test(t))
      return { slot, side, ord: numTok ? Number(numTok) : 0 }
    }
  }
  return { slot: 'other', side, ord: 0 }
}

/**
 * 给一套骨架打标签。
 * @param {string[]} names 骨头名（已按父先子后的拓扑序）
 * @param {number[]} parentOf
 */
export function labelSkeleton (names, parentOf) {
  const raw = names.map(n => resolveBone(n))
  // spine/neck 之类没写序号的，按层级深度补齐 ord（父链上同槽位的个数）
  return raw.map((r, i) => {
    if (r.ord === 0 && !r.isLeaf && !r.isRoot) {
      let depth = 0
      let p = parentOf[i]
      while (p >= 0 && depth < 32) {
        if (raw[p].slot === r.slot) depth++
        p = parentOf[p]
      }
      if (depth > 0) return { ...r, ord: depth }
    }
    return r
  })
}

/**
 * 计算 目标骨架 → 源骨架 的映射。
 * @returns Map<目标骨下标, 源骨下标>
 */
export function buildBoneMap (srcNames, srcParent, dstNames, dstParent) {
  const srcLabels = labelSkeleton(srcNames, srcParent)
  const dstLabels = labelSkeleton(dstNames, dstParent)

  // 按 (slot, side) 分组，并按 ord 排序
  const group = (labels) => {
    const m = new Map()
    labels.forEach((l, i) => {
      const key = `${l.slot}|${l.side}`
      if (!m.has(key)) m.set(key, [])
      m.get(key).push({ i, ord: l.ord })
    })
    for (const arr of m.values()) arr.sort((a, b) => a.ord - b.ord)
    return m
  }
  const srcG = group(srcLabels)
  const dstG = group(dstLabels)

  const map = new Map()
  for (const [key, dstList] of dstG) {
    const srcList = srcG.get(key)
    if (!srcList || srcList.length === 0) continue
    for (let k = 0; k < dstList.length; k++) {
      // 链长不等时按比例重采样：3 节手指对 4 节 → 取最近的
      const t = dstList.length === 1 ? 0 : k / (dstList.length - 1)
      const si = Math.round(t * (srcList.length - 1))
      map.set(dstList[k].i, srcList[si].i)
    }
  }
  return { map, srcLabels, dstLabels }
}

/** 统计映射质量，用于日志 */
export function summarizeMapping (srcNames, dstNames, map) {
  const mapped = [...map.entries()]
  const slots = new Map()
  for (const [d, s] of mapped) {
    const slot = dstNames[d]
    slots.set(slot, srcNames[s])
  }
  const unmapped = dstNames.filter((_, i) => !map.has(i))
  return { mappedCount: map.size, total: dstNames.length, unmapped }
}