// 2D 骨架蒙皮求值：把绑定姿态的顶点按某一帧动画摆好。
//
// 和 web/runtime.js、tools/render-ref.mjs 用的是同一套 2D LBS 数学：
//   skinned = Σ w * (poseGlobal[bone] · bindGlobal[bone]⁻¹) · bindVertex
// 这里只求顶点位置，不画图；给 AI 分块皮肤做「纹理姿态 UV」用：
// 侧视 T-pose 的手臂指向镜头，屏幕投影退化成一个圆，不能拿绑定姿态投影当 UV；
// 选一个手臂已经伸开的动画帧，把顶点摆到那一帧再投影，UV 才覆盖整条手臂。
import fs from 'node:fs'
import path from 'node:path'

const aff = (x, y, r) => { const c = Math.cos(r), s = Math.sin(r); return [c, s, -s, c, x, y] }
const mul = (A, B) => [
  A[0] * B[0] + A[2] * B[1], A[1] * B[0] + A[3] * B[1],
  A[0] * B[2] + A[2] * B[3], A[1] * B[2] + A[3] * B[3],
  A[0] * B[4] + A[2] * B[5] + A[4], A[1] * B[4] + A[3] * B[5] + A[5]
]
const inv = (M) => {
  const det = M[0] * M[3] - M[1] * M[2]
  if (Math.abs(det) < 1e-12) throw new Error('2D 变换不可逆（骨头长度为 0？）')
  const id = 1 / det
  const a = M[3] * id, b = -M[1] * id, c = -M[2] * id, d = M[0] * id
  return [a, b, c, d, -(a * M[4] + c * M[5]), -(b * M[4] + d * M[5])]
}

/** 绑定姿态下某根骨头的全局原点（给 Q 版放大头部时当缩放枢轴） */
export function bindBoneOrigin (charDef, boneName) {
  const bones = charDef.bones
  const g = new Array(bones.length)
  for (let i = 0; i < bones.length; i++) {
    const b = bones[i]
    const L = aff(b.x, b.y, b.rot)
    g[i] = b.parent < 0 ? L : mul(g[b.parent], L)
  }
  const i = bones.findIndex(b => b.name === boneName)
  if (i < 0) throw new Error(`没有骨头 ${boneName}`)
  return [g[i][4], g[i][5]]
}

export function loadClip (dataDir, clipName) {
  const animPath = path.join(dataDir, 'anim.json')
  if (!fs.existsSync(animPath)) throw new Error('没有动画数据: ' + animPath)
  const anims = JSON.parse(fs.readFileSync(animPath, 'utf8'))
  const clip = anims.clips[clipName]
  if (!clip) {
    throw new Error(`没有动画 ${clipName}；可用: ${Object.keys(anims.clips).join(', ')}`)
  }
  return clip
}

/**
 * 按 clip/frame 对 mesh 做 2D 蒙皮，返回 Float32Array(nv*2)。
 * 缺轨道的骨头沿用绑定姿态（和运行时一致）。
 */
export function computePosedVerts (charDef, clip, frame) {
  const bones = charDef.bones
  const n = bones.length
  const bg = new Array(n), bi = new Array(n)
  for (let i = 0; i < n; i++) {
    const b = bones[i]
    const L = aff(b.x, b.y, b.rot)
    bg[i] = b.parent < 0 ? L : mul(bg[b.parent], L)
    bi[i] = inv(bg[i])
  }

  const g = new Array(n)
  for (let i = 0; i < n; i++) {
    const b = bones[i]
    const t = clip.tracks[b.name]
    let lx, ly, rot
    if (t) {
      const o = frame * 4
      if (o + 3 >= t.length) throw new Error(`帧 ${frame} 超出动画范围（${t.length / 4} 帧）`)
      lx = t[o] * b.len
      ly = t[o + 1] * b.len
      rot = t[o + 2]
    } else {
      lx = b.x; ly = b.y; rot = b.rot
    }
    const L = aff(lx, ly, rot)
    g[i] = b.parent < 0 ? L : mul(g[b.parent], L)
  }

  const mesh = charDef.mesh
  const verts = mesh.verts, si = mesh.skinIndices, sw = mesh.skinWeights
  const nv = verts.length / 2
  const out = new Float32Array(nv * 2)
  for (let v = 0; v < nv; v++) {
    const bx = verts[v * 2], by = verts[v * 2 + 1]
    let x = 0, y = 0
    for (let k = 0; k < 4; k++) {
      const w = sw[v * 4 + k]
      if (w <= 0) continue
      const b = si[v * 4 + k]
      const M = mul(g[b], bi[b])
      x += w * (M[0] * bx + M[2] * by + M[4])
      y += w * (M[1] * bx + M[3] * by + M[5])
    }
    out[v * 2] = x
    out[v * 2 + 1] = y
  }
  return out
}

/** 一组顶点在给定位置数组里的包围盒 [minX, minY, maxX, maxY] */
export function vertsBox (positions, verts) {
  let minX = 1e9, minY = 1e9, maxX = -1e9, maxY = -1e9
  for (const v of verts) {
    const x = positions[v * 2], y = positions[v * 2 + 1]
    if (x < minX) minX = x
    if (x > maxX) maxX = x
    if (y < minY) minY = y
    if (y > maxY) maxY = y
  }
  return [minX, minY, maxX, maxY]
}
