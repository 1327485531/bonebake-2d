@echo off
cd /d "%~dp0"
echo 正在启动本地服务器（8899 被占用会自动换端口，以控制台打印为准）
echo 按 Ctrl+C 停止。
node tools\serve.mjs
if errorlevel 1 python tools\serve.py
if errorlevel 1 py -3 tools\serve.py
pause
