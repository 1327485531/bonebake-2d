# 素材许可（Assets License）

本仓库的**代码**是 MIT；素材按层授权，但**仓库里不包含任何 AI 生成图片**。

## 代码

MIT，见 [LICENSE](LICENSE)。

## 动画 / 模型 / 骨架：CC0

- 来源：[Mesh2Motion](https://github.com/Mesh2Motion/mesh2motion-app)（代码 MIT）
- 本仓库的 12 个动画来自 `human-base-animations.glb`；上游声明 3D 模型/骨架/动画为 **CC0 1.0**。
- CC0 允许复制、修改、分发、商用，不要求署名。
- `CarnegieMellonAnimations/` 与 `human-mocap-animations.glb` **没有**包含在本仓库，也不是 index 当前使用的动画；
  CMU/mocap 数据不能直接转售（含转换形式），不要把它们打进发布包。
- 手绘模板 / ref 图是对 CC0 网格的派生渲染，按 CC0 处理。

## 字体 / 运行时

- `web/fonts/NotoSansSC-400.woff2`：SIL OFL 1.1，见 `web/fonts/OFL.txt`。
- DragonBones：MIT；PixiJS：MIT；保留各自文件头/许可。

## AI 生成图片：不随仓库分发

- `gallery/` 的 AI 角色图已移除；仓库不包含 AI 生成图片。
- `out/` 里的 AI 贴图是本地生成物，git 忽略，不随仓库分发。
- 生成脚本/提示词（如 `tools/generate-character-sets.mjs`）是 MIT 代码；生成需要用户自己的 API 地址和 key。
- AI 输出图片的商用/再分发条款取决于 OpenAI / 你使用的 API 服务（如 AruHub 或其他代理）；
  用户生成后若要公开/商用，需自行核对上游条款。本项目不对 AI 输出图片作任何授权或担保。

## 一句话

**代码 MIT；动画/模型/骨架 CC0；字体 OFL；DragonBones/Pixi MIT；仓库不含 AI 图片。**
