# 第三方素材与许可

本文档说明本仓库里哪些东西可以直接商用、哪些需要单独确认。不是法律意见；发布前请保留上游许可原文并自行复核。

## 1. 动画 / 模型 / 骨架：Mesh2Motion（CC0 素材 + MIT 代码）

- 上游：<https://github.com/Mesh2Motion/mesh2motion-app>
- 本地副本：`mesh2motion-app/`（不纳入本仓库版本管理）
- 许可：
  - 代码/平台：MIT，见 `mesh2motion-app/LICENSE-MIT.MD`
  - **3D 模型、骨架、动画：CC0 1.0**，见 `mesh2motion-app/LICENSE-CC0.MD`
  - 上游 README 原文：“The art assets (3d models, rigs, animations) are all licensed under CC0.”
- 本 demo 的 12 个动画都来自：

  ```text
  mesh2motion-app/static/animations/human-base-animations.glb
  Idle_A / Walk / Jog / Sprint / Jump_air / Sword_Attack /
  Punch_Jab / Dance_Simple / Roll / Zombie_Walk / Pistol_Shoot / Crouch_Walk
  ```

  `tools/bake-all.sh` 只加载这个 GLB；没有使用 `human-mocap-animations.glb`、
  `human-addon-animations.glb` 或 `CarnegieMellonAnimations/`。
- CC0 允许复制、修改、分发、商用，**不要求署名**；保留来源说明是好习惯。

> 注意：`CarnegieMellonAnimations/` 是上游附带的一小份 CMU/rancidmilk 样例
> （<https://rancidmilk.itch.io/free-character-animations>），**不是本 demo 当前使用的动画**。
> `human-mocap-animations.glb` 是 mocap 转换出的 GLB，也不是当前 index 用的动画。
>
> CMU Motion Capture Database 的条款（<http://mocap.cs.cmu.edu/>）：
> 数据可用于研究，也可包含在商业产品中，但**不能直接转售数据本身（包括转换后的形式）**。
> 因此不要把 `CarnegieMellonAnimations/` 或 `human-mocap-animations.glb` 打进 GitHub 仓库/发布包；
> `mesh2motion-app/` 整个不入库即可。

## 2. 字体：Noto Sans SC（SIL OFL 1.1）

- 文件：`web/fonts/NotoSansSC-400.woff2`
- 许可：SIL Open Font License 1.1，全文见 `web/fonts/OFL.txt`
- 可随软件一起分发/商用；修改字体后仍需遵守 OFL（保留名称/许可等）。

## 3. DragonBones / PixiJS（MIT）

- `tools/vendor/dragonBones-core.js`：DragonBones MIT
- `web/vendor/dragonBones-pixi.js`：DragonBones MIT
- `web/vendor/pixi.js`：PixiJS v8.9.2，MIT
- 保留各自文件头部的版权/许可声明即可。

## 4. AI 生成图片（不随仓库分发）

`ai_ronin*`、`ai_chibi`、`ai_mage` 等角色的 AI 贴图只在本地 `out/` 生成，**git 忽略，仓库不包含**。

- 底层网格/骨架/动画仍是 CC0 + MIT；
- 生成脚本/提示词是 MIT 代码；生成需要用户自己的 API 地址和 key；
- AI 输出图片的商用/再分发条款取决于 OpenAI / 你使用的 API 服务（AruHub 或其它代理），
  本项目不对 AI 输出图片作授权或担保；
- 不要把 key、`.env` 或 `out/` 里的 AI 图提交到仓库。

## 5. 结论（针对 index 当前动画）

`web/index.html` 当前播放的 12 个动画来自 Mesh2Motion 的 `human-base-animations.glb`，
上游声明为 **CC0**，因此**可以免费商用**（无署名要求）。  
但页面上的 **AI 角色贴图**是另一层授权，不在 CC0 范围内；发布前请按第 4 节单独确认。
